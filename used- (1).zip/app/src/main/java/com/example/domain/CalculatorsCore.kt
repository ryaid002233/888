package com.example.domain

import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.domain.WesternDigits.round3
import kotlin.math.abs

data class SellerCalcResult(
    val sumS1n: Double = 0.0,
    val sumS1m: Double = 0.0,
    val sumS2n: Double = 0.0,
    val sumS2m: Double = 0.0,
    val sumS3n: Double = 0.0,
    val sumS3m: Double = 0.0,
    val sumCashQty: Double = 0.0,
    val saleCash: Double = 0.0,
    val sumDebtQty: Double = 0.0,
    val sumDebtAmt: Double = 0.0,
    val sumQatOutQty: Double = 0.0,
    val sumQatOutAmt: Double = 0.0,
    val enteredQty: Double = 0.0,
    val qtyBalance: Double = 0.0,
    val sumReceived: Double = 0.0,
    val sumOut: Double = 0.0,
    val sumWithdraw: Double = 0.0,
    val sumWeekly: Double = 0.0,
    val cashAfterOut: Double = 0.0,
    val cashBalance: Double = 0.0,
    val currencyTotal: Double = 0.0,
    val currencyDiff: Double = 0.0
)

object SellerInvoiceCalculator {
    fun calculate(form: SellerFormData): SellerCalcResult {
        var s1n = 0.0
        var s1m = 0.0
        var s2n = 0.0
        var s2m = 0.0
        var s3n = 0.0
        var s3m = 0.0
        var dn = 0.0
        var dm = 0.0
        var onQty = 0.0
        var om = 0.0

        val colCount = form.saleColCount.coerceIn(1, 3)
        form.salesRows.forEach { r ->
            s1n += num(r.s1n)
            s1m += num(r.s1m)
            if (colCount >= 2) {
                s2n += num(r.s2n)
                s2m += num(r.s2m)
            }
            if (colCount >= 3) {
                s3n += num(r.s3n)
                s3m += num(r.s3m)
            }
            dn += num(r.dn)
            dm += num(r.dm)
            onQty += num(r.onQty)
            om += num(r.om)
        }

        val sumCashQty = s1n + s2n + s3n
        val saleCash = s1m + s2m + s3m
        val enteredQty = num(form.qty)
        val qtyBalance = enteredQty - sumCashQty - dn - onQty

        val sumReceived = form.receivedRows.sumOf { num(it.amount) }
        val sumOut = form.outRows.sumOf { num(it.amount) }
        val sumWithdraw = form.withdrawRows.sumOf { num(it.amount) }
        val sumWeekly = form.weeklyRows.sumOf { num(it.amount) }

        val cashAfterOut = saleCash - sumOut
        val cashBalance = cashAfterOut + sumWeekly + sumReceived - sumWithdraw

        val currencyTotal = form.currencyRows.sumOf { row ->
            val amt = num(row.amount)
            val rate = if (row.cur.contains("يمني")) 1.0 else {
                val r = num(row.rate)
                if (r > 0.0) r else 1.0
            }
            amt * rate
        }

        return SellerCalcResult(
            sumS1n = round3(s1n),
            sumS1m = round3(s1m),
            sumS2n = round3(s2n),
            sumS2m = round3(s2m),
            sumS3n = round3(s3n),
            sumS3m = round3(s3m),
            sumCashQty = round3(sumCashQty),
            saleCash = round3(saleCash),
            sumDebtQty = round3(dn),
            sumDebtAmt = round3(dm),
            sumQatOutQty = round3(onQty),
            sumQatOutAmt = round3(om),
            enteredQty = round3(enteredQty),
            qtyBalance = round3(qtyBalance),
            sumReceived = round3(sumReceived),
            sumOut = round3(sumOut),
            sumWithdraw = round3(sumWithdraw),
            sumWeekly = round3(sumWeekly),
            cashAfterOut = round3(cashAfterOut),
            cashBalance = round3(cashBalance),
            currencyTotal = round3(currencyTotal),
            currencyDiff = round3(cashBalance - currencyTotal)
        )
    }
}

data class WeeklyCalcResult(
    val rowQtyRemaining: List<Double>,
    val totQty: Double,
    val totCashQty: Double,
    val totDebtQty: Double,
    val totExpQty: Double,
    val totQtyRemaining: Double,
    val rowSalesTotals: List<Double>,
    val totSalesCash: Double,
    val totSalesWeekly: Double,
    val totSalesWeeklySales: Double,
    val totSalesPrev: Double,
    val totSalesAll: Double,
    val rowMoneyTotals: List<Double>,
    val totYemeni: Double,
    val totSaudiAmt: Double,
    val totSaudiExch: Double,
    val totOmaniAmt: Double,
    val totOmaniExch: Double,
    val totDirhamAmt: Double,
    val totDirhamExch: Double,
    val totMoneyAll: Double,
    val diff: Double
)

object WeeklyFilterCalculator {

    fun calculate(filter: WeeklyFilter): WeeklyCalcResult {
        var cumRem = 0.0
        var tQ = 0.0
        var tC = 0.0
        var tD = 0.0
        var tE = 0.0
        val remList = mutableListOf<Double>()

        filter.qtyRows.forEach { r ->
            val q = num(r.qty)
            val c = num(r.cash)
            val d = num(r.debt)
            val e = num(r.expense)
            cumRem = cumRem + q - c - d - e
            tQ += q
            tC += c
            tD += d
            tE += e
            remList.add(round3(cumRem))
        }

        var tsC = 0.0
        var tsW = 0.0
        var tsWS = 0.0
        var tsP = 0.0
        var tsAll = 0.0
        val sList = mutableListOf<Double>()

        filter.salesRows.forEach { r ->
            val c = num(r.cash)
            val w = num(r.weeklyAmt)
            val ws = num(r.weeklySalesAmt)
            val p = num(r.prevAmt)
            val tot = c + w + ws - p
            tsC += c
            tsW += w
            tsWS += ws
            tsP += p
            tsAll += tot
            sList.add(round3(tot))
        }

        var tmY = 0.0
        var tmSA = 0.0
        var tmSE = 0.0
        var tmOA = 0.0
        var tmOE = 0.0
        var tmDA = 0.0
        var tmDE = 0.0
        var tmAll = 0.0
        val mList = mutableListOf<Double>()

        filter.moneyRows.forEach { r ->
            val y = num(r.yemeni)
            val sa = num(r.saudiAmt)
            val se = num(r.saudiExch)
            val oa = num(r.omaniAmt)
            val oe = num(r.omaniExch)
            val da = num(r.dirhamAmt)
            val de = num(r.dirhamExch)
            val tot = y + se + oe + de
            tmY += y
            tmSA += sa
            tmSE += se
            tmOA += oa
            tmOE += oe
            tmDA += da
            tmDE += de
            tmAll += tot
            mList.add(round3(tot))
        }

        return WeeklyCalcResult(
            rowQtyRemaining = remList,
            totQty = round3(tQ),
            totCashQty = round3(tC),
            totDebtQty = round3(tD),
            totExpQty = round3(tE),
            totQtyRemaining = round3(cumRem),
            rowSalesTotals = sList,
            totSalesCash = round3(tsC),
            totSalesWeekly = round3(tsW),
            totSalesWeeklySales = round3(tsWS),
            totSalesPrev = round3(tsP),
            totSalesAll = round3(tsAll),
            rowMoneyTotals = mList,
            totYemeni = round3(tmY),
            totSaudiAmt = round3(tmSA),
            totSaudiExch = round3(tmSE),
            totOmaniAmt = round3(tmOA),
            totOmaniExch = round3(tmOE),
            totDirhamAmt = round3(tmDA),
            totDirhamExch = round3(tmDE),
            totMoneyAll = round3(tmAll),
            diff = round3(tsAll - tmAll)
        )
    }

    fun buildFilterFromFolder(
        folder: WeekFolder,
        existingFilter: WeeklyFilter?
    ): WeeklyFilter {
        val slots = DateHelper.buildWeekSlots(folder.startDate, folder.endDate)
        val oldSalesByDate = existingFilter?.salesRows?.associateBy { it.date }.orEmpty()

        val qtyRows = slots.map { (day, date) -> WeeklyQtyRow(day = day, date = date) }.toMutableList()
        val salesRows = slots.map { (day, date) ->
            val old = oldSalesByDate[date]
            WeeklySalesRow(
                day = day,
                date = date,
                weeklyNote = old?.weeklyNote ?: "",
                weeklySalesNote = old?.weeklySalesNote ?: "",
                prevNote = old?.prevNote ?: ""
            )
        }.toMutableList()
        val moneyRows = slots.map { (day, date) -> WeeklyMoneyRow(day = day, date = date) }.toMutableList()

        val accQty = DoubleArray(slots.size)
        val accCashQty = DoubleArray(slots.size)
        val accDebtQty = DoubleArray(slots.size)
        val accExpQty = DoubleArray(slots.size)

        val accSaleCash = DoubleArray(slots.size)
        val accSaleGross = DoubleArray(slots.size)
        val accOutAmt = DoubleArray(slots.size)
        val accRecvAmt = DoubleArray(slots.size)
        val accWeeklyAmt = DoubleArray(slots.size)
        val accWithdrawAmt = DoubleArray(slots.size)

        val accYemeni = DoubleArray(slots.size)
        val accSaudiAmt = DoubleArray(slots.size)
        val accSaudiExch = DoubleArray(slots.size)
        val accOmaniAmt = DoubleArray(slots.size)
        val accOmaniExch = DoubleArray(slots.size)
        val accDirhamAmt = DoubleArray(slots.size)
        val accDirhamExch = DoubleArray(slots.size)

        val dateIndex = slots.withIndex().associate { (i, p) -> p.second to i }
        folder.invoices
            .filter { it.invoiceKind != "buyer" }
            .sortedBy { it.initDateISO }
            .forEach { inv ->
                val idx = dateIndex[inv.initDateISO] ?: return@forEach
                val calc = SellerInvoiceCalculator.calculate(inv.formData)
                accQty[idx] += calc.enteredQty
                accCashQty[idx] += calc.sumCashQty
                accDebtQty[idx] += calc.sumDebtQty
                accExpQty[idx] += calc.sumQatOutQty

                accSaleCash[idx] += calc.cashAfterOut
                accSaleGross[idx] += calc.saleCash
                accOutAmt[idx] += calc.sumOut
                accRecvAmt[idx] += calc.sumReceived
                accWeeklyAmt[idx] += calc.sumWeekly
                accWithdrawAmt[idx] += calc.sumWithdraw

                inv.formData.currencyRows.forEach { cr ->
                    val amt = num(cr.amount)
                    val rate = if (cr.cur.contains("يمني")) 1.0 else {
                        val r = num(cr.rate)
                        if (r > 0.0) r else 1.0
                    }
                    val valAmt = amt * rate
                    when {
                        cr.cur.contains("سعودي") -> {
                            accSaudiAmt[idx] += amt
                            accSaudiExch[idx] += valAmt
                        }
                        cr.cur.contains("عماني") -> {
                            accOmaniAmt[idx] += amt
                            accOmaniExch[idx] += valAmt
                        }
                        cr.cur.contains("درهم") -> {
                            accDirhamAmt[idx] += amt
                            accDirhamExch[idx] += valAmt
                        }
                        else -> {
                            accYemeni[idx] += valAmt
                        }
                    }
                }
            }

        for (i in slots.indices) {
            qtyRows[i] = qtyRows[i].copy(
                qty = rawNumberString(accQty[i]),
                cash = rawNumberString(accCashQty[i]),
                debt = rawNumberString(accDebtQty[i]),
                expense = rawNumberString(accExpQty[i])
            )
            salesRows[i] = salesRows[i].copy(
                cash = rawNumberString(accSaleCash[i]),
                saleGross = rawNumberString(accSaleGross[i]),
                outAmt = rawNumberString(accOutAmt[i]),
                weeklyAmt = rawNumberString(accRecvAmt[i]),
                weeklySalesAmt = rawNumberString(accWeeklyAmt[i]),
                prevAmt = rawNumberString(accWithdrawAmt[i])
            )
            moneyRows[i] = moneyRows[i].copy(
                yemeni = rawNumberString(accYemeni[i]),
                saudiAmt = rawNumberString(accSaudiAmt[i]),
                saudiExch = rawNumberString(accSaudiExch[i]),
                omaniAmt = rawNumberString(accOmaniAmt[i]),
                omaniExch = rawNumberString(accOmaniExch[i]),
                dirhamAmt = rawNumberString(accDirhamAmt[i]),
                dirhamExch = rawNumberString(accDirhamExch[i])
            )
        }

        return WeeklyFilter(
            id = existingFilter?.id ?: newId("wf"),
            name = folder.name,
            fromDate = folder.startDate,
            toDate = folder.endDate,
            sourceFolderId = folder.id,
            specialtyId = folder.specialtyId,
            qtyRows = qtyRows,
            salesRows = salesRows,
            moneyRows = moneyRows,
            updatedAt = System.currentTimeMillis()
        )
    }
}

object DetailCalculator {

    fun recalculate(form: DetailFormData): DetailFormData {
        val qQty = num(form.qQty)
        val qCash = num(form.qCash)
        val qDebt = num(form.qDebt)
        val qOut = num(form.qOut)
        val computedQRest = qQty - qCash - qDebt - qOut

        val sSale = num(form.sSale)
        val sWeekly = num(form.sWeekly)
        val sPrivateOut = num(form.sPrivateOut)
        val computedSCashRest = sSale + sWeekly - sPrivateOut

        val updatedDebts = form.debtRows.map { row ->
            val rest = round3(num(row.amount) - num(row.weekly))
            row.copy(rest = rest)
        }
        val computedSDebtSale = updatedDebts.sumOf { it.rest }
        val computedSGrand = computedSCashRest + computedSDebtSale

        val computedPrevTotal = form.receivedRows.sumOf { num(it.amount) }
        val computedMidTotal = computedSCashRest + computedPrevTotal + sPrivateOut

        val wVal = num(form.wValue)
        val computedMTotal = form.moneyRows.sumOf { num(it.value) } + wVal
        val computedChkDiff = computedMTotal - computedMidTotal

        val overrides = form.manualOverrides
        val qRest = overrides["qRest"]?.let { num(it) } ?: computedQRest
        val sCashRest = overrides["sCashRest"]?.let { num(it) } ?: computedSCashRest
        val sDebtSale = overrides["sDebtSale"]?.let { num(it) } ?: computedSDebtSale
        val sGrand = overrides["sGrand"]?.let { num(it) } ?: (sCashRest + sDebtSale)
        val prevTotal = overrides["prevTotal"]?.let { num(it) } ?: computedPrevTotal
        val midTotal = overrides["midTotal"]?.let { num(it) } ?: (sCashRest + prevTotal + sPrivateOut)
        val mTotal = overrides["mTotal"]?.let { num(it) } ?: computedMTotal
        val chkDiff = overrides["chkDiff"]?.let { num(it) } ?: (mTotal - midTotal)

        return form.copy(
            debtRows = updatedDebts,
            calcQRest = round3(qRest),
            calcSCashRest = round3(sCashRest),
            calcSDebtSale = round3(sDebtSale),
            calcSGrand = round3(sGrand),
            calcPrevTotal = round3(prevTotal),
            calcMidTotal = round3(midTotal),
            calcMTotal = round3(mTotal),
            calcChkDiff = round3(chkDiff)
        )
    }

    fun buildDetailFormFromFolder(
        folder: WeekFolder,
        weeklyFilter: WeeklyFilter,
        specialties: List<Specialty>,
        existingForm: DetailFormData?
    ): DetailFormData {
        val invoices = folder.invoices.filter { it.invoiceKind != "buyer" }.sortedBy { it.initDateISO }
        val wCalc = WeeklyFilterCalculator.calculate(weeklyFilter)

        val specWorkersMap = specialties.associate { it.id to it.workersAmount }
        val totalWorkersFee = invoices.sumOf { inv ->
            val spId = inv.specialtyId.ifBlank { folder.specialtyId }
            specWorkersMap[spId] ?: 0.0
        }

        // Aggregate debt rows by name, matching weeklyRows for weekly paid amount
        data class DebtAcc(var qty: Double = 0.0, var amt: Double = 0.0, var wk: Double = 0.0)
        val debtMap = linkedMapOf<String, DebtAcc>()
        val recMap = linkedMapOf<String, Double>()
        val withdrawItems = mutableListOf<DetailWithdrawItem>()
        val moneyDayItems = mutableListOf<DetailMoneyDayItem>()

        var yemAmt = 0.0
        var yemVal = 0.0
        var sauAmt = 0.0
        var sauVal = 0.0
        var omaAmt = 0.0
        var omaVal = 0.0
        var dirAmt = 0.0
        var dirVal = 0.0

        invoices.forEach { inv ->
            val fd = inv.formData
            fd.salesRows.forEach { sr ->
                val name = sr.dname.trim()
                val dm = num(sr.dm)
                val dn = num(sr.dn)
                if (name.isNotEmpty() || dm > 0.0) {
                    val key = name.ifBlank { "عميل" }
                    val acc = debtMap.getOrPut(key) { DebtAcc() }
                    acc.qty += dn
                    acc.amt += dm
                }
            }
            fd.weeklyRows.forEach { wr ->
                val name = wr.name.trim()
                val a = num(wr.amount)
                if (name.isNotEmpty() && a > 0.0) {
                    val acc = debtMap.getOrPut(name) { DebtAcc() }
                    acc.wk += a
                }
            }
            fd.receivedRows.forEach { rr ->
                val name = rr.name.trim()
                val a = num(rr.amount)
                if (a > 0.0) {
                    val key = name.ifBlank { "مسلم" }
                    recMap[key] = (recMap[key] ?: 0.0) + a
                }
            }
            fd.withdrawRows.forEach { wd ->
                val a = num(wd.amount)
                if (a > 0.0) {
                    withdrawItems.add(
                        DetailWithdrawItem(
                            name = wd.name.trim().ifBlank { inv.initSeller },
                            amount = a,
                            date = inv.initDateISO,
                            note = wd.name.trim()
                        )
                    )
                }
            }
            val dayName = DateHelper.dayNameAr(inv.initDateISO)
            fd.currencyRows.forEach { cr ->
                val amt = num(cr.amount)
                val rate = if (cr.cur.contains("يمني")) 1.0 else {
                    val r = num(cr.rate)
                    if (r > 0.0) r else 1.0
                }
                val v = amt * rate
                if (amt > 0.0 || v > 0.0) {
                    moneyDayItems.add(
                        DetailMoneyDayItem(
                            cur = cr.cur,
                            amount = amt,
                            rate = rate,
                            value = v,
                            date = inv.initDateISO,
                            dayName = dayName
                        )
                    )
                    when {
                        cr.cur.contains("سعودي") -> { sauAmt += amt; sauVal += v }
                        cr.cur.contains("عماني") -> { omaAmt += amt; omaVal += v }
                        cr.cur.contains("درهم") -> { dirAmt += amt; dirVal += v }
                        else -> { yemAmt += amt; yemVal += v }
                    }
                }
            }
        }

        val debtRows = debtMap.entries
            .filter { it.value.amt > 0.0 }
            .map { (name, acc) ->
                val amt = round3(acc.amt)
                val wk = round3(acc.wk)
                DetailDebtRow(
                    name = name,
                    qty = rawNumberString(acc.qty),
                    amount = rawNumberString(amt),
                    weekly = rawNumberString(wk),
                    rest = round3(amt - wk)
                )
            }

        val recRows = recMap.entries.map { (name, amt) ->
            DetailReceivedRow(name = name, amount = rawNumberString(round3(amt)))
        }

        val moneyRows = listOf(
            DetailMoneyRow(label = "يمني", amount = rawNumberString(yemAmt), value = rawNumberString(yemVal)),
            DetailMoneyRow(label = "سعودي", amount = rawNumberString(sauAmt), value = rawNumberString(sauVal)),
            DetailMoneyRow(label = "عماني", amount = rawNumberString(omaAmt), value = rawNumberString(omaVal)),
            DetailMoneyRow(label = "درهم", amount = rawNumberString(dirAmt), value = rawNumberString(dirVal))
        )

        val saleGross = weeklyFilter.salesRows.sumOf { num(it.saleGross) }
        val outAmt = weeklyFilter.salesRows.sumOf { num(it.outAmt) }
        val qCash = wCalc.totCashQty
        val qDebt = wCalc.totDebtQty
        val qOut = wCalc.totExpQty

        val base = DetailFormData(
            qQty = rawNumberString(wCalc.totQty),
            qCash = rawNumberString(qCash),
            qDebt = rawNumberString(qDebt),
            qOut = rawNumberString(qOut),
            sSale = rawNumberString(round3(saleGross - outAmt)),
            sWeekly = rawNumberString(wCalc.totSalesWeeklySales),
            sPrivateOut = rawNumberString(round3(totalWorkersFee)),
            wLabel = existingForm?.wLabel ?: "السحب فلوس",
            wValue = rawNumberString(wCalc.totSalesPrev),
            note = existingForm?.note ?: "",
            manualOverrides = existingForm?.manualOverrides ?: emptyMap(),
            receivedRows = recRows,
            debtRows = debtRows,
            moneyRows = moneyRows,
            withdrawSnapshot = withdrawItems,
            moneyDaysSnapshot = moneyDayItems,
            moneySummarySnapshot = DetailMoneySnapshot(
                yemeniAmt = round3(yemAmt),
                yemeniVal = round3(yemVal),
                saudiAmt = round3(sauAmt),
                saudiVal = round3(sauVal),
                omaniAmt = round3(omaAmt),
                omaniVal = round3(omaVal),
                dirhamAmt = round3(dirAmt),
                dirhamVal = round3(dirVal)
            )
        )
        return recalculate(base)
    }

    fun buildClockEntries(
        detail: DetailRecord,
        specialties: List<Specialty>
    ): List<ClockEntry> {
        val fd = recalculate(detail.formData)
        val from = detail.initDateFrom.ifBlank { DateHelper.todayIso() }
        val to = detail.initDateTo.ifBlank { from }
        val sp = detail.specialtyId
        val days = DateHelper.daysBetweenInclusive(from, to)
        val entries = mutableListOf<ClockEntry>()
        val srcId = detail.id

        if (abs(fd.calcSGrand) > 1e-9) {
            entries.add(
                ClockEntry(
                    section = ClockSection.SALE,
                    srcDetailId = srcId,
                    specialtyId = sp,
                    dir = "لكم",
                    amount = abs(fd.calcSGrand),
                    name = detail.initDetail,
                    date = from,
                    to = to,
                    qty = num(fd.qQty),
                    auto = true
                )
            )
        }

        val workersVal = num(fd.sPrivateOut)
        if (abs(workersVal) > 1e-9) {
            entries.add(
                ClockEntry(
                    section = ClockSection.WORKERS,
                    srcDetailId = srcId,
                    specialtyId = sp,
                    dir = "لكم",
                    amount = abs(workersVal),
                    name = detail.initDetail,
                    date = from,
                    to = to,
                    days = days,
                    auto = true
                )
            )
        }

        val wLabel = fd.wLabel.trim().ifBlank { "سحب فلوس" }
        val wItems = fd.withdrawSnapshot.filter { it.amount > 0.0 }
        if (wItems.isNotEmpty()) {
            wItems.forEach { w ->
                val wd = w.date.trim().ifBlank { from }
                val stmt = "$wLabel — ${w.name.trim()}" + if (wd.isNotBlank()) " $wd" else ""
                entries.add(
                    ClockEntry(
                        section = ClockSection.WITHDRAW,
                        srcDetailId = srcId,
                        specialtyId = sp,
                        dir = "عليكم",
                        amount = abs(w.amount),
                        name = stmt,
                        date = wd,
                        to = wd,
                        note = stmt,
                        auto = true
                    )
                )
            }
        } else {
            val wTot = num(fd.wValue)
            if (abs(wTot) > 1e-9) {
                entries.add(
                    ClockEntry(
                        section = ClockSection.WITHDRAW,
                        srcDetailId = srcId,
                        specialtyId = sp,
                        dir = "عليكم",
                        amount = abs(wTot),
                        name = wLabel,
                        date = from,
                        to = to,
                        note = wLabel,
                        auto = true
                    )
                )
            }
        }

        val recSub = fd.receivedRows
            .filter { num(it.amount) > 0.0 }
            .map { ClockDebtSubRow(name = it.name.trim(), amount = num(it.amount)) }
        val paidMoney = if (fd.calcPrevTotal > 0.0) fd.calcPrevTotal else recSub.sumOf { it.amount }
        if (abs(paidMoney) > 1e-9) {
            entries.add(
                ClockEntry(
                    section = ClockSection.DEBTS,
                    srcDetailId = srcId,
                    specialtyId = sp,
                    dir = "لكم",
                    amount = abs(paidMoney),
                    name = detail.initDetail,
                    date = from,
                    to = to,
                    kind = "received",
                    subRows = recSub,
                    auto = true
                )
            )
        }

        val debtSub = fd.debtRows
            .filter { it.name.isNotBlank() || num(it.amount) > 0.0 || num(it.weekly) > 0.0 }
            .map {
                ClockDebtSubRow(
                    name = it.name.trim(),
                    qty = num(it.qty),
                    amount = num(it.amount),
                    rest = it.rest
                )
            }
        val grossDebt = debtSub.sumOf { it.rest }
        if (abs(grossDebt) > 1e-9) {
            entries.add(
                ClockEntry(
                    section = ClockSection.DEBTS,
                    srcDetailId = srcId,
                    specialtyId = sp,
                    dir = "عليكم",
                    amount = abs(grossDebt),
                    name = detail.initDetail,
                    date = from,
                    to = to,
                    kind = "debtsale",
                    subRows = debtSub,
                    auto = true
                )
            )
        }

        fun curRank(label: String): Int = when {
            label.contains("يمني") -> 0
            label.contains("سعودي") -> 1
            label.contains("عماني") -> 2
            label.contains("درهم") -> 3
            else -> 4
        }

        val dayItems = fd.moneyDaysSnapshot.filter { it.value > 0.0 || it.amount > 0.0 }
        if (dayItems.isNotEmpty()) {
            dayItems.groupBy { it.date.ifBlank { from } }.toSortedMap().forEach { (dt, items) ->
                val mergedByCur = linkedMapOf<Pair<String, Double>, TsRowCurrency>()
                items.forEach { itDay ->
                    val rate = if (itDay.rate > 0.0) itDay.rate else if (itDay.amount > 0.0) itDay.value / itDay.amount else 1.0
                    val amt = if (itDay.amount > 0.0) itDay.amount else itDay.value
                    val key = itDay.cur.trim() to WesternDigits.round6(rate)
                    val prev = mergedByCur[key]
                    mergedByCur[key] = if (prev == null) {
                        TsRowCurrency(cur = itDay.cur.trim(), a = amt, r = rate)
                    } else {
                        prev.copy(a = prev.a + amt)
                    }
                }
                val rs = mergedByCur.values
                    .filter { abs(it.a * it.r) > 1e-9 }
                    .sortedBy { curRank(it.cur) }
                val tot = rs.sumOf { abs(it.a * it.r) }
                if (tot > 1e-9 && rs.isNotEmpty()) {
                    val dayNm = items.firstNotNullOfOrNull { it.dayName.takeIf(String::isNotBlank) }
                        ?: DateHelper.dayNameAr(dt).ifBlank { dt }
                    val first = rs.first()
                    entries.add(
                        ClockEntry(
                            section = ClockSection.CURRENCY,
                            srcDetailId = srcId,
                            specialtyId = sp,
                            dir = "لكم",
                            amount = tot,
                            name = "عملات $dayNm",
                            date = dt,
                            to = dt,
                            cur = first.cur,
                            curAmount = first.a,
                            curRate = first.r,
                            rows = rs,
                            auto = true
                        )
                    )
                }
            }
        } else {
            val rs = fd.moneyRows.mapNotNull { mr ->
                val v = num(mr.value)
                val a = num(mr.amount)
                if (v > 0.0) {
                    val amt = if (a > 0.0) a else v
                    TsRowCurrency(
                        cur = mr.label,
                        a = amt,
                        r = if (amt > 0.0) v / amt else 1.0
                    )
                } else null
            }
            val tot0 = rs.sumOf { abs(it.a * it.r) }
            if (tot0 > 1e-9 && rs.isNotEmpty()) {
                val first = rs.first()
                entries.add(
                    ClockEntry(
                        section = ClockSection.CURRENCY,
                        srcDetailId = srcId,
                        specialtyId = sp,
                        dir = "لكم",
                        amount = tot0,
                        name = detail.initDetail.ifBlank { "التفصيل" },
                        date = from,
                        to = to,
                        cur = first.cur,
                        curAmount = first.a,
                        curRate = first.r,
                        rows = rs,
                        auto = true
                    )
                )
            }
        }

        return entries
    }
}

data class FifoOpenDebtRow(
    val date: String,
    val detailTitle: String,
    val customerName: String,
    val qty: Double,
    val grossAmount: Double,
    val remainingDebt: Double,
    val runningTotal: Double
)

object AutoDebtFifoCalculator {

    fun computeOpenDebts(debtClockEntries: List<ClockEntry>): List<FifoOpenDebtRow> {
        data class MutableDebt(
            val idx: Int,
            val date: String,
            val title: String,
            val name: String,
            val qty: Double,
            val gross: Double,
            var left: Double
        )
        data class RecPayment(val idx: Int, val name: String, val amount: Double)

        val debts = mutableListOf<MutableDebt>()
        val payments = mutableListOf<RecPayment>()

        debtClockEntries.forEachIndexed { idx, entry ->
            val dt = entry.date.ifBlank { entry.to }
            if (entry.kind == "debtsale") {
                entry.subRows.forEach { sr ->
                    val nm = sr.name.trim()
                    if (nm.isNotEmpty() && sr.rest > 1e-9) {
                        debts.add(
                            MutableDebt(
                                idx = idx,
                                date = dt,
                                title = entry.name,
                                name = nm,
                                qty = sr.qty,
                                gross = sr.amount,
                                left = sr.rest
                            )
                        )
                    }
                }
            } else if (entry.kind == "received") {
                entry.subRows.forEach { sr ->
                    val nm = sr.name.trim()
                    if (nm.isNotEmpty() && sr.amount > 1e-9) {
                        payments.add(RecPayment(idx = idx, name = nm, amount = sr.amount))
                    }
                }
            }
        }

        payments.forEach { pay ->
            var rem = pay.amount
            for (d in debts) {
                if (rem <= 1e-9) break
                if (d.idx < pay.idx && d.name == pay.name && d.left > 1e-9) {
                    val take = minOf(d.left, rem)
                    d.left -= take
                    rem -= take
                }
            }
        }

        var run = 0.0
        return debts
            .filter { it.left > 1e-9 }
            .map { d ->
                run += d.left
                FifoOpenDebtRow(
                    date = d.date,
                    detailTitle = d.title,
                    customerName = d.name,
                    qty = d.qty,
                    grossAmount = d.gross,
                    remainingDebt = round3(d.left),
                    runningTotal = round3(run)
                )
            }
    }
}
