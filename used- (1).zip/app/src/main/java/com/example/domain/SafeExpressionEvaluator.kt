package com.example.domain

/**
 * Pure Kotlin recursive-descent arithmetic expression evaluator matching the JS calculator popup.
 * Supports +, -, *, /, %, parentheses, unary +/-, and Arabic-Indic digit normalization.
 */
object SafeExpressionEvaluator {

    fun evaluate(rawExpression: String): Double? {
        val expr = WesternDigits.toWestern(rawExpression)
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(",", "")
            .replace(Regex("""\s+"""), "")
        if (expr.isEmpty()) return null
        return try {
            val parser = Parser(expr)
            val result = parser.parseExpression()
            if (parser.pos != expr.length || !result.isFinite()) null else result
        } catch (_: Exception) {
            null
        }
    }

    private class Parser(private val s: String) {
        var pos = 0

        fun parseExpression(): Double {
            var x = parseTerm()
            while (pos < s.length) {
                when (s[pos]) {
                    '+' -> {
                        pos++
                        x += parseTerm()
                    }
                    '-' -> {
                        pos++
                        x -= parseTerm()
                    }
                    else -> return x
                }
            }
            return x
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (pos < s.length) {
                when (s[pos]) {
                    '*' -> {
                        pos++
                        x *= parseFactor()
                    }
                    '/' -> {
                        pos++
                        val d = parseFactor()
                        if (d == 0.0) throw ArithmeticException("Division by zero")
                        x /= d
                    }
                    else -> return x
                }
            }
            return x
        }

        private fun parseFactor(): Double {
            if (pos >= s.length) throw IllegalArgumentException("Unexpected end")
            when (s[pos]) {
                '+' -> {
                    pos++
                    return parseFactor()
                }
                '-' -> {
                    pos++
                    return -parseFactor()
                }
            }
            var x: Double
            val startPos = pos
            if (s[pos] == '(') {
                pos++
                x = parseExpression()
                if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("Missing ')'")
                pos++
            } else if (s[pos] in '0'..'9' || s[pos] == '.') {
                while (pos < s.length && (s[pos] in '0'..'9' || s[pos] == '.')) {
                    pos++
                }
                x = s.substring(startPos, pos).toDoubleOrNull()
                    ?: throw IllegalArgumentException("Invalid number")
            } else {
                throw IllegalArgumentException("Unexpected char: ${s[pos]}")
            }

            while (pos < s.length && s[pos] == '%') {
                pos++
                x /= 100.0
            }
            return x
        }
    }
}
