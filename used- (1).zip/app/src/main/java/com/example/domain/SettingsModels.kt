package com.example.domain

data class ProfileSettings(
    val nameAr: String = "",
    val nameEn: String = "",
    val addressAr: String = "",
    val addressEn: String = "",
    val contacts: String = "",
    val contactsEn: String = "",
    val useFullHeader: Boolean = false,
    val logoPath: String = "",
    val stampPath: String = "",
    val signPath: String = "",
    val logoSize: Double = 1.0,
    val signSize: Double = 1.0,
    val stampSize: Double = 1.0
)

data class AppearanceSettings(
    val designType: String = "glassmorphism",
    val frameEnabled: Boolean = true,
    val frameColorEnabled: Boolean = true,
    val frameShapeEnabled: Boolean = true,
    val frameStyleEnabled: Boolean = true,
    val frameThicknessEnabled: Boolean = true,
    val frameColor: String = "gold", // "gold", "silver", "copper", "theme", or "#RRGGBB"
    val frameShape: String = "rounded", // square, soft, rounded, round, pill, circle
    val frameStyle: String = "solid", // solid, dashed, dotted, double, groove, ridge, inset, outset
    val frameThickness: String = "thin", // thin, medium, thick
    val buttonShape: String = "classic", // classic, rounded, simple
    val shadows: Boolean = true,
    val backgroundPath: String = "",
    val backgroundOpacity: Int = 100
)

data class MessageSettings(
    val sendMethod: String = "whatsapp", // "whatsapp" or "sms"
    val sendWhen: String = "confirm", // "auto", "confirm", "never"
    val globalMessageSettings: Boolean = true,
    val msgIntroEnabled: Boolean = true,
    val msgIntro: String = "",
    val msgEndEnabled: Boolean = true,
    val msgEnd: String = "",
    val payEnd: String = "الرجاء سرعة سداد ماعليكم مع كامل الشكر والاحترام",
    val msgFormatDebt: String = "عليكم",
    val msgFormatPay: String = "الرصيد لك",
    val messageFormat: String = "both", // "both", "pay", "debt"
    val messageContent: String = "text", // "text", "image"
    val sendDest: String = "phone", // "phone", "other"
    val waType: String = "business", // "green", "business"
    val countryCode: String = "+967",
    val lineKey: String = "empty", // "empty", "zero", "country"
    val imageSize: Double = 1.0,
    val paTiming: String = "confirm"
)

data class StampSettings(
    val vouchers: String = "sign", // sign, stamp, all, none
    val invoices: String = "sign",
    val statement: String = "sign",
    val balance: String = "sign"
)

data class LuxuryPrintSettings(
    val on: Boolean = false,
    val tpl: String = "",
    val style: String = "minimal",
    val shape: String = "box",
    val line: String = "solid",
    val btn: String = "simple",
    val btnT: String = "",
    val colT: String = "",
    val modT: String = "",
    val shadow: String = "off",
    val thick: String = "medium",
    val txtColor: String = "#111827",
    val txtLColor: String = "#15803d",
    val numLColor: String = "#15803d",
    val txtOColor: String = "#dc2626",
    val numOColor: String = "#dc2626",
    val txtTColor: String = "#0f172a",
    val numTColor: String = "#0f172a",
    val paperColor: String = "#ffffff",
    val frame: String = "",
    val bgPath: String = "",
    val clear: Int = 100
)

data class PrintSettings(
    val printMethod: String = "pdf", // "pdf" or "printer"
    val paperStatement: String = "a4", // a4, a3, 58, 80
    val paperVoucher: String = "a4", // a5, a4, a3, 58, 80
    val saleSortBy: String = "date", // name, amount, date
    val saleSortDir: String = "asc", // asc, desc
    val printColorMode: String = "color", // color, gray, bw
    val printColor: String = "#6B1A2F",
    val printFont: String = "cairo",
    val printFontScale: Int = 100,
    val printTextColor: String = "#111111",
    val currencyStmtHeader: Boolean = true,
    val currencyStmtSummary: Boolean = true,
    val currencyStmtList: List<String>? = null,
    val showHeaderData: Boolean = true,
    val repeatHeader: Boolean = true,
    val showPrintDate: Boolean = true,
    val showPrintTime: Boolean = true,
    val showAccountNote: Boolean = false,
    val showPhone: Boolean = false,
    val addNoteOnStatement: Boolean = false,
    val stampSettings: StampSettings = StampSettings(),
    val lux: LuxuryPrintSettings = LuxuryPrintSettings()
)

data class AppLockSettings(
    val enabled: Boolean = false,
    val pin: String = "",
    val biometric: Boolean = false,
    val autoLock: String = "1m" // "0", "30s", "1m", "5m", "15m"
)

data class DriveBackupHistoryItem(
    val filename: String = "",
    val dateIso: String = "",
    val sizeBytes: Long = 0L,
    val fileId: String = ""
)

data class DriveBackupSettings(
    val connected: Boolean = false,
    val email: String = "",
    val dataEnabled: Boolean = true,
    val dataInterval: String = "24h", // 6h, 12h, 24h, 7d
    val imagesBackupEnabled: Boolean = false,
    val imagesInterval: String = "daily", // daily, weekly, monthly
    val wifiOnly: Boolean = false,
    val backupOnExit: Boolean = false,
    val lastDataBackup: Long = 0L,
    val backupHistory: List<DriveBackupHistoryItem> = emptyList()
)

data class AppSettings(
    val lang: String = "ar",
    val dark: Boolean = false,
    val primaryColorHex: String = "#1e40af",
    val fontFamily: String = "tajawal", // default, cairo, tajawal, almarai, ibm
    val fontWeight: String = "medium", // light, medium, bold
    val fontSize: String = "medium", // small, medium, large
    val viewMode: String = "grid", // list, grid
    val multiCurrency: Boolean = true,
    val defaultCurrency: String = "ر.ي",
    val showInvoicesInFolders: Boolean = true,
    val longPressActions: Boolean = true,
    val activeSpecialty: String = "all",
    val buyerActiveSpecialty: String = "all",
    val fixedDebtCashboxId: String = "",
    val tasfeerFxAccId: String = "",
    val tasfeerComAccId: String = "",
    val tasfeerPass: String = "",
    val youtubeUrl: String = "",
    val supportPhone: String = "967773544574",
    val supportEmail: String = "",
    val termsText: String = "",
    val privacyText: String = "",
    val currencies: List<AppCurrency> = defaultCurrencies(),
    val specialties: List<Specialty> = emptyList(),
    val buyerSpecialties: List<Specialty> = emptyList(),
    val profile: ProfileSettings = ProfileSettings(),
    val appearance: AppearanceSettings = AppearanceSettings(),
    val messages: MessageSettings = MessageSettings(),
    val printing: PrintSettings = PrintSettings(),
    val appLock: AppLockSettings = AppLockSettings(),
    val gdriveBackup: DriveBackupSettings = DriveBackupSettings(),
    val savedNames: List<String> = emptyList()
) {
    companion object {
        fun defaultCurrencies(): List<AppCurrency> = listOf(
            AppCurrency(name = "ريال يمني", symbol = "ر.ي", sellRate = 1.0, buyRate = 1.0, fraction = 1.0, isDefault = true, subUnit = "فلس"),
            AppCurrency(name = "ريال سعودي", symbol = "ر.س", sellRate = 1.0, buyRate = 1.0, fraction = 1.0, isDefault = false, subUnit = "هللة"),
            AppCurrency(name = "ريال عماني", symbol = "ر.ع", sellRate = 1.0, buyRate = 1.0, fraction = 1.0, isDefault = false, subUnit = "بيسة"),
            AppCurrency(name = "درهم إماراتي", symbol = "د.إ", sellRate = 1.0, buyRate = 1.0, fraction = 1.0, isDefault = false, subUnit = "فلس"),
            AppCurrency(name = "دولار أمريكي", symbol = "$", sellRate = 1.0, buyRate = 1.0, fraction = 1.0, isDefault = false, subUnit = "سنت")
        )
    }
}

object ThemeCatalog {
    val paletteColors: List<Pair<String, String>> = listOf(
        "#1E40AF" to "الأزرق الملكي",
        "#071F4F" to "الكحلي الفاخر",
        "#6B1A2F" to "العنابي",
        "#0F766E" to "الزمردي الداكن",
        "#0369A1" to "السماوي العميق",
        "#4338CA" to "النيلي",
        "#7C2D12" to "النحاسي",
        "#B45309" to "الكهرماني الداكن",
        "#1D4ED8" to "أزرق حيوي",
        "#15803D" to "أخضر غابي",
        "#DC2626" to "القرمزي الحيوي",
        "#9333EA" to "الأرجواني",
        "#BE123C" to "الياقوتي الداكن",
        "#2F4F4F" to "الفحمي",
        "#A52A2A" to "البني",
        "#000080" to "الكحلي",
        "#4169E1" to "رويال بلو",
        "#87CEEB" to "السماوي",
        "#50C878" to "الزمردي",
        "#98FF98" to "النعناعي",
        "#808000" to "الزيتي",
        "#00FF00" to "الليموني",
        "#800000" to "الماروني",
        "#DC143C" to "القرمزي",
        "#FF7F50" to "المرجاني",
        "#E0115F" to "روبي",
        "#FF00FF" to "الفوشيا",
        "#E6E6FA" to "اللافندر",
        "#FFB6C1" to "الوردي الفاتح",
        "#FFD700" to "الذهبي",
        "#FFDB58" to "الخردلي",
        "#FFDAB9" to "المشمشي",
        "#FFBF00" to "الكهرماني",
        "#00FFFF" to "السيان / أكوا",
        "#D2691E" to "الشوكولاتة",
        "#F0E68C" to "الكاكي",
        "#FA8072" to "السلموني",
        "#40E0D0" to "التركوازي",
        "#DDA0DD" to "البرقوقي",
        "#DA70D6" to "الأوركيد",
        "#F5F5DC" to "البيج",
        "#D3D3D3" to "الرمادي الفاتح",
        "#000000" to "الأسود",
        "#FFFFFF" to "الأبيض"
    )

    val designTypes: List<Pair<String, String>> = listOf(
        "glassmorphism" to "Glassmorphism",
        "material3" to "Material Design 3",
        "luxury" to "Luxury UI",
        "bento" to "Bento Grid",
        "neumorphism" to "Neumorphism",
        "flat" to "Flat Design",
        "fluent" to "Fluent Design",
        "classic" to "Classic UI",
        "editorial" to "Editorial UI",
        "minimal" to "Minimal UI",
        "neobrutalism" to "Neobrutalism",
        "skeuomorphism" to "Skeuomorphism",
        "ui3d" to "3D UI",
        "futuristic" to "Futuristic UI",
        "hybrid" to "Hybrid UI"
    )
}
