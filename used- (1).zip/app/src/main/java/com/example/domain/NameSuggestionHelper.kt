package com.example.domain

object NameSuggestionHelper {

    private val DIACRITICS_REGEX = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]")
    private val WHITESPACE_REGEX = Regex("\\s+")

    private val IGNORED_BOILERPLATE = setOf(
        "بدون تخصيص",
        "حوالة مبيعات",
        "قيد بين الحسابات",
        "سحب",
        "ربح",
        "نقدي",
        "دين",
        "متعادل",
        "حسابات",
        "صندوق التوريد الرئيسي",
        "مجلد حسابات 1"
    )

    fun cleanDisplayName(raw: String): String =
        raw.trim().replace(WHITESPACE_REGEX, " ")

    fun extractWords(raw: String): List<String> =
        cleanDisplayName(raw).split(' ').filter { it.isNotBlank() }

    fun normalizeForSearch(raw: String): String {
        val cleaned = cleanDisplayName(raw)
        if (cleaned.isEmpty()) return ""
        val noDiacritics = DIACRITICS_REGEX.replace(cleaned, "")
        val sb = StringBuilder(noDiacritics.length)
        for (ch in noDiacritics) {
            val mapped = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                else -> ch.lowercaseChar()
            }
            sb.append(mapped)
        }
        return sb.toString()
    }

    fun isStorableName(raw: String): Boolean {
        val clean = cleanDisplayName(raw)
        if (clean.length < 2) return false
        if (!clean.any { it.isLetter() }) return false
        val words = extractWords(clean)
        if (words.isEmpty() || words.size > 5) return false
        val norm = normalizeForSearch(clean)
        if (IGNORED_BOILERPLATE.any { normalizeForSearch(it) == norm }) return false
        return true
    }

    fun addNamesToSaved(
        existing: List<String>,
        newNames: Collection<String>,
        maxCount: Int = 500
    ): List<String> {
        val validNew = newNames
            .map { cleanDisplayName(it) }
            .filter { isStorableName(it) }
        if (validNew.isEmpty()) return existing

        val seenNorms = HashSet<String>()
        val result = ArrayList<String>(minOf(maxCount, existing.size + validNew.size))

        // Add newest entered names first (if multiple passed, preserve order or latest)
        for (n in validNew.asReversed()) {
            val norm = normalizeForSearch(n)
            if (seenNorms.add(norm)) {
                result.add(n)
            }
        }
        for (old in existing) {
            val clean = cleanDisplayName(old)
            if (!isStorableName(clean)) continue
            val norm = normalizeForSearch(clean)
            if (seenNorms.add(norm)) {
                result.add(clean)
                if (result.size >= maxCount) break
            }
        }
        return result.take(maxCount)
    }

    fun removeName(existing: List<String>, target: String): List<String> {
        val targetNorm = normalizeForSearch(target)
        val targetClean = cleanDisplayName(target)
        return existing.filterNot { item ->
            val c = cleanDisplayName(item)
            c == targetClean || (targetNorm.isNotEmpty() && normalizeForSearch(c) == targetNorm)
        }
    }

    fun mergeSavedNames(
        explicitSaved: List<String>,
        harvestedFromSnapshot: Collection<String>,
        maxCount: Int = 600
    ): List<String> {
        val seenNorms = HashSet<String>()
        val result = ArrayList<String>(minOf(maxCount, explicitSaved.size + harvestedFromSnapshot.size))

        fun tryAdd(raw: String) {
            if (result.size >= maxCount) return
            val clean = cleanDisplayName(raw)
            if (!isStorableName(clean)) return
            val norm = normalizeForSearch(clean)
            if (seenNorms.add(norm)) {
                result.add(clean)
            }
        }

        explicitSaved.forEach(::tryAdd)
        harvestedFromSnapshot.forEach(::tryAdd)
        return result
    }

    fun wordCount(raw: String): Int = extractWords(raw).size

    /**
     * Suggests stored names matching [query], prioritizing 3-word names (الأسماء الثلاثية)
     * and supporting 1-, 2-, and 3-word prefix/token matching (e.g. "محمد ع ص" -> "محمد علي صالح").
     */
    fun suggestNames(
        query: String,
        savedNames: List<String>,
        limit: Int = 6
    ): List<String> {
        if (savedNames.isEmpty() || limit <= 0) return emptyList()

        val qClean = cleanDisplayName(query)
        val qNorm = normalizeForSearch(qClean)

        // Deduplicate input list while preserving recency order
        val unique = ArrayList<String>(savedNames.size)
        val seen = HashSet<String>()
        for (item in savedNames) {
            val clean = cleanDisplayName(item)
            if (!isStorableName(clean)) continue
            val norm = normalizeForSearch(clean)
            if (seen.add(norm)) unique.add(clean)
        }
        if (unique.isEmpty()) return emptyList()

        if (qNorm.isEmpty()) {
            // When input is empty and focused: surface recent 3-word names first, then 2/4-word, then 1-word
            return unique
                .mapIndexed { idx, name ->
                    val words = extractWords(name).size
                    val threeWordRank = when (words) {
                        3 -> 0
                        2, 4 -> 1
                        else -> 2
                    }
                    Triple(threeWordRank, idx, name)
                }
                .sortedWith(compareBy<Triple<Int, Int, String>> { it.first }.thenBy { it.second })
                .take(limit)
                .map { it.third }
        }

        val qWords = qNorm.split(' ').filter { it.isNotBlank() }

        data class RankedCandidate(
            val tier: Int,
            val threeWordRank: Int,
            val recencyIdx: Int,
            val name: String
        )

        val ranked = ArrayList<RankedCandidate>()
        unique.forEachIndexed { idx, candidate ->
            val cNorm = normalizeForSearch(candidate)
            if (cNorm == qNorm) return@forEachIndexed

            val cWords = cNorm.split(' ').filter { it.isNotBlank() }
            if (cWords.isEmpty()) return@forEachIndexed

            val tier = when {
                // Tier 0: Exact prefix of entire normalized name ("محمد ع" -> "محمد علي صالح")
                cNorm.startsWith(qNorm) -> 0
                // Tier 1: Ordered word-prefix matching up to N words ("م ع ص" or "محمد ع ص" -> "محمد علي صالح")
                qWords.size <= cWords.size && qWords.indices.all { i -> cWords[i].startsWith(qWords[i]) } -> 1
                // Tier 2: Unordered distinct word-prefix match ("صالح محمد" -> "محمد علي صالح")
                matchesUnorderedWordPrefixes(qWords, cWords) -> 2
                // Tier 3: Every query word appears as substring
                qWords.all { qt -> cNorm.contains(qt) } -> 3
                else -> -1
            }

            if (tier >= 0) {
                val threeWordRank = when (cWords.size) {
                    3 -> 0
                    2, 4 -> 1
                    else -> 2
                }
                ranked.add(RankedCandidate(tier, threeWordRank, idx, candidate))
            }
        }

        return ranked
            .sortedWith(
                compareBy<RankedCandidate> { it.tier }
                    .thenBy { it.threeWordRank }
                    .thenBy { it.recencyIdx }
            )
            .take(limit)
            .map { it.name }
    }

    private fun matchesUnorderedWordPrefixes(qWords: List<String>, cWords: List<String>): Boolean {
        if (qWords.size > cWords.size) return false
        val used = BooleanArray(cWords.size)
        for (qt in qWords) {
            var found = false
            for (i in cWords.indices) {
                if (!used[i] && cWords[i].startsWith(qt)) {
                    used[i] = true
                    found = true
                    break
                }
            }
            if (!found) return false
        }
        return true
    }
}
