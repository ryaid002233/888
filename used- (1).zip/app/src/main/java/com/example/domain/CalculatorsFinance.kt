package com.example.domain

import com.example.domain.WesternDigits.round2
import com.example.domain.WesternDigits.round3
import com.example.domain.WesternDigits.round6
import kotlin.math.abs

object ClockCalculator {
    fun signedAmount(entry: ClockEntry): Double {
        val a = abs(entry.amount)
        return if (entry.dir == "عليكم") -a else a
    }

    fun sectionTotal(entries: List<ClockEntry>, section: ClockSection): Double =
        entries.filter { it.section == section }.sumOf { signedAmount(it) }

    fun runningBalances(entries: List<ClockEntry>): Map<String, Double> {
        var run = 0.0
        val out = mutableMapOf<String, Double>()
        entries.sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp }).forEach { e ->
            run += signedAmount(e)
            out[e.id] = round3(run)
        }
        return out
    }
}

data class TasfeerFundCoverageError(
    val cur: String,
    val requested: Double,
    val available: Double
)

data class TasfeerGapSummary(
    val accountsTotal: Double,
    val fundsTotal: Double,
    val gap: Double,
    val side: String // "acc", "fund", "even"
)

data class TasfeerRecalcResult(
    val updatedVouchers: List<TsVoucher>,
    val fundCurrencyQty: Map<Pair<String, String>, Double>,
    val fundCurrencyVal: Map<Pair<String, String>, Double>,
    val accountBalances: Map<String, Double>,
    val fundValues: Map<String, Double>,
    val gapSummary: TasfeerGapSummary
)

object TasfeerFxEngine {

    private fun normalizeBaseCur(cur: String, currencies: List<AppCurrency>): String {
        val def = currencies.firstOrNull()?.name ?: "ريال يمني"
        return cur.trim().ifBlank { def }
    }

    private fun voucherRows(v: TsVoucher, baseCur: String): List<TsRowCurrency> {
        if (v.rows.isNotEmpty()) {
            return v.rows.map { r ->
                val cur = r.cur.trim().ifBlank { baseCur }
                val rate = if (cur == baseCur) 1.0 else if (r.r > 0.0) r.r else 1.0
                TsRowCurrency(cur = cur, a = r.a, r = rate)
            }
        }
        val cur = v.cur.trim().ifBlank { baseCur }
        val rate = if (cur == baseCur) 1.0 else if (v.rate > 0.0) v.rate else 1.0
        return if (v.amount > 0.0) listOf(TsRowCurrency(cur = cur, a = v.amount, r = rate)) else emptyList()
    }

    fun checkFundCoverage(
        existingVouchers: List<TsVoucher>,
        currencies: List<AppCurrency>,
        fundId: String,
        requestedByCur: Map<String, Double>,
        editingVoucherId: String? = null
    ): TasfeerFundCoverageError? {
        val baseCur = currencies.firstOrNull()?.name ?: "ريال يمني"
        val balances = mutableMapOf<String, Double>()
        existingVouchers
            .filter { it.id != editingVoucherId && !it.isFx && !it.isCom }
            .forEach { v ->
                when (v.kind) {
                    "receipt" -> if (v.fundId == fundId) {
                        val sgn = if (v.dir == "out") -1.0 else 1.0
                        voucherRows(v, baseCur).forEach { r ->
                            balances[r.cur] = (balances[r.cur] ?: 0.0) + sgn * r.a
                        }
                    }
                    "transfer" -> {
                        voucherRows(v, baseCur).forEach { r ->
                            if (v.fromFundId == fundId) {
                                balances[r.cur] = (balances[r.cur] ?: 0.0) - r.a
                            }
                            if (v.toFundId == fundId) {
                                balances[r.cur] = (balances[r.cur] ?: 0.0) + r.a
                            }
                        }
                    }
                    "internal" -> if (v.fromFundId == fundId) {
                        voucherRows(v, baseCur).forEach { r ->
                            balances[r.cur] = (balances[r.cur] ?: 0.0) - r.a
                        }
                    }
                    "exchange" -> if (v.fundId == fundId) {
                        val fc = v.fromCur.trim().ifBlank { baseCur }
                        val tc = v.toCur.trim().ifBlank { baseCur }
                        balances[fc] = (balances[fc] ?: 0.0) - v.fromAmt
                        balances[tc] = (balances[tc] ?: 0.0) + v.toAmt
                    }
                }
            }

        requestedByCur.forEach { (cur, req) ->
            val avail = balances[cur] ?: 0.0
            if (req > avail + 1e-6) {
                return TasfeerFundCoverageError(cur = cur, requested = req, available = avail.coerceAtLeast(0.0))
            }
        }
        return null
    }

    /**
     * Exact port of fxRecalc from app.js lines 5627-5660:
     * Replays all non-FX vouchers chronologically, maintains weighted average FX cost per (fund, currency),
     * generates FX profit/loss & commission auto-vouchers, and computes exact balances and Gap.
     */
    fun recalculate(
        accounts: List<TsAccount>,
        funds: List<TsFund>,
        vouchers: List<TsVoucher>,
        currencies: List<AppCurrency>,
        fxAccId: String,
        comAccId: String
    ): TasfeerRecalcResult {
        val baseCur = currencies.firstOrNull()?.name ?: "ريال يمني"
        val manualVouchers = vouchers
            .filter { !it.isFx && !it.isCom }
            .sortedWith(compareBy<TsVoucher> { it.date }.thenBy { it.createdAt })

        val qtyMap = mutableMapOf<Pair<String, String>, Double>()
        val valMap = mutableMapOf<Pair<String, String>, Double>()

        fun avgCost(fundId: String, cur: String): Double? {
            if (cur == baseCur) return 1.0
            val key = fundId to cur
            val q = qtyMap[key] ?: 0.0
            val v = valMap[key] ?: 0.0
            return if (q > 1e-9) v / q else null
        }

        fun addLot(fundId: String, cur: String, a: Double, costValue: Double) {
            if (fundId.isBlank() || cur.isBlank() || a <= 0.0) return
            val key = fundId to cur
            qtyMap[key] = (qtyMap[key] ?: 0.0) + a
            valMap[key] = (valMap[key] ?: 0.0) + costValue
        }

        fun sellRows(fundId: String, rows: List<TsRowCurrency>): Pair<Double, List<TsFxEntry>> {
            var diffSum = 0.0
            val fxEntries = mutableListOf<TsFxEntry>()
            rows.forEach { r ->
                val key = fundId to r.cur
                val avg = avgCost(fundId, r.cur)
                if (r.cur != baseCur && avg != null) {
                    val df = r.a * (r.r - avg)
                    diffSum += df
                    fxEntries.add(
                        TsFxEntry(
                            cur = r.cur,
                            amount = r.a,
                            avgCost = round3(avg),
                            sellRate = r.r,
                            diff = round2(df)
                        )
                    )
                }
                val newQ = (qtyMap[key] ?: 0.0) - r.a
                val costUsed = r.a * (avg ?: r.r)
                val newV = (valMap[key] ?: 0.0) - costUsed
                qtyMap[key] = if (newQ <= 1e-9) 0.0 else newQ
                valMap[key] = if (newQ <= 1e-9) 0.0 else newV
            }
            return round2(diffSum) to fxEntries
        }

        val generatedVouchers = mutableListOf<TsVoucher>()
        val fundLabel = funds.associate { it.id to it.name }

        manualVouchers.forEach { v ->
            val rows = voucherRows(v, baseCur)
            when (v.kind) {
                "receipt" -> {
                    if (v.dir == "out") {
                        val (diff, fxList) = sellRows(v.fundId, rows)
                        if (abs(diff) >= 0.01) {
                            generatedVouchers.add(
                                makeFxVoucher(v, diff, fxList, fxAccId, v.fundId, fundLabel[v.fundId] ?: "")
                            )
                        }
                    } else {
                        rows.forEach { r ->
                            addLot(v.fundId, r.cur, r.a, r.a * r.r)
                        }
                    }
                }
                "transfer" -> {
                    val (diff, fxList) = sellRows(v.fromFundId, rows)
                    if (abs(diff) >= 0.01) {
                        generatedVouchers.add(
                            makeFxVoucher(v, diff, fxList, fxAccId, v.fromFundId, fundLabel[v.fromFundId] ?: "")
                        )
                    }
                    rows.forEach { r ->
                        addLot(v.toFundId, r.cur, r.a, r.a * r.r)
                    }
                }
                "internal" -> {
                    val (diff, fxList) = sellRows(v.fromFundId, rows)
                    if (abs(diff) >= 0.01) {
                        generatedVouchers.add(
                            makeFxVoucher(v, diff, fxList, fxAccId, v.fromFundId, fundLabel[v.fromFundId] ?: "")
                        )
                    }
                    if (v.com > 0.0 && comAccId.isNotBlank()) {
                        generatedVouchers.add(
                            TsVoucher(
                                id = "com_${v.id}",
                                kind = "receipt",
                                dir = "in",
                                date = v.date,
                                time = v.time,
                                accId = comAccId,
                                cur = v.comCur.ifBlank { baseCur },
                                amount = v.com,
                                rate = 1.0,
                                note = "عمولة حوالة داخلية ${v.transferNo}".trim(),
                                isCom = true,
                                fxParentId = v.id,
                                createdAt = v.createdAt
                            )
                        )
                    }
                }
                "exchange" -> {
                    val fc = v.fromCur.trim().ifBlank { baseCur }
                    val tc = v.toCur.trim().ifBlank { baseCur }
                    val avg = avgCost(v.fundId, fc) ?: 1.0
                    val keyFrom = v.fundId to fc
                    val cost = v.fromAmt * avg
                    val newQ = (qtyMap[keyFrom] ?: 0.0) - v.fromAmt
                    val newV = (valMap[keyFrom] ?: 0.0) - cost
                    qtyMap[keyFrom] = if (newQ <= 1e-9) 0.0 else newQ
                    valMap[keyFrom] = if (newQ <= 1e-9) 0.0 else newV
                    addLot(v.fundId, tc, v.toAmt, cost)
                }
            }
        }

        val allVouchers = manualVouchers + generatedVouchers

        val accountBalances = accounts.associate { acc ->
            var bal = 0.0
            allVouchers.forEach { v ->
                val vTotal = voucherTotalBase(v, baseCur)
                when {
                    v.accId == acc.id && (v.kind == "receipt" || v.kind == "fx" || v.kind == "clockacc") -> {
                        bal += if (v.dir == "out") -vTotal else vTotal
                    }
                    v.accId == acc.id && v.kind == "internal" -> {
                        // Internal transfer from fund on account is always a debit on account (-tot)
                        bal += if (v.dir == "in") vTotal else -vTotal
                    }
                }
            }
            acc.id to round3(bal)
        }

        val fundValues = funds.associate { fund ->
            val sumVal = valMap.entries
                .filter { it.key.first == fund.id }
                .sumOf { it.value }
            fund.id to round3(sumVal)
        }

        val totalAcc = accountBalances.values.sum()
        val totalFunds = fundValues.values.sum()
        val gap = round3(totalAcc - totalFunds)
        val side = when {
            gap > 1e-6 -> "acc"
            gap < -1e-6 -> "fund"
            else -> "even"
        }

        return TasfeerRecalcResult(
            updatedVouchers = allVouchers,
            fundCurrencyQty = qtyMap,
            fundCurrencyVal = valMap,
            accountBalances = accountBalances,
            fundValues = fundValues,
            gapSummary = TasfeerGapSummary(
                accountsTotal = round3(totalAcc),
                fundsTotal = round3(totalFunds),
                gap = gap,
                side = side
            )
        )
    }

    fun voucherTotalBase(v: TsVoucher, baseCur: String): Double {
        val core = when {
            v.kind == "exchange" -> if (v.toAmt > 0.0) v.toAmt else v.amount
            v.rows.isNotEmpty() -> v.rows.sumOf { r ->
                val rate = if (r.cur.trim() == baseCur) 1.0 else if (r.r > 0.0) r.r else 1.0
                r.a * rate
            }
            else -> {
                val rate = if (v.cur.trim() == baseCur || v.cur.isBlank()) 1.0 else if (v.rate > 0.0) v.rate else 1.0
                v.amount * rate
            }
        }
        return if (v.kind == "internal") core + v.com else core
    }

    fun previewExpectedFxDiff(
        existingVouchers: List<TsVoucher>,
        funds: List<TsFund>,
        currencies: List<AppCurrency>,
        kind: String,
        fundId: String,
        rows: List<TsRowCurrency>,
        editingVoucherId: String? = null
    ): Double {
        if (fundId.isBlank() || rows.isEmpty()) return 0.0
        val tempId = "__fx_preview__"
        val baseList = existingVouchers.filter { it.id != editingVoucherId && !it.isFx && !it.isCom }
        val tempVoucher = TsVoucher(
            id = tempId,
            kind = kind,
            dir = "out",
            date = DateHelper.todayIso(),
            fundId = if (kind == "receipt") fundId else "",
            fromFundId = if (kind != "receipt") fundId else "",
            rows = rows,
            createdAt = Long.MAX_VALUE / 2
        )
        val res = recalculate(
            accounts = emptyList(),
            funds = funds,
            vouchers = baseList + tempVoucher,
            currencies = currencies,
            fxAccId = "",
            comAccId = ""
        )
        val fx = res.updatedVouchers.firstOrNull { it.fxParentId == tempId } ?: return 0.0
        return if (fx.dir == "out") -fx.amount else fx.amount
    }

    private fun makeFxVoucher(
        parent: TsVoucher,
        diff: Double,
        fxEntries: List<TsFxEntry>,
        fxAccId: String,
        sourceFundId: String,
        fundName: String
    ): TsVoucher {
        val isProfit = diff > 0.0
        val label = if (isProfit) "لكم ربح فارق صرف" else "عليكم خسارة فارق صرف"
        return TsVoucher(
            id = "fx_${parent.id}",
            kind = "fx",
            dir = if (isProfit) "in" else "out",
            date = parent.date,
            time = parent.time,
            accId = fxAccId,
            fundId = if (fxAccId.isBlank()) sourceFundId else "",
            amount = abs(diff),
            rate = 1.0,
            note = "$label ($fundName)",
            isFx = true,
            fxParentId = parent.id,
            fxFromLabel = fundName,
            fxDetail = fxEntries,
            createdAt = parent.createdAt
        )
    }
}

data class TransferSheetCalc(
    val oldTotal: Double,
    val exchange: Double,
    val newTotal: Double,
    val totalExpenses: Double,
    val diff: Double,
    val profitLabel: String
)

data class BuyerStatsSummary(
    val salesNet: Double,
    val profitSellerNet: Double,
    val profitSupplierNet: Double
)

object BuyerCalculators {

    fun calculateTransfer(sheet: BuyerTransferSheet): TransferSheetCalc {
        val oldTotal = round2(sheet.rows.sumOf { it.buy + it.exp })
        val exchange = if (sheet.oldPrice > 0.0) round6(oldTotal / sheet.oldPrice) else 0.0
        val newTotal = round2(exchange * sheet.newPrice)
        val totalExp = round2(newTotal + sheet.rentRada + sheet.rentShip)
        val diff = round2(sheet.weeklySale - totalExp)
        val label = when {
            diff > 1e-6 -> "ربح"
            diff < -1e-6 -> "خسارة"
            else -> "متوازن"
        }
        return TransferSheetCalc(
            oldTotal = oldTotal,
            exchange = exchange,
            newTotal = newTotal,
            totalExpenses = totalExp,
            diff = diff,
            profitLabel = label
        )
    }

    /**
     * Synchronizes Buyer Transfer Sheets -> Annual Folders -> BuyerSales + Seller/Supplier 50/50 Profit Split.
     */
    fun syncBuyerEcosystem(
        folders: List<WeekFolder>,
        specialties: List<Specialty>,
        transferSheets: List<BuyerTransferSheet>,
        existingAnnualFolders: List<BuyerAnnualFolder>,
        existingSales: List<BuyerSaleEntry>,
        existingProfits: List<BuyerProfitEntry>
    ): Triple<List<BuyerAnnualFolder>, List<BuyerSaleEntry>, List<BuyerProfitEntry>> {
        val buyerFolders = folders.filter { it.scope == FolderScope.BUYER }
        val specMap = specialties.associate { it.id to it.name }
        val manualAnnualRows = existingAnnualFolders
            .flatMap { af -> af.rows.filter { it.autoKey.isBlank() }.map { af.specialtyId to it } }
            .groupBy({ it.first }, { it.second })

        val autoRowsBySpec = mutableMapOf<String, MutableList<BuyerAnnualRow>>()

        transferSheets.forEach { ts ->
            val calc = calculateTransfer(ts)
            val folder = buyerFolders.firstOrNull { it.id == ts.folderId }
            val spId = ts.specialtyId.ifBlank { folder?.specialtyId ?: "" }
            val from = ts.fromDate.ifBlank { folder?.startDate ?: "" }
            val to = ts.toDate.ifBlank { folder?.endDate ?: from }
            val row = BuyerAnnualRow(
                id = "ar_${ts.id}",
                from = from,
                to = to,
                day = if (from.isNotBlank()) DateHelper.dayNameAr(from) else "",
                name = ts.name.ifBlank { folder?.name ?: "" },
                buy = calc.totalExpenses,
                sell = round2(ts.weeklySale),
                habba = ts.habbaCount,
                diff = calc.diff,
                profitLabel = when {
                    calc.diff > 1e-6 -> "ربح"
                    calc.diff < -1e-6 -> "خسارة"
                    else -> "0"
                },
                autoKey = "ts:${ts.id}"
            )
            autoRowsBySpec.getOrPut(spId) { mutableListOf() }.add(row)
        }

        val allSpecIds = (autoRowsBySpec.keys + manualAnnualRows.keys + buyerFolders.map { it.specialtyId }).distinct()
        val syncedAnnualFolders = allSpecIds.map { spId ->
            val existing = existingAnnualFolders.firstOrNull { it.specialtyId == spId }
            val combined = (autoRowsBySpec[spId].orEmpty() + manualAnnualRows[spId].orEmpty())
                .sortedBy { it.from }
            BuyerAnnualFolder(
                id = existing?.id ?: newId("baf"),
                specialtyId = spId,
                name = existing?.name?.takeIf { it.isNotBlank() } ?: (specMap[spId] ?: "كشف سنوي"),
                rows = combined,
                updatedAt = System.currentTimeMillis()
            )
        }

        // Rebuild auto sales & auto profit 50/50 split from annual rows
        val manualSales = existingSales.filter { !it.auto }
        val autoSales = mutableListOf<BuyerSaleEntry>()
        val manualProfits = existingProfits.filter { !it.autoProfit }
        val autoProfits = mutableListOf<BuyerProfitEntry>()

        syncedAnnualFolders.forEach { af ->
            af.rows.forEach { row ->
                val key = "${af.specialtyId}:${row.id}"
                if (row.sell > 0.0) {
                    autoSales.add(
                        BuyerSaleEntry(
                            id = "bsa_${row.id}",
                            dir = "لكم",
                            date = row.from.ifBlank { row.to },
                            from = row.from,
                            to = row.to,
                            amount = round2(row.sell),
                            qty = row.habba,
                            unitPrice = if (row.habba > 0.0) round2(row.sell / row.habba) else 0.0,
                            specialtyId = af.specialtyId,
                            note = row.name,
                            auto = true,
                            autoKey = key
                        )
                    )
                }
                val half = round2(abs(row.diff) / 2.0)
                if (half > 0.0) {
                    val isProfit = row.diff > 0.0
                    val kindStr = if (isProfit) "ربح" else "خسارة"
                    listOf("seller", "supplier").forEach { tgt ->
                        autoProfits.add(
                            BuyerProfitEntry(
                                id = "bpa_${tgt}_${row.id}",
                                target = tgt,
                                type = if (isProfit) "ربح" else "سحب",
                                kind = kindStr,
                                date = row.from.ifBlank { row.to },
                                from = row.from,
                                to = row.to,
                                amount = half,
                                specialtyId = af.specialtyId,
                                note = "${row.name} ($kindStr)",
                                autoProfit = true,
                                autoKey = key
                            )
                        )
                    }
                }
            }
        }

        return Triple(syncedAnnualFolders, autoSales + manualSales, autoProfits + manualProfits)
    }

    fun computeStats(sales: List<BuyerSaleEntry>, profits: List<BuyerProfitEntry>): BuyerStatsSummary {
        val sNet = sales.sumOf { if (it.dir == "لكم") it.amount else -it.amount }
        val sellerNet = profits.filter { it.target == "seller" }.sumOf {
            if (it.type == "سحب" || it.kind == "خسارة") -it.amount else it.amount
        }
        val supplierNet = profits.filter { it.target == "supplier" }.sumOf {
            if (it.type == "سحب" || it.kind == "خسارة") -it.amount else it.amount
        }
        return BuyerStatsSummary(
            salesNet = round2(sNet),
            profitSellerNet = round2(sellerNet),
            profitSupplierNet = round2(supplierNet)
        )
    }
}
