package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.data.AppDatabaseSnapshot
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

private val SubDark = Color(0xFF0B0D12)
private val SubCreamCard = Color(0xFFFAF6EC)
private val SubGold = Color(0xFFC5B17E)

@Composable
internal fun TsFundsTabContent(
    selectedFundId: String?,
    onSelectFund: (String?) -> Unit,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenReceipt: (String?, String?, TsVoucher?) -> Unit,
    onOpenTransfer: (String?, TsVoucher?) -> Unit,
    onOpenInternal: (String?, TsVoucher?) -> Unit,
    onOpenExchange: (String) -> Unit,
    onOpenFundEdit: (TsFund?) -> Unit,
    onOpenVoucherMenu: (TsVoucher) -> Unit
) {
    val snap = uiState.snapshot
    val tsState = uiState.tasfeerState
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val activity = LocalContext.current.findActivityOrNull()
    var showFundPrintDialog by remember { mutableStateOf(false) }

    if (selectedFundId == null) {
        val funds = remember(snap.tsFunds) { snap.tsFunds.sortedBy { it.order } }
        val totalFunds = funds.sumOf { tsState.fundValues[it.id] ?: 0.0 }
        val posSum = funds.map { tsState.fundValues[it.id] ?: 0.0 }.filter { it > 0 }.sum()
        val negSum = funds.map { tsState.fundValues[it.id] ?: 0.0 }.filter { it < 0 }.sumOf { abs(it) }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp)
        ) {
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("صناديق الصرافة (${funds.size})", fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                    val tokens = LocalFrameTokens.current
                    Button(
                        onClick = { onOpenFundEdit(null) },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        colors = ButtonDefaults.buttonColors(containerColor = tokens.barTop, contentColor = tokens.barContent),
                        modifier = Modifier.heightIn(min = 44.dp).testTag("ts_add_fund_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = tokens.barAccent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("صندوق جديد", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryStatCard("عليكم", fmt(negSum), AppColors.DebitRed, Modifier.weight(1f))
                    SummaryStatCard("لكم", fmt(posSum), AppColors.CreditGreen, Modifier.weight(1f))
                    SummaryStatCard(
                        "الباقي",
                        fmt(abs(totalFunds)),
                        if (totalFunds >= 0) AppColors.CreditGreen else AppColors.DebitRed,
                        Modifier.weight(1f)
                    )
                }
            }
            items(funds, key = { it.id }) { fund ->
                val valBase = tsState.fundValues[fund.id] ?: 0.0
                val curEntries = tsState.fundCurrencyQty.entries.filter { it.key.first == fund.id && abs(it.value) > 1e-6 }
                Surface(
                    onClick = { onSelectFund(fund.id) },
                    shape = RoundedCornerShape(14.dp),
                    color = SubCreamCard,
                    border = BorderStroke(1.2.dp, SubGold),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("🏦 ${fund.name}", fontWeight = FontWeight.Black, color = Color(0xFF0F172A), style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${fmt(abs(valBase))} ${if (valBase >= 0) "لكم" else "عليكم"}",
                                fontWeight = FontWeight.Black,
                                color = if (valBase >= 0) AppColors.CreditGreen else AppColors.DebitRed
                            )
                        }
                        if (curEntries.isNotEmpty()) {
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                curEntries.forEach { (pair, qty) ->
                                    Surface(shape = RoundedCornerShape(8.dp), color = Color.White, border = BorderStroke(1.dp, SubGold.copy(alpha = 0.6f))) {
                                        Text("${pair.second}: ${fmt(qty)}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                                    }
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                "ترحيل" to { onOpenTransfer(fund.id, null) },
                                "توريد" to { onOpenReceipt(fund.id, null, null) },
                                "حواله" to { onOpenInternal(fund.id, null) },
                                "تعديل" to { onOpenFundEdit(fund) }
                            ).forEach { (lbl, act) ->
                                OutlinedButton(
                                    onClick = act,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f).heightIn(min = 38.dp)
                                ) {
                                    Text(lbl, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        val fund = snap.tsFunds.firstOrNull { it.id == selectedFundId }
        if (fund == null) {
            onSelectFund(null)
            return
        }
        val fundTotal = tsState.fundValues[fund.id] ?: 0.0
        val fundVouchers = remember(tsState.updatedVouchers, fund.id) {
            tsState.updatedVouchers.filter { !it.isFx && !it.isCom && (it.fundId == fund.id || it.fromFundId == fund.id || it.toFundId == fund.id) }
                .sortedByDescending { it.createdAt }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp)
        ) {
            item {
                TsFundCurrencyTotalsHeaderCard(
                    fundName = fund.name,
                    currencies = uiState.settings.currencies,
                    fundCurrencyQty = tsState.fundCurrencyQty,
                    fundId = fund.id,
                    fundTotal = fundTotal
                )
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TsDarkActionBtn("💱 صرافة عملات", { onOpenExchange(fund.id) }, Modifier.weight(1f))
                        TsDarkActionBtn("➕ سند قبض", { onOpenReceipt(fund.id, null, null) }, Modifier.weight(1f))
                        TsDarkActionBtn("🔄 ترحيل", { onOpenTransfer(fund.id, null) }, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TsDarkActionBtn("📤 حواله", { onOpenInternal(fund.id, null) }, Modifier.weight(1f))
                        TsDarkActionBtn("🖨 كشف", { showFundPrintDialog = true }, Modifier.weight(1f))
                        TsDarkActionBtn("✏️ تعديل", { onOpenFundEdit(fund) }, Modifier.weight(1f))
                    }
                    TsDarkActionBtn("📥 معاملة قبض خاصة", { onOpenReceipt(fund.id, "إضافة سندات معاملة خاصة للصناديق", null) }, Modifier.fillMaxWidth())
                }
            }
            item {
                Text("📒 دفتر الحركات (${fundVouchers.size})", fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
            }
            items(fundVouchers, key = { it.id }) { v ->
                TsVoucherRowCard(v, snap, baseCur, false, onClick = { onOpenVoucherMenu(v) }, onLongClick = { onOpenVoucherMenu(v) })
            }
        }

        if (showFundPrintDialog) {
            var fromD by remember { mutableStateOf(DateHelper.yearStartIso()) }
            var toD by remember { mutableStateOf(DateHelper.yearEndIso()) }
            TsModalShell(title = "🖨 كشف ${fund.name}", onDismiss = { showFundPrintDialog = false }) {
                DateRangeBar(fromD, toD, onRangeChange = { f, t -> fromD = f; toD = t })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val html = PrintReportBuilders.buildTasfeerFundHtml(fund, tsState.updatedVouchers, uiState.settings.currencies, fromD, toD, false, uiState.settings)
                            viewModel.printHtmlReport(activity, "كشف ${fund.name}", html)
                            showFundPrintDialog = false
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("طباعة كشف") }
                    OutlinedButton(
                        onClick = {
                            val html = PrintReportBuilders.buildTasfeerFundHtml(fund, tsState.updatedVouchers, uiState.settings.currencies, fromD, toD, true, uiState.settings)
                            viewModel.printHtmlReport(activity, "مصادقة ${fund.name}", html)
                            showFundPrintDialog = false
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("طباعة مصادقة") }
                }
            }
        }
    }
}

@Composable
private fun TsFundCurrencyTotalsHeaderCard(
    fundName: String,
    currencies: List<AppCurrency>,
    fundCurrencyQty: Map<Pair<String, String>, Double>,
    fundId: String,
    fundTotal: Double
) {
    val currencyCells = remember(currencies, fundCurrencyQty, fundId) {
        val knownNames = currencies.map { it.name }.toSet()
        val configured = currencies.map { c ->
            c.symbol.ifBlank { c.name } to (fundCurrencyQty[fundId to c.name] ?: 0.0)
        }
        val extras = fundCurrencyQty.entries
            .filter { it.key.first == fundId && it.key.second !in knownNames && abs(it.value) > 1e-6 }
            .map { it.key.second to it.value }
        (configured + extras).ifEmpty { listOf("ر.ي" to 0.0) }
    }
    val stripShape = RoundedCornerShape(10.dp)
    val borderDark = Color(0xFF0F172A)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = SubCreamCard,
        border = BorderStroke(1.2.dp, SubGold),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth().testTag("ts_fund_header_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = fundName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = borderDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Surface(
                shape = stripShape,
                color = Color.White,
                border = BorderStroke(1.5.dp, borderDark),
                modifier = Modifier.fillMaxWidth().testTag("ts_fund_totals_strip")
            ) {
                BoxWithConstraints(
                    modifier = Modifier.fillMaxWidth().clip(stripShape)
                ) {
                    val minCurWidth = 68.dp
                    val minTotalWidth = 98.dp
                    val neededWidth = (minCurWidth * currencyCells.size) + minTotalWidth + (1.dp * currencyCells.size)
                    val useScroll = maxWidth < neededWidth

                    Row(
                        modifier = (if (useScroll) {
                            Modifier.horizontalScroll(rememberScrollState())
                        } else {
                            Modifier.fillMaxWidth()
                        }).height(IntrinsicSize.Min)
                    ) {
                        currencyCells.forEach { (symbol, qty) ->
                            Column(
                                modifier = (if (useScroll) Modifier.widthIn(min = 76.dp) else Modifier.weight(1f))
                                    .fillMaxHeight()
                                    .padding(horizontal = 6.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = symbol,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF475569),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = fmt(abs(qty), maxDecimals = 2, minDecimals = 2),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = borderDark,
                                    maxLines = 1,
                                    softWrap = false
                                )
                                if (qty > 1e-6) {
                                    Text(
                                        text = "لكم",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AppColors.CreditGreen,
                                        maxLines = 1
                                    )
                                } else if (qty < -1e-6) {
                                    Text(
                                        text = "عليكم",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AppColors.DebitRed,
                                        maxLines = 1
                                    )
                                }
                            }
                            VerticalDivider(
                                modifier = Modifier.fillMaxHeight(),
                                thickness = 1.dp,
                                color = borderDark
                            )
                        }

                        val isDebit = fundTotal < -1e-6
                        Column(
                            modifier = (if (useScroll) Modifier.widthIn(min = 108.dp) else Modifier.weight(1.3f))
                                .fillMaxHeight()
                                .background(if (isDebit) Color(0xFFFEF2F2) else Color(0xFFEAF2FF))
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (isDebit) "الناتج عليكم" else "الناتج لكم",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDebit) AppColors.DebitRed else Color(0xFF1E293B),
                                maxLines = 1
                            )
                            Text(
                                text = fmt(abs(fundTotal), maxDecimals = 2, minDecimals = 2),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isDebit) AppColors.DebitRed else borderDark,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun TsDarkActionBtn(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
        modifier = modifier.heightIn(min = 44.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.background(tokens.darkTileBrush).padding(horizontal = 6.dp, vertical = 8.dp)) {
            Text(label, color = tokens.darkTileContent, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TsAccountsTabContent(
    selectedFolderId: String?,
    selectedAccountId: String?,
    onSelectFolder: (String?) -> Unit,
    onSelectAccount: (String?) -> Unit,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenFolderEdit: (TsFolder?) -> Unit,
    onOpenAccountEdit: (String, TsAccount?) -> Unit,
    onOpenStats: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenVoucherEdit: (TsVoucher) -> Unit,
    onOpenVoucherView: (TsVoucher) -> Unit
) {
    val snap = uiState.snapshot
    val tsState = uiState.tasfeerState
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val activity = LocalContext.current.findActivityOrNull()
    val haptic = LocalHapticFeedback.current

    if (selectedAccountId != null) {
        val acc = snap.tsAccounts.firstOrNull { it.id == selectedAccountId }
        if (acc == null) { onSelectAccount(null); return }
        var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
        var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
        var sortField by remember { mutableStateOf(DebtSortField.DATE) }
        var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
        var selectAll by remember { mutableStateOf(false) }

        val accVouchers = remember(tsState.updatedVouchers, acc.id, uiState.settings.activeSpecialty, fromDate, toDate, sortField, sortDir) {
            tsState.updatedVouchers.filter { it.accId == acc.id }
                .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.activeSpecialty) }
                .filter { (fromDate.isBlank() || it.date >= fromDate) && (toDate.isBlank() || it.date <= toDate) }
                .let { list ->
                    val cmp = when (sortField) {
                        DebtSortField.DATE -> compareBy<TsVoucher> { it.date }.thenBy { it.createdAt }
                        DebtSortField.NAME -> compareBy<TsVoucher> { it.note.ifBlank { it.kind } }
                        DebtSortField.AMOUNT -> compareBy<TsVoucher> { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
                    }
                    if (sortDir == DebtSortDir.ASC) list.sortedWith(cmp) else list.sortedWith(cmp.reversed())
                }
        }
        val payTot = accVouchers.filter { it.dir != "out" && it.kind != "internal" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
        val debtTot = accVouchers.filter { it.dir == "out" || it.kind == "internal" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }

        // Running balances chronological
        val runMap = remember(tsState.updatedVouchers, acc.id) {
            var run = 0.0
            val m = mutableMapOf<String, Double>()
            tsState.updatedVouchers.filter { it.accId == acc.id }
                .sortedWith(compareBy<TsVoucher> { it.date }.thenBy { it.createdAt })
                .forEach { v ->
                    val t = TasfeerFxEngine.voucherTotalBase(v, baseCur)
                    val isOut = v.dir == "out" || v.kind == "internal"
                    run += if (isOut) -t else t
                    m[v.id] = run
                }
            m
        }

        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DebtsControlStrip(
                specialties = uiState.settings.specialties,
                activeSpecialty = uiState.settings.activeSpecialty,
                onSelectSpecialty = viewModel::setHomeSpecialty,
                onAddSpecialty = viewModel::addHomeSpecialty,
                selectAllChecked = selectAll,
                onToggleSelectAll = { selectAll = !selectAll },
                totals = DebtTotals(pay = payTot, debt = debtTot),
                sortField = sortField,
                sortDir = sortDir,
                onSortFieldChange = { sortField = it },
                onSortDirChange = { sortDir = it },
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t }
            )
            if (acc.phone.isNotBlank() || acc.limitAmount > 0.0) {
                Surface(shape = RoundedCornerShape(10.dp), color = SubCreamCard, border = BorderStroke(1.dp, SubGold), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        if (acc.phone.isNotBlank()) Text("📞 ${acc.phone}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (acc.limitAmount > 0.0) Text("السقف: ${fmt(acc.limitAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppColors.DebitRed)
                    }
                }
            }
            // 4-Column Statement Table Header matching accTable
            Surface(color = SubDark, shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp)) {
                    Text("النوع", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.7f))
                    Text("المبلغ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Text("التفصيل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1.7f))
                    Text("الرصيد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                }
            }
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(accVouchers, key = { it.id }) { v ->
                    val tot = TasfeerFxEngine.voucherTotalBase(v, baseCur)
                    val isOut = v.dir == "out" || v.kind == "internal"
                    val bal = runMap[v.id] ?: 0.0
                    Surface(shape = RoundedCornerShape(8.dp), color = Color.White, border = BorderStroke(1.dp, SubGold.copy(alpha = 0.5f)), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 6.dp, vertical = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (isOut) "عليكم" else "لكم", color = if (isOut) AppColors.DebitRed else AppColors.CreditGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.7f))
                                Text(fmt(tot), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                                Column(modifier = Modifier.weight(1.7f)) {
                                    Text(v.note.ifBlank { if (v.kind == "clockacc") v.pg else v.kind }, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(DateHelper.displaySlash(v.date), fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                                Text(
                                    "${if (bal < 0) "عليكم " else "لكم "}${fmt(abs(bal))}",
                                    fontWeight = FontWeight.Bold, fontSize = 11.sp,
                                    color = if (bal < 0) AppColors.DebitRed else AppColors.CreditGreen,
                                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                                )
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                if (v.img.isNotBlank()) IconButton({ onOpenVoucherView(v) }, Modifier.size(34.dp)) { Icon(Icons.Default.Photo, "صورة", Modifier.size(16.dp)) }
                                IconButton({
                                    val txt = viewModel.buildAccountMessageText(acc.name, if (isOut) "عليكم" else "لكم", tot, baseCur, v.note, bal, bal >= 0)
                                    viewModel.sendAccountMessage(acc.phone, txt)
                                }, Modifier.size(34.dp)) { Icon(Icons.Default.Share, "إرسال", Modifier.size(16.dp)) }
                                IconButton({
                                    val html = PrintReportBuilders.buildTasfeerSingleVoucherHtml(v, snap.tsAccounts, snap.tsFunds, uiState.settings)
                                    viewModel.printHtmlReport(activity, "سند ${acc.name}", html, isVoucher = true)
                                }, Modifier.size(34.dp)) { Icon(Icons.Default.Print, "طباعة", Modifier.size(16.dp)) }
                                IconButton({
                                    if (v.isFx || v.isCom) viewModel.emitMessage("قيد تلقائي من فارق الصرف/العمولة — لا يعدل يدوياً")
                                    else onOpenVoucherEdit(v)
                                }, Modifier.size(34.dp)) { Icon(Icons.Default.Edit, "تعديل", Modifier.size(16.dp)) }
                                IconButton({ viewModel.deleteTsVoucher(v.id) }, Modifier.size(34.dp)) { Icon(Icons.Default.Delete, "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    if (selectedFolderId != null) {
        val folder = snap.tsFolders.firstOrNull { it.id == selectedFolderId }
        if (folder == null) { onSelectFolder(null); return }
        var search by remember { mutableStateOf("") }
        var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
        var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
        var sortField by remember { mutableStateOf(DebtSortField.NAME) }
        var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
        var selectAll by remember { mutableStateOf(false) }
        var menuAccount by remember { mutableStateOf<TsAccount?>(null) }
        var moveCopyMode by remember { mutableStateOf<Pair<TsAccount, Boolean>?>(null) }

        val folderAccounts = remember(snap.tsAccounts, folder.id, search, sortField, sortDir, tsState.accountBalances) {
            snap.tsAccounts.filter { it.folderId == folder.id }
                .filter { search.isBlank() || it.name.contains(search, true) || it.phone.contains(search, true) }
                .let { list ->
                    val cmp = when (sortField) {
                        DebtSortField.DATE -> compareBy<TsAccount> { it.name }
                        DebtSortField.NAME -> compareBy<TsAccount> { it.name }
                        DebtSortField.AMOUNT -> compareBy<TsAccount> { abs(tsState.accountBalances[it.id] ?: 0.0) }
                    }
                    if (sortDir == DebtSortDir.ASC) list.sortedWith(cmp) else list.sortedWith(cmp.reversed())
                }
        }
        val posF = folderAccounts.map { tsState.accountBalances[it.id] ?: 0.0 }.filter { it > 0 }.sum()
        val negF = folderAccounts.map { tsState.accountBalances[it.id] ?: 0.0 }.filter { it < 0 }.sumOf { abs(it) }

        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DebtsControlStrip(
                    specialties = uiState.settings.specialties,
                    activeSpecialty = uiState.settings.activeSpecialty,
                    onSelectSpecialty = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    selectAllChecked = selectAll,
                    onToggleSelectAll = { selectAll = !selectAll },
                    totals = DebtTotals(pay = posF, debt = negF),
                    sortField = sortField,
                    sortDir = sortDir,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortDir = it },
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    placeholder = { Text("بحث في الحسابات...") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(folderAccounts, key = { it.id }) { acc ->
                        val bal = tsState.accountBalances[acc.id] ?: 0.0
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = SubCreamCard,
                            border = BorderStroke(1.2.dp, SubGold),
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).combinedClickable(
                                onClick = { onSelectAccount(acc.id) },
                                onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); menuAccount = acc }
                            )
                        ) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.size(40.dp).clip(CircleShape).background(SubDark), contentAlignment = Alignment.Center) {
                                    Text(acc.name.take(1).ifBlank { "ح" }, color = SubGold, fontWeight = FontWeight.Black)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(acc.name, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                    if (acc.phone.isNotBlank()) Text(acc.phone, fontSize = 11.sp, color = Color(0xFF64748B))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(fmt(abs(bal)), fontWeight = FontWeight.Black, color = if (bal >= 0) AppColors.CreditGreen else AppColors.DebitRed)
                                    Text(if (bal > 1e-6) "لكم" else if (bal < -1e-6) "عليكم" else "متعادل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
                                }
                            }
                        }
                    }
                }
            }
            FloatingActionButton(
                onClick = { onOpenAccountEdit(folder.id, null) },
                containerColor = SubDark, contentColor = SubGold,
                modifier = Modifier.align(rightBottomAlignment()).padding(16.dp).testTag("ts_add_acc_fab")
            ) { Icon(Icons.Default.PersonAdd, contentDescription = "إضافة حساب") }
        }

        menuAccount?.let { acc ->
            TsModalShell(title = acc.name, onDismiss = { menuAccount = null }) {
                listOf(
                    "✏️ تعديل الحساب" to { onOpenAccountEdit(folder.id, acc); menuAccount = null },
                    "🖨️ طباعة كشف" to {
                        val html = PrintReportBuilders.buildTasfeerAccountHtml(acc, tsState.updatedVouchers, uiState.settings.currencies, false, uiState.settings)
                        viewModel.printHtmlReport(activity, acc.name, html); menuAccount = null
                    },
                    "📝 طباعة مصادقة" to {
                        val html = PrintReportBuilders.buildTasfeerAccountHtml(acc, tsState.updatedVouchers, uiState.settings.currencies, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة ${acc.name}", html); menuAccount = null
                    },
                    "📋 نسخ إلى مجلد آخر" to { moveCopyMode = acc to false; menuAccount = null },
                    "✂️ نقل إلى مجلد آخر" to { moveCopyMode = acc to true; menuAccount = null },
                    "🗑 حذف الحساب" to { viewModel.deleteTsAccount(acc.id); menuAccount = null }
                ).forEach { (lbl, act) ->
                    OutlinedButton(onClick = act, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text(lbl, fontWeight = FontWeight.Bold) }
                }
            }
        }

        moveCopyMode?.let { (acc, isMove) ->
            TsModalShell(title = if (isMove) "نقل ${acc.name}" else "نسخ ${acc.name}", onDismiss = { moveCopyMode = null }) {
                snap.tsFolders.filter { it.id != folder.id }.forEach { f ->
                    Button(
                        onClick = { viewModel.copyOrMoveTsAccount(acc, f.id, isMove); moveCopyMode = null },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) { Text(f.name) }
                }
            }
        }
        return
    }

    // Folders Grid View
    val folders = remember(snap.tsFolders) { snap.tsFolders.sortedBy { it.order } }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TsDarkActionBtn("📁 إضافة مجلد حسابات", { onOpenFolderEdit(null) }, Modifier.weight(1.3f))
            TsDarkActionBtn("📊 الإحصائيات", onOpenStats, Modifier.weight(0.9f))
            TsDarkActionBtn("🔍 البحث السريع", onOpenSearch, Modifier.weight(1f))
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(folders, key = { it.id }) { fol ->
                val fAccs = snap.tsAccounts.filter { it.folderId == fol.id }
                val fNet = fAccs.sumOf { tsState.accountBalances[it.id] ?: 0.0 }
                Surface(
                    onClick = { onSelectFolder(fol.id) },
                    shape = RoundedCornerShape(14.dp),
                    color = SubCreamCard,
                    border = BorderStroke(1.2.dp, SubGold),
                    shadowElevation = 2.dp
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            if (fol.img.isNotBlank() && File(fol.img).exists()) {
                                Image(rememberAsyncImagePainter(File(fol.img)), fol.name, contentScale = ContentScale.Crop, modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)))
                            } else {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFB45309))
                            }
                            IconButton(onClick = { onOpenFolderEdit(fol) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل المجلد", modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(fol.name, fontWeight = FontWeight.Black, color = Color(0xFF0F172A), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${fAccs.size} حساب", fontSize = 11.sp, color = Color(0xFF64748B))
                        Text(
                            "${fmt(abs(fNet))} ${if (fNet > 1e-6) "لكم" else if (fNet < -1e-6) "عليكم" else ""}",
                            fontWeight = FontWeight.Bold,
                            color = if (fNet > 1e-6) AppColors.CreditGreen else if (fNet < -1e-6) AppColors.DebitRed else Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun TsVouchersTabContent(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenVoucherMenu: (TsVoucher) -> Unit
) {
    val snap = uiState.snapshot
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val all = remember(uiState.tasfeerState.updatedVouchers) {
        uiState.tasfeerState.updatedVouchers.sortedByDescending { it.createdAt }
    }
    var selMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("كافة السندات (${all.size})", fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
            TextButton(onClick = { selMode = !selMode; if (!selMode) selectedIds = emptySet() }) {
                Text(if (selMode) "إلغاء التحديد" else "تحديد متعدد")
            }
        }
        if (selMode) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { selectedIds = all.map { it.id }.toSet() }, modifier = Modifier.weight(1f)) { Text("تحديد الكل") }
                Button(
                    onClick = { viewModel.deleteTsVouchers(selectedIds.toList()); selectedIds = emptySet(); selMode = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AppColors.DebitRed),
                    modifier = Modifier.weight(1f)
                ) { Text("حذف المحدد (${selectedIds.size})") }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(all, key = { it.id }) { v ->
                val isSel = v.id in selectedIds
                TsVoucherRowCard(
                    v = v, snap = snap, baseCur = baseCur, selected = isSel,
                    onClick = {
                        if (selMode) selectedIds = if (isSel) selectedIds - v.id else selectedIds + v.id
                        else onOpenVoucherMenu(v)
                    },
                    onLongClick = { selMode = true; selectedIds = selectedIds + v.id }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TsVoucherRowCard(
    v: TsVoucher,
    snap: AppDatabaseSnapshot,
    baseCur: String,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val tot = TasfeerFxEngine.voucherTotalBase(v, baseCur)
    val isOut = v.dir == "out" || v.kind == "internal"
    val kindName = when {
        v.isFx -> "فارق صرف"
        v.isCom -> "عمولة حوالة"
        v.kind == "clockacc" -> "سند المراقب (${v.pg})"
        v.kind == "internal" -> "حوالة داخلية"
        v.kind == "transfer" -> "ترحيل بين الصناديق"
        v.kind == "exchange" -> "صرافة عملات"
        else -> if (isOut) "سند صرف" else "سند قبض"
    }
    val accName = snap.tsAccounts.firstOrNull { it.id == v.accId }?.name ?: ""
    val fundName = snap.tsFunds.firstOrNull { it.id == v.fundId || it.id == v.fromFundId }?.name ?: ""
    val haptic = LocalHapticFeedback.current

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFFE0F2FE) else SubCreamCard,
        border = BorderStroke(1.2.dp, if (selected) Color(0xFF0284C7) else SubGold),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(
            onClick = onClick,
            onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onLongClick() }
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(kindName, fontWeight = FontWeight.Black, color = Color(0xFF0F172A), fontSize = 13.sp)
                val sub = listOfNotNull(fundName.takeIf { it.isNotBlank() }, accName.takeIf { it.isNotBlank() }, v.note.takeIf { it.isNotBlank() }).joinToString(" • ")
                if (sub.isNotBlank()) Text(sub, fontSize = 12.sp, color = Color(0xFF334155), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(DateHelper.displaySlash(v.date), fontSize = 11.sp, color = Color(0xFF64748B))
            }
            Text(fmt(tot), fontWeight = FontWeight.Black, color = if (isOut) AppColors.DebitRed else AppColors.CreditGreen)
        }
    }
}

@Composable
internal fun TsMoreTabContent(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel
) {
    val snap = uiState.snapshot
    val sett = uiState.settings
    var showResetConfirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = SubCreamCard, border = BorderStroke(1.dp, SubGold), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("إعدادات الترحيل التلقائي", fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                TsDropdownField(
                    label = "حساب فارق الصرافة",
                    selectedText = snap.tsAccounts.firstOrNull { it.id == sett.tasfeerFxAccId }?.name ?: "بدون",
                    options = listOf("" to "بدون") + snap.tsAccounts.map { it.id to it.name },
                    onSelect = { id -> viewModel.updateSettings { it.copy(tasfeerFxAccId = id) } }
                )
                TsDropdownField(
                    label = "حساب عمولة الحوالة",
                    selectedText = snap.tsAccounts.firstOrNull { it.id == sett.tasfeerComAccId }?.name ?: "بدون",
                    options = listOf("" to "بدون") + snap.tsAccounts.map { it.id to it.name },
                    onSelect = { id -> viewModel.updateSettings { it.copy(tasfeerComAccId = id) } }
                )
            }
        }
        Button(
            onClick = { showResetConfirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = AppColors.DebitRed, contentColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
        ) {
            Icon(Icons.Default.DeleteForever, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("🗑 تصفير بيانات الصرافة", fontWeight = FontWeight.Bold)
        }
    }

    if (showResetConfirm) {
        ConfirmActionDialog(
            title = "تصفير بيانات الصرافة",
            message = "هل أنت متأكد من حذف جميع السندات والحسابات والمجلدات والصناديق في الصرافة؟",
            confirmText = "تصفير",
            onConfirm = { viewModel.resetTasfeerAll(); showResetConfirm = false },
            onDismiss = { showResetConfirm = false }
        )
    }
}
