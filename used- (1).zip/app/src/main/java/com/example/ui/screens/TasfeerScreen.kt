package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.findActivityOrNull
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

private val TsCanvasTop = Color(0xFFE7E0CB)
private val TsCanvasBot = Color(0xFFD6CCB0)
private val TsDarkHeaderBg = Color(0xFF0B0D12)
private val TsGold = Color(0xFFC5B17E)
private val TsCreamCard = Color(0xFFFAF6EC)

private sealed class TsActiveDialog {
    data class Receipt(val fundId: String? = null, val titleOverride: String? = null, val existing: TsVoucher? = null) : TsActiveDialog()
    data class ClockAcc(val existing: TsVoucher? = null) : TsActiveDialog()
    data class Internal(val fundId: String? = null, val existing: TsVoucher? = null) : TsActiveDialog()
    data class Transfer(val fundId: String? = null, val existing: TsVoucher? = null) : TsActiveDialog()
    data class Exchange(val fundId: String) : TsActiveDialog()
    data class FundEdit(val existing: TsFund?) : TsActiveDialog()
    data class FolderEdit(val existing: TsFolder?) : TsActiveDialog()
    data class AccountEdit(val folderId: String, val existing: TsAccount?) : TsActiveDialog()
    data class VoucherMenu(val v: TsVoucher) : TsActiveDialog()
    data class VoucherView(val v: TsVoucher) : TsActiveDialog()
    data object Gap : TsActiveDialog()
    data object Stats : TsActiveDialog()
    data object Search : TsActiveDialog()
}

@Composable
fun TasfeerScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val snap = uiState.snapshot
    val tsState = uiState.tasfeerState
    val gap = tsState.gapSummary

    var passUnlocked by remember(uiState.settings.tasfeerPass) {
        mutableStateOf(uiState.settings.tasfeerPass.isBlank())
    }
    var passInput by remember { mutableStateOf("") }
    var passErr by remember { mutableStateOf(false) }

    if (!passUnlocked) {
        BackHandler(onBack = onBack)
        Column(
            modifier = Modifier.fillMaxSize().background(TsCreamCard).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(48.dp), tint = TsDarkHeaderBg)
            Spacer(Modifier.height(12.dp))
            Text(strings.t("أدخل كلمة مرور الصرافة", "Enter Exchange Passcode"), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = passInput,
                onValueChange = { passInput = it; passErr = false },
                label = { Text(strings.t("كلمة المرور", "Passcode")) },
                isError = passErr,
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onBack) { Text(strings.cancel) }
                Button(onClick = { if (passInput == uiState.settings.tasfeerPass) passUnlocked = true else passErr = true }) {
                    Text(strings.confirm)
                }
            }
        }
        return
    }

    // Tabs: 0=الرئيسية, 1=الصناديق, 2=الحسابات, 3=السندات, 4=المزيد
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedFundId by remember { mutableStateOf<String?>(null) }
    var selectedFolderId by remember { mutableStateOf<String?>(null) }
    var selectedAccountId by remember { mutableStateOf<String?>(null) }
    var activeDialog by remember { mutableStateOf<TsActiveDialog?>(null) }

    val handleStepBack: () -> Unit = {
        when {
            selectedAccountId != null -> selectedAccountId = null
            selectedFolderId != null -> selectedFolderId = null
            selectedFundId != null -> selectedFundId = null
            selectedTab != 0 -> selectedTab = 0
            else -> onBack()
        }
    }
    BackHandler(onBack = handleStepBack)

    val pageLabel = when {
        selectedAccountId != null -> snap.tsAccounts.firstOrNull { it.id == selectedAccountId }?.name ?: "الحساب"
        selectedFolderId != null -> snap.tsFolders.firstOrNull { it.id == selectedFolderId }?.name ?: "صفحة مجلد الحساب"
        selectedFundId != null -> snap.tsFunds.firstOrNull { it.id == selectedFundId }?.name ?: "داخل الصندوق"
        selectedTab == 0 -> "الرئيسية"
        selectedTab == 1 -> "الصناديق"
        selectedTab == 2 -> "صفحة الحسابات"
        selectedTab == 3 -> "السندات"
        else -> "المزيد"
    }

    val tokens = LocalFrameTokens.current
    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            Surface(color = Color.Transparent, shadowElevation = tokens.elevation, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.background(tokens.barBrush).statusBarsPadding()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = handleStepBack,
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            color = tokens.barButtonBg,
                            border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                            modifier = Modifier.size(44.dp).testTag("ts_back_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = strings.t("رجوع", "Back"),
                                    tint = tokens.barContent
                                )
                            }
                        }

                        Text(
                            text = pageLabel,
                            color = tokens.barContent,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (selectedAccountId != null) {
                                val acc = snap.tsAccounts.firstOrNull { it.id == selectedAccountId }
                                if (acc != null) {
                                    TsHeaderMiniBtn("🖨️") {
                                        val html = PrintReportBuilders.buildTasfeerAccountHtml(acc, tsState.updatedVouchers, uiState.settings.currencies, false, uiState.settings)
                                        viewModel.printHtmlReport(activity, acc.name, html)
                                    }
                                    TsHeaderMiniBtn("📝") {
                                        val html = PrintReportBuilders.buildTasfeerAccountHtml(acc, tsState.updatedVouchers, uiState.settings.currencies, true, uiState.settings)
                                        viewModel.printHtmlReport(activity, "مصادقة ${acc.name}", html)
                                    }
                                }
                            } else if (selectedFundId != null) {
                                val fund = snap.tsFunds.firstOrNull { it.id == selectedFundId }
                                if (fund != null) {
                                    TsHeaderMiniBtn("🖨️") {
                                        val html = PrintReportBuilders.buildTasfeerFundHtml(fund, tsState.updatedVouchers, uiState.settings.currencies, "", "", false, uiState.settings)
                                        viewModel.printHtmlReport(activity, fund.name, html)
                                    }
                                }
                            }
                            Text("الصرافة", color = tokens.barContent, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        }
                    }
                    if (tokens.frameEnabled && tokens.frameStyle != "none") {
                        HorizontalDivider(thickness = 1.dp, color = tokens.barDivider)
                    }
                }
            }
        },
        bottomBar = {
            Surface(color = Color.Transparent, shadowElevation = (tokens.elevation.value * 2f).dp, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth().background(tokens.barBrush)) {
                    if (tokens.frameEnabled && tokens.frameStyle != "none") {
                        HorizontalDivider(thickness = 1.dp, color = tokens.barDivider)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val tabs = listOf(
                            Triple(0, "الرئيسية", Icons.Default.Home),
                            Triple(1, "الصناديق", Icons.Default.Payments),
                            Triple(2, "الحسابات", Icons.Default.MenuBook),
                            Triple(3, "السندات", Icons.Default.ReceiptLong),
                            Triple(4, "المزيد", Icons.Default.MoreHoriz)
                        )
                        tabs.forEach { (idx, title, icon) ->
                            val active = selectedTab == idx
                            Surface(
                                onClick = {
                                    selectedTab = idx
                                    if (idx != 1) selectedFundId = null
                                    if (idx != 2) { selectedFolderId = null; selectedAccountId = null }
                                },
                                shape = RoundedCornerShape(tokens.buttonRadius),
                                color = if (active) tokens.barButtonBg else Color.Transparent,
                                border = if (active && tokens.frameEnabled) BorderStroke(1.dp, tokens.barAccent.copy(alpha = 0.85f)) else null,
                                modifier = Modifier.weight(1f).heightIn(min = 52.dp).testTag("ts_tab_$idx")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(icon, contentDescription = title, tint = if (active) tokens.barAccent else tokens.barContent.copy(alpha = 0.72f), modifier = Modifier.size(18.dp))
                                    Text(title, color = if (active) tokens.barContent else tokens.barContent.copy(alpha = 0.72f), fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(TsCanvasTop, TsCanvasBot)))
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> TsHomeTabContent(
                    uiState = uiState,
                    gap = gap,
                    onOpenReceipt = { activeDialog = TsActiveDialog.Receipt() },
                    onOpenClockAcc = { activeDialog = TsActiveDialog.ClockAcc() },
                    onOpenInternal = { activeDialog = TsActiveDialog.Internal() },
                    onOpenGap = { activeDialog = TsActiveDialog.Gap }
                )
                1 -> TsFundsTabContent(
                    selectedFundId = selectedFundId,
                    onSelectFund = { selectedFundId = it },
                    uiState = uiState,
                    viewModel = viewModel,
                    onOpenReceipt = { fId, t, ex -> activeDialog = TsActiveDialog.Receipt(fId, t, ex) },
                    onOpenTransfer = { fId, ex -> activeDialog = TsActiveDialog.Transfer(fId, ex) },
                    onOpenInternal = { fId, ex -> activeDialog = TsActiveDialog.Internal(fId, ex) },
                    onOpenExchange = { fId -> activeDialog = TsActiveDialog.Exchange(fId) },
                    onOpenFundEdit = { ex -> activeDialog = TsActiveDialog.FundEdit(ex) },
                    onOpenVoucherMenu = { v -> activeDialog = TsActiveDialog.VoucherMenu(v) }
                )
                2 -> TsAccountsTabContent(
                    selectedFolderId = selectedFolderId,
                    selectedAccountId = selectedAccountId,
                    onSelectFolder = { selectedFolderId = it },
                    onSelectAccount = { selectedAccountId = it },
                    uiState = uiState,
                    viewModel = viewModel,
                    onOpenFolderEdit = { ex -> activeDialog = TsActiveDialog.FolderEdit(ex) },
                    onOpenAccountEdit = { folId, ex -> activeDialog = TsActiveDialog.AccountEdit(folId, ex) },
                    onOpenStats = { activeDialog = TsActiveDialog.Stats },
                    onOpenSearch = { activeDialog = TsActiveDialog.Search },
                    onOpenVoucherEdit = { v ->
                        activeDialog = when (v.kind) {
                            "clockacc" -> TsActiveDialog.ClockAcc(v)
                            "internal" -> TsActiveDialog.Internal(existing = v)
                            "transfer" -> TsActiveDialog.Transfer(existing = v)
                            else -> TsActiveDialog.Receipt(existing = v)
                        }
                    },
                    onOpenVoucherView = { v -> activeDialog = TsActiveDialog.VoucherView(v) }
                )
                3 -> TsVouchersTabContent(
                    uiState = uiState,
                    viewModel = viewModel,
                    onOpenVoucherMenu = { v -> activeDialog = TsActiveDialog.VoucherMenu(v) }
                )
                else -> TsMoreTabContent(uiState = uiState, viewModel = viewModel)
            }
        }
    }

    when (val dlg = activeDialog) {
        is TsActiveDialog.Receipt -> TsCurrenciesToFundsDialog(dlg.fundId, dlg.titleOverride, dlg.existing, uiState, viewModel) { activeDialog = null }
        is TsActiveDialog.ClockAcc -> TsClockToAccountDialog(dlg.existing, uiState, viewModel) { activeDialog = null }
        is TsActiveDialog.Internal -> TsInternalTransferDialog(dlg.fundId, dlg.existing, uiState, viewModel) { activeDialog = null }
        is TsActiveDialog.Transfer -> TsTransferDialog(dlg.fundId, dlg.existing, uiState, viewModel) { activeDialog = null }
        is TsActiveDialog.Exchange -> TsExchangeDialog(dlg.fundId, uiState, viewModel) { activeDialog = null }
        is TsActiveDialog.FundEdit -> {
            val hasV = dlg.existing != null && snap.tsVouchers.any { it.fundId == dlg.existing.id || it.fromFundId == dlg.existing.id || it.toFundId == dlg.existing.id }
            TsFundEditDialog(dlg.existing, (snap.tsFunds.maxOfOrNull { it.order } ?: 0) + 1, hasV, viewModel) { activeDialog = null }
        }
        is TsActiveDialog.FolderEdit -> {
            val hasA = dlg.existing != null && snap.tsAccounts.any { it.folderId == dlg.existing.id }
            TsFolderEditDialog(dlg.existing, (snap.tsFolders.maxOfOrNull { it.order } ?: 0) + 1, hasA, viewModel) { activeDialog = null }
        }
        is TsActiveDialog.AccountEdit -> {
            val existingNames = snap.tsAccounts.filter { it.id != dlg.existing?.id }.map { it.name }.toSet()
            TsAccountEditDialog(dlg.folderId, dlg.existing, existingNames, viewModel) { activeDialog = null }
        }
        is TsActiveDialog.VoucherView -> TsVoucherDetailDialog(dlg.v, uiState) { activeDialog = null }
        is TsActiveDialog.Gap -> TsGapModalDialog(gap) { activeDialog = null }
        is TsActiveDialog.Stats -> TsStatsModalDialog(uiState) { activeDialog = null }
        is TsActiveDialog.Search -> TsSearchModalDialog(
            uiState = uiState,
            onOpenAccount = { accId ->
                val acc = snap.tsAccounts.firstOrNull { it.id == accId }
                if (acc != null) {
                    selectedTab = 2
                    selectedFolderId = acc.folderId
                    selectedAccountId = acc.id
                }
            },
            onDismiss = { activeDialog = null }
        )
        is TsActiveDialog.VoucherMenu -> {
            val v = dlg.v
            TsModalShell(title = "خيارات السند", onDismiss = { activeDialog = null }) {
                OutlinedButton(
                    onClick = {
                        val html = PrintReportBuilders.buildTasfeerSingleVoucherHtml(v, snap.tsAccounts, snap.tsFunds, uiState.settings)
                        viewModel.printHtmlReport(activity, "سند صرافة", html, isVoucher = true)
                        activeDialog = null
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("🖨️ طباعة", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = { activeDialog = TsActiveDialog.VoucherView(v) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("👁 رؤية السند", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = {
                        if (v.isFx || v.isCom) {
                            viewModel.emitMessage("قيد تلقائي من فارق الصرف/العمولة — لا يعدل يدوياً")
                            activeDialog = null
                        } else {
                            activeDialog = when (v.kind) {
                                "clockacc" -> TsActiveDialog.ClockAcc(v)
                                "internal" -> TsActiveDialog.Internal(existing = v)
                                "transfer" -> TsActiveDialog.Transfer(existing = v)
                                else -> TsActiveDialog.Receipt(existing = v)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("✏️ تعديل", fontWeight = FontWeight.Bold) }
                Button(
                    onClick = { viewModel.deleteTsVoucher(v.id); activeDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = AppColors.DebitRed),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("🗑 حذف", fontWeight = FontWeight.Bold) }
            }
        }
        null -> Unit
    }
}

@Composable
private fun TsHeaderMiniBtn(label: String, onClick: () -> Unit) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = tokens.barButtonBg,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
        modifier = Modifier.size(38.dp)
    ) {
        Box(contentAlignment = Alignment.Center) { Text(label, fontSize = 15.sp, color = tokens.barContent) }
    }
}

@Composable
private fun TsHomeTabContent(
    uiState: SmartAdminUiState,
    gap: TasfeerGapSummary,
    onOpenReceipt: () -> Unit,
    onOpenClockAcc: () -> Unit,
    onOpenInternal: () -> Unit,
    onOpenGap: () -> Unit
) {
    val today = DateHelper.todayIso()
    val baseCur = uiState.settings.currencies.firstOrNull()?.name ?: "ريال يمني"
    val todayVouchers = remember(uiState.tasfeerState.updatedVouchers, today) {
        uiState.tasfeerState.updatedVouchers.filter { !it.isFx && !it.isCom && it.date == today }
    }
    val fundOutToday = todayVouchers.filter { it.kind == "receipt" && it.dir == "out" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
    val fundInToday = todayVouchers.filter { it.kind == "receipt" && it.dir != "out" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
    val accOutToday = todayVouchers.filter { (it.kind == "clockacc" && it.dir == "out") || it.kind == "internal" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
    val accInToday = todayVouchers.filter { it.kind == "clockacc" && it.dir != "out" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
    val transferToday = todayVouchers.filter { it.kind == "transfer" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }
    val internalToday = todayVouchers.filter { it.kind == "internal" }.sumOf { TasfeerFxEngine.voucherTotalBase(it, baseCur) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 3 Top Black Action Buttons matching Screenshot 1
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TsHomeBlackBtn("سند قبض من العملات إلى الصناديق", onOpenReceipt, Modifier.weight(1f).testTag("ts_btn_receipt"))
            TsHomeBlackBtn("سندات قبض من صفحات المراقب الى الحسابات", onOpenClockAcc, Modifier.weight(1f).testTag("ts_btn_clockacc"))
            TsHomeBlackBtn("إرسال حوالات داخلية من الصناديق على الحسابات", onOpenInternal, Modifier.weight(1f).testTag("ts_btn_internal"))
        }

        // 6 Today Cards (2 columns × 3 rows)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsStatTile("إجمالي السحب من الصناديق اليوم", fmt(fundOutToday), modifier = Modifier.weight(1f))
            TsStatTile("إجمالي مقبوضات من العملات اليوم", fmt(fundInToday), modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsStatTile("إجمالي السحب من الحسابات اليوم", fmt(accOutToday), modifier = Modifier.weight(1f))
            TsStatTile("إجمالي مقبوضات الى الحسابات اليوم", fmt(accInToday), modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsStatTile("إجمالي التحويل بين الصناديق اليوم", fmt(transferToday), modifier = Modifier.weight(1f))
            TsStatTile("إجمالي السحب الداخلي من الصناديق على الحسابات اليوم", fmt(internalToday), modifier = Modifier.weight(1f))
        }

        // 2 Full Balance Cards
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TsTotalBalanceTile("رصيد الصناديق الكامل", gap.fundsTotal, Modifier.weight(1f))
            TsTotalBalanceTile("رصيد الحسابات الكامل", gap.accountsTotal, Modifier.weight(1f))
        }

        Spacer(Modifier.height(4.dp))
        Text(
            text = "ناتج المبالغ بين الحسابات والصناديق",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        val (gapHeadline, gapColor) = when (gap.side) {
            "fund" -> "الرصيد الباقي للصناديق" to AppColors.DebitRed
            "acc" -> "الرصيد الباقي للحسابات" to AppColors.CreditGreen
            else -> "لا يوجد فارق بين الحسابات والصناديق" to Color(0xFF475569)
        }
        Surface(
            onClick = onOpenGap,
            shape = RoundedCornerShape(14.dp),
            color = TsCreamCard,
            border = BorderStroke(1.2.dp, TsGold),
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth(0.66f).align(Alignment.CenterHorizontally).testTag("ts_gap_card")
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(gapHeadline, color = gapColor, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(fmt(abs(gap.gap)), color = gapColor, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun TsHomeBlackBtn(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.borderColor) else null,
        shadowElevation = tokens.elevation,
        modifier = modifier.heightIn(min = 66.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.background(tokens.darkTileBrush).padding(horizontal = 6.dp, vertical = 10.dp)) {
            Text(label, color = tokens.darkTileContent, fontSize = 11.sp, lineHeight = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun TsStatTile(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = TsCreamCard,
        border = BorderStroke(1.dp, TsGold),
        shadowElevation = 2.dp,
        modifier = modifier.heightIn(min = 64.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 11.sp, lineHeight = 14.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(value, fontSize = 17.sp, color = Color(0xFF0F172A), fontWeight = FontWeight.Black, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun TsTotalBalanceTile(title: String, value: Double, modifier: Modifier = Modifier) {
    val isPos = value >= 0
    val sideLabel = if (isPos) "لكم" else "عليكم"
    val col = if (isPos) AppColors.CreditGreen else AppColors.DebitRed
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = TsCreamCard,
        border = BorderStroke(1.dp, TsGold),
        shadowElevation = 2.dp,
        modifier = modifier.heightIn(min = 68.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 11.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text(sideLabel, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text(fmt(abs(value)), color = col, fontWeight = FontWeight.Black, fontSize = 18.sp)
            }
        }
    }
}
