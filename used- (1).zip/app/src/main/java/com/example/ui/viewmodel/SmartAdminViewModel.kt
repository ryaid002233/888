package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SmartAdminUiState(
    val snapshot: AppDatabaseSnapshot = AppDatabaseSnapshot(),
    val settings: AppSettings = AppSettings(),
    val tasfeerState: TasfeerRecalcResult = TasfeerRecalcResult(
        updatedVouchers = emptyList(),
        fundCurrencyQty = emptyMap(),
        fundCurrencyVal = emptyMap(),
        accountBalances = emptyMap(),
        fundValues = emptyMap(),
        gapSummary = TasfeerGapSummary(0.0, 0.0, 0.0, "even")
    ),
    val buyerStats: BuyerStatsSummary = BuyerStatsSummary(0.0, 0.0, 0.0),
    val savedNames: List<String> = emptyList(),
    val isLoaded: Boolean = false,
    val splashVisible: Boolean = true,
    val isLocked: Boolean = false
)

class SmartAdminViewModel(application: Application) : AndroidViewModel(application) {

    val repository = SmartAdminRepository(application.applicationContext)

    private val _splashVisible = MutableStateFlow(true)
    private val _isLocked = MutableStateFlow(false)
    private val _toastEvent = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    private val _driveBusy = MutableStateFlow(false)
    val driveBusy: StateFlow<Boolean> = _driveBusy.asStateFlow()

    private val _driveFiles = MutableStateFlow<List<GoogleDriveFileItem>>(emptyList())
    val driveFiles: StateFlow<List<GoogleDriveFileItem>> = _driveFiles.asStateFlow()

    private val _showDriveFilesDialog = MutableStateFlow(false)
    val showDriveFilesDialog: StateFlow<Boolean> = _showDriveFilesDialog.asStateFlow()

    private var pendingDriveAction: (() -> Unit)? = null

    val uiState: StateFlow<SmartAdminUiState> = combine(
        repository.snapshotFlow,
        repository.settingsFlow,
        _splashVisible,
        _isLocked
    ) { snap, sett, splash, locked ->
        val tsRecalc = TasfeerFxEngine.recalculate(
            accounts = snap.tsAccounts,
            funds = snap.tsFunds,
            vouchers = snap.tsVouchers,
            currencies = sett.currencies,
            fxAccId = sett.tasfeerFxAccId,
            comAccId = sett.tasfeerComAccId
        )
        val bStats = BuyerCalculators.computeStats(snap.buyerSales, snap.buyerProfits)
        val mergedNames = NameSuggestionHelper.mergeSavedNames(
            explicitSaved = sett.savedNames,
            harvestedFromSnapshot = harvestNamesFromSnapshot(snap)
        )
        SmartAdminUiState(
            snapshot = snap,
            settings = sett,
            tasfeerState = tsRecalc,
            buyerStats = bStats,
            savedNames = mergedNames,
            isLoaded = true,
            splashVisible = splash,
            isLocked = locked
        )
    }.flowOn(Dispatchers.Default).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SmartAdminUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureMinimumContainers()
            val initialSettings = repository.settingsFlow.first()
            if (initialSettings.appLock.enabled && initialSettings.appLock.pin.isNotBlank()) {
                _isLocked.value = true
            }
            GoogleDriveBackupManager.schedulePeriodicBackup(getApplication(), initialSettings.gdriveBackup)
        }
    }

    fun emitMessage(msg: String) {
        _toastEvent.tryEmit(msg)
    }

    fun dismissSplash() {
        _splashVisible.value = false
    }

    fun unlockApp() {
        _isLocked.value = false
    }

    fun lockNowIfEnabled() {
        val lock = uiState.value.settings.appLock
        if (lock.enabled && lock.pin.isNotBlank()) {
            _isLocked.value = true
        }
    }

    fun verifyPin(input: String): Boolean {
        val pin = uiState.value.settings.appLock.pin
        return if (input == pin) {
            _isLocked.value = false
            true
        } else {
            false
        }
    }

    // --- Settings Actions ---
    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repository.updateSettings(transform) }
    }

    fun rememberName(name: String) {
        viewModelScope.launch { repository.rememberNames(name) }
    }

    fun removeSavedName(name: String) {
        viewModelScope.launch { repository.removeSavedName(name) }
    }

    private fun harvestNamesFromSnapshot(snap: AppDatabaseSnapshot): List<String> = buildList {
        snap.debtAccounts.forEach { add(it.name) }
        snap.privateAccounts.forEach { add(it.name) }
        snap.tsAccounts.forEach { add(it.name) }
        snap.tsVouchers.forEach {
            add(it.sender)
            add(it.receiver)
        }
        snap.buyerSales.forEach {
            add(it.sender)
            add(it.receiver)
            add(it.entity)
        }
        snap.buyerTransfers.forEach { sheet ->
            add(sheet.name)
            add(sheet.diffAccountName)
            sheet.rows.forEach { add(it.name) }
        }
        snap.weekFolders.forEach { folder ->
            add(folder.name)
            folder.invoices.forEach { inv ->
                add(inv.initSeller)
                inv.formData.salesRows.forEach { sr ->
                    add(sr.dname)
                    add(sr.oname)
                }
                inv.formData.receivedRows.forEach { add(it.name) }
                inv.formData.outRows.forEach { add(it.name) }
                inv.formData.withdrawRows.forEach { add(it.name) }
                inv.formData.weeklyRows.forEach { add(it.name) }
                inv.buyerRows.forEach { add(it.name) }
            }
        }
        snap.details.forEach { d ->
            add(d.initDetail)
            d.formData.receivedRows.forEach { add(it.name) }
            d.formData.debtRows.forEach { add(it.name) }
        }
        snap.clockEntries.filter { !it.auto }.forEach { add(it.name) }
        snap.currencyReceipts.forEach { add(it.toAccountName) }
        snap.debtCashboxes.forEach { add(it.name) }
        snap.privateFolders.forEach { add(it.name) }
        snap.tsFolders.forEach { add(it.name) }
        snap.tsFunds.forEach { add(it.name) }
        snap.weeklyFilters.forEach { add(it.name) }
    }

    fun toggleLanguage() = updateSettings { s ->
        s.copy(lang = if (s.lang == "ar") "en" else "ar")
    }

    fun toggleDarkTheme() = updateSettings { s -> s.copy(dark = !s.dark) }

    fun setPrimaryColor(hex: String) = updateSettings { s -> s.copy(primaryColorHex = hex) }

    fun setHomeSpecialty(id: String) = updateSettings { s -> s.copy(activeSpecialty = id) }

    fun setBuyerSpecialty(id: String) = updateSettings { s -> s.copy(buyerActiveSpecialty = id) }

    fun addHomeSpecialty(name: String, workersAmount: Double = 0.0) {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return
        val sp = Specialty(name = trimmed, workersAmount = workersAmount)
        updateSettings { s ->
            s.copy(specialties = s.specialties + sp, activeSpecialty = sp.id)
        }
        emitMessage("تم إضافة التخصيص")
    }

    fun addBuyerSpecialty(name: String, workersAmount: Double = 0.0) {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return
        val sp = Specialty(name = trimmed, workersAmount = workersAmount)
        updateSettings { s ->
            s.copy(buyerSpecialties = s.buyerSpecialties + sp, buyerActiveSpecialty = sp.id)
        }
        emitMessage("تم إضافة تخصيص الشرائي")
    }

    // --- Image Helpers ---
    fun saveImageFromUri(uri: Uri, onSaved: (String) -> Unit) {
        viewModelScope.launch {
            val path = ImageStorageHelper.savePickedImage(getApplication(), uri)
            if (path != null) onSaved(path)
            else emitMessage("تعذر حفظ الصورة")
        }
    }

    fun saveImageToGallery(path: String) {
        viewModelScope.launch {
            val ok = ImageStorageHelper.saveToGallery(
                getApplication(),
                path,
                "AlIdari_${System.currentTimeMillis()}.jpg"
            )
            emitMessage(if (ok) "تم حفظ الصورة في المعرض" else "تعذر الحفظ في المعرض")
        }
    }

    // --- Folders & Invoices ---
    fun saveWeekFolder(folder: WeekFolder, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveWeekFolder(folder)
            onDone()
        }
    }

    fun deleteWeekFolder(folder: WeekFolder) {
        viewModelScope.launch {
            repository.deleteWeekFolderToTrash(folder)
            emitMessage("تم نقل المجلد إلى سلة المهملات")
        }
    }

    fun toggleFolderLock(folder: WeekFolder) {
        viewModelScope.launch {
            repository.saveWeekFolder(folder.copy(locked = !folder.locked))
        }
    }

    fun saveInvoice(invoice: FolderInvoice, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.saveInvoice(invoice)
            emitMessage("تم حفظ الفاتورة والمزامنة تلقائياً")
            onDone()
        }
    }

    fun deleteInvoice(invoice: FolderInvoice) {
        viewModelScope.launch {
            repository.deleteInvoiceToTrash(invoice)
            emitMessage("تم نقل الفاتورة إلى سلة المهملات")
        }
    }

    fun copyOrMoveInvoices(invoices: List<FolderInvoice>, targetFolderId: String, move: Boolean) {
        viewModelScope.launch {
            repository.copyOrMoveInvoices(invoices, targetFolderId, move)
            emitMessage(if (move) "تم نقل الفواتير" else "تم نسخ الفواتير")
        }
    }

    // --- Weekly Filter & Detail ---
    fun saveWeeklyFilter(filter: WeeklyFilter) {
        viewModelScope.launch {
            repository.saveWeeklyFilter(filter)
            emitMessage("تم حفظ الفلتر الأسبوعي")
        }
    }

    fun deleteWeeklyFilter(filter: WeeklyFilter) {
        viewModelScope.launch { repository.deleteWeeklyFilterToTrash(filter) }
    }

    fun saveDetailRecord(record: DetailRecord, pushToClock: Boolean = true) {
        viewModelScope.launch {
            repository.saveDetailRecord(record, pushToClock)
            emitMessage(if (pushToClock) "تم الحفظ والترحيل إلى المراقب" else "تم الحفظ")
        }
    }

    fun deleteDetailRecord(record: DetailRecord) {
        viewModelScope.launch { repository.deleteDetailToTrash(record) }
    }

    // --- Clock Entries ---
    fun saveClockEntry(entry: ClockEntry) {
        viewModelScope.launch {
            repository.saveClockEntry(entry)
            emitMessage("تم حفظ الحركة في المراقب")
        }
    }

    fun deleteClockEntry(entry: ClockEntry) {
        viewModelScope.launch { repository.deleteClockEntryToTrash(entry) }
    }

    fun deleteClockEntries(entries: List<ClockEntry>) {
        viewModelScope.launch {
            repository.deleteClockEntriesToTrash(entries)
            emitMessage("تم حذف المعاملات المحددة")
        }
    }

    // --- Debts ---
    fun saveDebtCashbox(box: DebtCashbox) = viewModelScope.launch {
        repository.saveDebtCashbox(box)
        emitMessage("تم الحفظ")
    }
    fun deleteDebtCashbox(id: String) = viewModelScope.launch {
        repository.deleteDebtCashboxCascade(id)
        emitMessage("تم حذف الصندوق")
    }
    fun saveDebtAccount(acc: DebtAccount) = viewModelScope.launch {
        repository.saveDebtAccount(acc)
        emitMessage("تم الحفظ")
    }
    fun deleteDebtAccount(acc: DebtAccount) = viewModelScope.launch {
        repository.deleteDebtAccount(acc)
        emitMessage("تم حذف الحساب")
    }
    fun copyOrMoveDebtAccount(acc: DebtAccount, targetCashboxId: String, move: Boolean) = viewModelScope.launch {
        repository.copyOrMoveDebtAccount(acc, targetCashboxId, move)
        emitMessage(if (move) "تم نقل الحساب" else "تم نسخ الحساب")
    }
    fun saveDebtVoucher(v: DebtVoucher) = viewModelScope.launch {
        repository.saveDebtVoucher(v)
        emitMessage("تم الحفظ")
    }
    fun validateAndSaveDebtVoucher(
        account: DebtAccount,
        voucher: DebtVoucher,
        onSaved: (newNetBalance: Double) -> Unit = {}
    ): String? {
        val accVouchers = uiState.value.snapshot.debtVouchers.filter {
            it.accountId == account.id && it.id != voucher.id
        }
        val balanceWithoutCurrent = accVouchers.sumOf {
            if (it.type == "debt") it.amount else -it.amount
        }
        if (account.limitEnabled && account.limitAmount > 0.0 && voucher.type == "debt" &&
            balanceWithoutCurrent + voucher.amount > account.limitAmount + 1e-9
        ) {
            return "تم رفض المعاملة: ستتجاوز سقف المديونية ${fmt(account.limitAmount)}"
        }
        val newNet = balanceWithoutCurrent + if (voucher.type == "debt") voucher.amount else -voucher.amount
        viewModelScope.launch {
            repository.saveDebtVoucher(voucher)
            emitMessage("تم الحفظ")
            onSaved(newNet)
        }
        return null
    }
    fun deleteDebtVoucher(id: String) = viewModelScope.launch {
        repository.deleteDebtVoucher(id)
        emitMessage("تم حذف المعاملة")
    }
    fun deleteDebtVouchers(ids: List<String>) = viewModelScope.launch {
        repository.deleteDebtVouchers(ids)
        emitMessage("تم حذف المعاملات المحددة")
    }
    fun copyOrMoveDebtVouchers(vouchers: List<DebtVoucher>, targetAccountId: String, move: Boolean) = viewModelScope.launch {
        repository.copyOrMoveDebtVouchers(vouchers, targetAccountId, move)
        emitMessage(if (move) "تم نقل المعاملة" else "تم نسخ المعاملة")
    }

    // --- Currency Strip ---
    fun saveCurrencyReceipt(r: CurrencyReceipt) = viewModelScope.launch {
        repository.saveCurrencyReceipt(r)
        emitMessage("تم تسجيل الحوالة")
    }
    fun deleteCurrencyReceipt(id: String) = viewModelScope.launch { repository.deleteCurrencyReceipt(id) }
    fun saveCurrencyExchange(ex: CurrencyExchangeOp) = viewModelScope.launch {
        repository.saveCurrencyExchange(ex)
        emitMessage("تم تسجيل المصارفة")
    }
    fun deleteCurrencyExchange(id: String) = viewModelScope.launch { repository.deleteCurrencyExchange(id) }

    // --- Tasfeer ---
    fun saveTsFolder(f: TsFolder) = viewModelScope.launch {
        repository.saveTsFolder(f)
        emitMessage("تم حفظ المجلد")
    }

    fun deleteTsFolder(id: String) = viewModelScope.launch {
        val hasAccounts = uiState.value.snapshot.tsAccounts.any { it.folderId == id }
        if (hasAccounts) {
            emitMessage("انقل حسابات هذا المجلد أو احذفها أولاً")
            return@launch
        }
        repository.deleteTsFolder(id)
        emitMessage("تم حذف المجلد")
    }

    fun saveTsAccount(a: TsAccount) = viewModelScope.launch {
        repository.saveTsAccount(a)
        emitMessage("تم حفظ الحساب")
    }

    fun deleteTsAccount(id: String) = viewModelScope.launch {
        repository.deleteTsAccount(id)
        emitMessage("تم حذف الحساب")
    }

    fun copyOrMoveTsAccount(acc: TsAccount, targetFolderId: String, move: Boolean) = viewModelScope.launch {
        repository.copyOrMoveTsAccount(acc, targetFolderId, move)
        emitMessage(if (move) "تم نقل الحساب" else "تم نسخ الحساب")
    }

    fun saveTsFund(f: TsFund) = viewModelScope.launch {
        repository.saveTsFund(f)
        emitMessage("تم حفظ الصندوق")
    }

    fun deleteTsFund(id: String) = viewModelScope.launch {
        val hasVouchers = uiState.value.snapshot.tsVouchers.any { it.fundId == id || it.fromFundId == id || it.toFundId == id }
        if (hasVouchers) {
            emitMessage("لا يمكن المسح: الصندوق يحتوي على عملات")
            return@launch
        }
        repository.deleteTsFund(id)
        emitMessage("تم مسح الصندوق")
    }

    fun saveTsVoucherWithValidation(
        v: TsVoucher,
        newAccountName: String = "",
        onSuccess: () -> Unit = {}
    ): String? {
        val st = uiState.value
        val curList = st.settings.currencies
        val baseCur = curList.firstOrNull()?.name ?: "ريال يمني"
        val checkFund = when (v.kind) {
            "receipt" -> if (v.dir == "out") v.fundId else ""
            "transfer", "internal" -> v.fromFundId
            "exchange" -> v.fundId
            else -> ""
        }
        if (checkFund.isNotBlank()) {
            val reqMap = linkedMapOf<String, Double>()
            if (v.kind == "exchange") {
                val fc = v.fromCur.ifBlank { baseCur }
                reqMap[fc] = (reqMap[fc] ?: 0.0) + v.fromAmt
            } else if (v.rows.isNotEmpty()) {
                v.rows.forEach { r ->
                    val c = r.cur.ifBlank { baseCur }
                    reqMap[c] = (reqMap[c] ?: 0.0) + r.a
                }
            } else {
                val c = v.cur.ifBlank { baseCur }
                reqMap[c] = (reqMap[c] ?: 0.0) + v.amount
            }
            val err = TasfeerFxEngine.checkFundCoverage(
                existingVouchers = st.snapshot.tsVouchers,
                currencies = curList,
                fundId = checkFund,
                requestedByCur = reqMap,
                editingVoucherId = v.id
            )
            if (err != null) {
                return "رصيد الصندوق غير كافٍ من (${err.cur}): المتاح ${fmt(err.available)} والمطلوب ${fmt(err.requested)}"
            }
        }
        viewModelScope.launch {
            var resolvedVoucher = v
            if (newAccountName.isNotBlank()) {
                val existing = st.snapshot.tsAccounts.firstOrNull { it.name == newAccountName.trim() }
                val acc = existing ?: TsAccount(
                    folderId = st.snapshot.tsFolders.firstOrNull()?.id ?: "ts_folder_main",
                    name = newAccountName.trim()
                ).also { repository.saveTsAccount(it) }
                resolvedVoucher = v.copy(accId = acc.id)
            }
            repository.saveTsVoucherWithLink(resolvedVoucher)
            emitMessage("تم حفظ سند الصرافة")
            onSuccess()
        }
        return null
    }

    fun deleteTsVoucher(id: String) = viewModelScope.launch {
        repository.deleteTsVoucher(id)
        emitMessage("تم حذف السند")
    }

    fun deleteTsVouchers(ids: List<String>) = viewModelScope.launch {
        repository.deleteTsVouchers(ids)
        emitMessage("تم حذف السندات المحددة")
    }

    fun resetTasfeerAll() = viewModelScope.launch {
        repository.resetTasfeerAll()
        emitMessage("تم تصفير بيانات الصرافة")
    }

    // --- Private Accounts ---
    fun savePrivateFolder(f: PrivateFolder) = viewModelScope.launch { repository.savePrivateFolder(f) }
    fun deletePrivateFolder(id: String) = viewModelScope.launch { repository.deletePrivateFolder(id) }
    fun savePrivateAccount(a: PrivateAccount) = viewModelScope.launch { repository.savePrivateAccount(a) }
    fun deletePrivateAccount(a: PrivateAccount) = viewModelScope.launch {
        repository.deletePrivateAccountToTrash(a)
        emitMessage("تم نقل الحساب لسلة المهملات")
    }
    fun savePrivateTx(tx: PrivateTx) = viewModelScope.launch { repository.savePrivateTx(tx) }
    fun deletePrivateTx(id: String) = viewModelScope.launch { repository.deletePrivateTx(id) }
    fun deletePrivateTxs(ids: List<String>) = viewModelScope.launch {
        repository.deletePrivateTxs(ids)
        emitMessage("تم حذف المعاملات المحددة")
    }
    fun copyOrMovePrivateAccount(acc: PrivateAccount, targetFolderId: String, move: Boolean) = viewModelScope.launch {
        repository.copyOrMovePrivateAccount(acc, targetFolderId, move)
        emitMessage(if (move) "تم نقل الحساب" else "تم نسخ الحساب")
    }
    fun copyOrMovePrivateTxs(txs: List<PrivateTx>, targetAccountId: String, move: Boolean) = viewModelScope.launch {
        repository.copyOrMovePrivateTxs(txs, targetAccountId, move)
        emitMessage(if (move) "تم نقل المعاملة" else "تم نسخ المعاملة")
    }
    fun savePrivateTransfer(
        fromAccount: PrivateAccount,
        toAccount: PrivateAccount,
        currency: String,
        amount: Double,
        typeOnSource: String,
        note: String
    ) = viewModelScope.launch {
        repository.savePrivateTransfer(fromAccount, toAccount, currency, amount, typeOnSource, note)
        emitMessage("تم تنفيذ القيد المزدوج بين الحسابين")
    }

    // --- Buyer Program ---
    fun saveBuyerTransferSheet(sheet: BuyerTransferSheet) = viewModelScope.launch {
        repository.saveBuyerTransferSheet(sheet)
        emitMessage("تم الحفظ وتحديث الكشف السنوي والأرباح")
    }
    fun deleteBuyerTransferSheet(id: String) = viewModelScope.launch {
        repository.deleteBuyerTransferSheet(id)
        emitMessage("تم حذف كشف التحويل")
    }
    fun saveBuyerAnnualFolder(f: BuyerAnnualFolder) = viewModelScope.launch {
        repository.saveBuyerAnnualFolder(f)
        emitMessage("تم حفظ الكشف السنوي")
    }
    fun saveBuyerSaleEntry(e: BuyerSaleEntry) = viewModelScope.launch {
        repository.saveBuyerSaleEntry(e)
        emitMessage("تم حفظ الحوالة")
    }
    fun deleteBuyerSaleEntry(id: String) = viewModelScope.launch {
        repository.deleteBuyerSaleEntry(id)
        emitMessage("تم حذف الحوالة")
    }
    fun saveBuyerProfitEntry(e: BuyerProfitEntry) = viewModelScope.launch {
        repository.saveBuyerProfitEntry(e)
        emitMessage("تم حفظ القيد")
    }
    fun deleteBuyerProfitEntry(id: String) = viewModelScope.launch {
        repository.deleteBuyerProfitEntry(id)
        emitMessage("تم حذف القيد")
    }
    fun syncBuyerEcosystem() = viewModelScope.launch {
        repository.syncBuyerEcosystemNow()
        emitMessage("تمت مزامنة الشرائي")
    }

    // --- Trash & Backup ---
    fun restoreTrash(item: TrashItem) = viewModelScope.launch {
        val ok = repository.restoreTrashItem(item)
        emitMessage(if (ok) "تمت الاستعادة" else "تعذرت الاستعادة")
    }
    fun deleteTrashItem(id: String) = viewModelScope.launch { repository.deleteTrashItem(id) }
    fun emptyTrash() = viewModelScope.launch { repository.emptyTrash() }
    fun eraseAllData() = viewModelScope.launch {
        repository.eraseAllData()
        emitMessage("تم مسح جميع البيانات")
    }

    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = repository.exportBackupJson(uiState.value.settings)
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                emitMessage("تم تصدير النسخة الاحتياطية بنجاح")
            } catch (_: Exception) {
                emitMessage("فشل تصدير النسخة الاحتياطية")
            }
        }
    }

    fun shareBackupFile() {
        viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val json = repository.exportBackupJson(uiState.value.settings)
                val cacheDir = java.io.File(app.cacheDir, "shared").apply { if (!exists()) mkdirs() }
                val file = java.io.File(cacheDir, "SmartAdmin_Backup_${DateHelper.todayIso()}.json")
                file.writeText(json, Charsets.UTF_8)
                ShareHelper.shareFile(app, file, "application/json", "مشاركة نسخة احتياطية")
            } catch (_: Exception) {
                emitMessage("تعذرت مشاركة النسخة الاحتياطية")
            }
        }
    }

    fun importBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val raw = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val res = repository.importBackupJson(raw)
                if (res.isSuccess) {
                    emitMessage("تم استيراد ${res.getOrNull()} عنصر بنجاح")
                } else {
                    emitMessage("ملف النسخة الاحتياطية غير صالح")
                }
            } catch (_: Exception) {
                emitMessage("فشل استيراد النسخة الاحتياطية")
            }
        }
    }

    // --- Real Google Drive Backup & Restore ---
    fun updateDriveSettings(transform: (DriveBackupSettings) -> DriveBackupSettings) {
        viewModelScope.launch {
            repository.updateSettings { s ->
                val updated = transform(s.gdriveBackup)
                GoogleDriveBackupManager.schedulePeriodicBackup(getApplication(), updated)
                s.copy(gdriveBackup = updated)
            }
        }
    }

    fun dismissDriveFilesDialog() {
        _showDriveFilesDialog.value = false
    }

    fun connectGoogleDrive(
        activity: Activity?,
        onNeedResolution: (IntentSenderRequest) -> Unit
    ) {
        if (activity == null) {
            emitMessage("تعذر فتح نافذة المصادقة")
            return
        }
        viewModelScope.launch {
            _driveBusy.value = true
            try {
                val res = GoogleDriveBackupManager.authorize(activity)
                if (res.hasResolution() && res.pendingIntent != null) {
                    pendingDriveAction = { connectGoogleDrive(activity, onNeedResolution) }
                    onNeedResolution(IntentSenderRequest.Builder(res.pendingIntent!!.intentSender).build())
                } else {
                    val token = res.accessToken
                    if (token.isNullOrBlank()) {
                        emitMessage("لم يتم استلام صلاحية الوصول لـ Google Drive")
                    } else {
                        GoogleDriveBackupManager.cacheToken(token)
                        val email = runCatching { GoogleDriveBackupManager.fetchUserEmail(token) }.getOrDefault("")
                        updateDriveSettings { it.copy(connected = true, email = email) }
                        emitMessage("تم ربط Google Drive بنجاح${if (email.isNotBlank()) " ($email)" else ""}")
                    }
                }
            } catch (e: Exception) {
                emitMessage("تعذر ربط Google Drive: ${e.message ?: "خطأ غير معروف"}")
            } finally {
                _driveBusy.value = false
            }
        }
    }

    fun handleGoogleDriveResolutionResult(activity: Activity?, data: Intent?) {
        if (activity == null || data == null) {
            pendingDriveAction = null
            emitMessage("تم إلغاء مصادقة Google Drive")
            return
        }
        viewModelScope.launch {
            _driveBusy.value = true
            try {
                val authResult = Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data)
                val token = authResult.accessToken
                if (token.isNullOrBlank()) {
                    emitMessage("لم تكتمل مصادقة Google Drive")
                } else {
                    GoogleDriveBackupManager.cacheToken(token)
                    val email = runCatching { GoogleDriveBackupManager.fetchUserEmail(token) }.getOrDefault("")
                    updateDriveSettings { it.copy(connected = true, email = email) }
                    emitMessage("تم ربط Google Drive بنجاح")
                    pendingDriveAction?.invoke()
                }
            } catch (e: Exception) {
                emitMessage("فشل إتمام مصادقة Google: ${e.message ?: ""}")
            } finally {
                pendingDriveAction = null
                _driveBusy.value = false
            }
        }
    }

    fun disconnectGoogleDrive() {
        GoogleDriveBackupManager.clearSession()
        updateDriveSettings { it.copy(connected = false, email = "") }
        emitMessage("تم فصل حساب Google Drive")
    }

    private suspend fun ensureDriveToken(
        activity: Activity?,
        onNeedResolution: (IntentSenderRequest) -> Unit,
        retryAction: () -> Unit
    ): String? {
        val app = getApplication<Application>()
        val silent = GoogleDriveBackupManager.authorizeSilent(app)
        if (!silent.isNullOrBlank()) return silent
        if (activity == null) {
            emitMessage("الرجاء ربط حساب Google Drive أولاً")
            return null
        }
        val res = GoogleDriveBackupManager.authorize(activity)
        if (res.hasResolution() && res.pendingIntent != null) {
            pendingDriveAction = retryAction
            onNeedResolution(IntentSenderRequest.Builder(res.pendingIntent!!.intentSender).build())
            return null
        }
        val token = res.accessToken
        GoogleDriveBackupManager.cacheToken(token)
        if (token.isNullOrBlank()) emitMessage("الرجاء ربط حساب Google Drive أولاً")
        return token
    }

    fun backupNowToGoogleDrive(
        activity: Activity?,
        onNeedResolution: (IntentSenderRequest) -> Unit,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val g = uiState.value.settings.gdriveBackup
            if (g.wifiOnly && !GoogleDriveBackupManager.isWifiConnected(app)) {
                emitMessage("الإعداد محدد على Wi-Fi فقط — لا يوجد اتصال Wi-Fi حالياً")
                onComplete?.invoke(false)
                return@launch
            }
            if (!GoogleDriveBackupManager.isNetworkConnected(app)) {
                emitMessage("لا يوجد اتصال بالإنترنت")
                onComplete?.invoke(false)
                return@launch
            }
            _driveBusy.value = true
            try {
                val token = ensureDriveToken(activity, onNeedResolution) {
                    backupNowToGoogleDrive(activity, onNeedResolution, onComplete)
                } ?: run {
                    onComplete?.invoke(false)
                    return@launch
                }
                val payload = repository.exportBackupJson(uiState.value.settings, includeImages = g.imagesBackupEnabled)
                val filename = GoogleDriveBackupManager.generateBackupFilename()
                val uploaded = GoogleDriveBackupManager.uploadBackupToRyd(token, payload, filename)
                val email = if (g.email.isBlank()) runCatching { GoogleDriveBackupManager.fetchUserEmail(token) }.getOrDefault("") else g.email
                updateDriveSettings {
                    GoogleDriveBackupManager.appendHistory(it, uploaded).copy(connected = true, email = email)
                }
                emitMessage("تم رفع النسخة إلى مجلد RYD على Google Drive (${uploaded.name})")
                onComplete?.invoke(true)
            } catch (e: Exception) {
                emitMessage("فشل رفع النسخة إلى Google Drive: ${e.message ?: ""}")
                onComplete?.invoke(false)
            } finally {
                _driveBusy.value = false
            }
        }
    }

    fun listGoogleDriveBackups(
        activity: Activity?,
        onNeedResolution: (IntentSenderRequest) -> Unit
    ) {
        viewModelScope.launch {
            _driveBusy.value = true
            try {
                val token = ensureDriveToken(activity, onNeedResolution) {
                    listGoogleDriveBackups(activity, onNeedResolution)
                } ?: return@launch
                val files = GoogleDriveBackupManager.listRydBackups(token)
                _driveFiles.value = files
                _showDriveFilesDialog.value = true
                if (files.isEmpty()) emitMessage("مجلد RYD فارغ — لا توجد نسخ محفوظة بعد")
            } catch (e: Exception) {
                emitMessage("تعذر جلب النسخ من Google Drive: ${e.message ?: ""}")
            } finally {
                _driveBusy.value = false
            }
        }
    }

    fun restoreFromGoogleDriveFile(
        activity: Activity?,
        fileId: String,
        onNeedResolution: (IntentSenderRequest) -> Unit
    ) {
        viewModelScope.launch {
            _driveBusy.value = true
            try {
                val token = ensureDriveToken(activity, onNeedResolution) {
                    restoreFromGoogleDriveFile(activity, fileId, onNeedResolution)
                } ?: return@launch
                val raw = GoogleDriveBackupManager.downloadBackupContent(token, fileId)
                val res = repository.importBackupJson(raw)
                if (res.isSuccess) {
                    _showDriveFilesDialog.value = false
                    emitMessage("تمت الاستعادة من Google Drive (${res.getOrNull()} عنصر)")
                } else {
                    emitMessage("ملف النسخة على Drive غير صالح")
                }
            } catch (e: Exception) {
                emitMessage("تعذر الاستعادة من Google Drive: ${e.message ?: ""}")
            } finally {
                _driveBusy.value = false
            }
        }
    }

    fun restoreLatestFromGoogleDrive(
        activity: Activity?,
        onNeedResolution: (IntentSenderRequest) -> Unit
    ) {
        viewModelScope.launch {
            _driveBusy.value = true
            try {
                val token = ensureDriveToken(activity, onNeedResolution) {
                    restoreLatestFromGoogleDrive(activity, onNeedResolution)
                } ?: return@launch
                val files = GoogleDriveBackupManager.listRydBackups(token)
                _driveFiles.value = files
                if (files.isEmpty()) {
                    emitMessage("لا توجد نسخ احتياطية في مجلد RYD على Google Drive")
                } else if (files.size == 1) {
                    val raw = GoogleDriveBackupManager.downloadBackupContent(token, files.first().id)
                    val res = repository.importBackupJson(raw)
                    emitMessage(
                        if (res.isSuccess) "تمت استعادة آخر نسخة (${files.first().name})"
                        else "ملف النسخة غير صالح"
                    )
                } else {
                    _showDriveFilesDialog.value = true
                }
            } catch (e: Exception) {
                emitMessage("فشل الاستعادة من Google Drive: ${e.message ?: ""}")
            } finally {
                _driveBusy.value = false
            }
        }
    }

    // --- Printing & Messaging Helpers ---
    fun printHtmlReport(activity: Activity?, title: String, htmlBody: String, isVoucher: Boolean = false) {
        if (activity == null) return
        PdfPrintManager.printHtml(activity, title, htmlBody, uiState.value.settings, isVoucher)
    }

    fun buildAccountMessageText(
        accountName: String,
        typeLabel: String,
        amount: Double,
        currency: String,
        note: String,
        netBalance: Double,
        netIsCreditForClient: Boolean // in private accounts: net > 0 means عليك (client owes us)
    ): String {
        val m = uiState.value.settings.messages
        val prof = uiState.value.settings.profile
        val sb = StringBuilder()
        if (m.msgIntroEnabled && m.msgIntro.isNotBlank()) {
            sb.appendLine(m.msgIntro)
        } else if (prof.nameAr.isNotBlank()) {
            sb.appendLine(prof.nameAr)
        }
        sb.appendLine("الأخ/ $accountName")
        sb.appendLine("نوع القيد: $typeLabel")
        sb.appendLine("المبلغ: ${fmt(amount)} $currency")
        if (note.isNotBlank()) sb.appendLine("البيان: $note")
        val balStatus = if (kotlin.math.abs(netBalance) < 1e-6) {
            "متوازن"
        } else when (m.messageFormat) {
            "pay" -> "${m.msgFormatPay}: ${fmt(kotlin.math.abs(netBalance))}"
            "debt" -> "${m.msgFormatDebt}: ${fmt(kotlin.math.abs(netBalance))}"
            else -> if (netIsCreditForClient) {
                "${m.msgFormatPay}: ${fmt(kotlin.math.abs(netBalance))}"
            } else {
                "${m.msgFormatDebt}: ${fmt(kotlin.math.abs(netBalance))}"
            }
        }
        sb.appendLine("الرصيد النهائي: $balStatus")
        if (m.msgEndEnabled) {
            val endTxt = m.msgEnd.ifBlank { m.payEnd }
            if (endTxt.isNotBlank()) sb.appendLine(endTxt)
        }
        return sb.toString().trim()
    }

    fun sendAccountMessage(phone: String, text: String) {
        val app = getApplication<Application>()
        val msg = uiState.value.settings.messages
        if (msg.sendWhen == "never") {
            emitMessage("إرسال الرسائل متوقف في الإعدادات")
            return
        }
        if (msg.sendDest == "other") {
            ShareHelper.shareText(app, "مشاركة إشعار الحساب", text)
            return
        }
        if (msg.sendMethod == "sms") {
            ShareHelper.openSms(app, phone, text, msg)
        } else {
            ShareHelper.openWhatsApp(app, phone, text, msg)
        }
    }

    /**
     * Offline Arabic/English Paper Line Parser (reproduces JS parsePaper feature for Seller Invoices):
     * Parses lines like: "محمد علي 15000" or "2 حبة أحمد 30000" into structured (qty, amount, name) triples.
     */
    fun parsePaperLines(rawText: String): List<Triple<String, String, String>> {
        return rawText.lines()
            .map { WesternDigits.toWestern(it).trim() }
            .filter { it.isNotBlank() }
            .mapNotNull { line ->
                val nums = Regex("""\d+(?:\.\d+)?""").findAll(line).map { it.value }.toList()
                val textOnly = line.replace(Regex("""\d+(?:\.\d+)?"""), " ")
                    .replace(Regex("""[*\-_=:|/\\]+"""), " ")
                    .replace(Regex("""\s+"""), " ")
                    .trim()
                when {
                    nums.size >= 2 -> {
                        val n1 = num(nums[0])
                        val n2 = num(nums[1])
                        // Smaller usually quantity, larger amount
                        val (q, a) = if (n1 <= n2) nums[0] to nums[1] else nums[1] to nums[0]
                        Triple(q, a, textOnly)
                    }
                    nums.size == 1 -> Triple("", nums[0], textOnly)
                    textOnly.isNotBlank() -> Triple("", "", textOnly)
                    else -> null
                }
            }
    }
}
