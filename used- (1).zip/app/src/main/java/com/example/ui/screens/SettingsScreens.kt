package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel

@Composable
fun SettingsScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onBack: () -> Unit,
    initialSection: String = "hub"
) {
    val strings = LocalAppStrings.current
    val settings = uiState.settings
    val context = LocalContext.current

    var subSection by remember(initialSection) { mutableStateOf(initialSection) }
    val handleBack = {
        if (initialSection == "hub" && subSection != "hub") {
            subSection = "hub"
        } else {
            onBack()
        }
    }
    BackHandler(onBack = handleBack)

    var showEraseConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = when (subSection) {
                    "profile" -> strings.t("الملف الشخصي والختم", "Profile & Stamps")
                    "appearance" -> strings.t("المظهر والحدود والخطوط", "Theme, Design & Fonts")
                    "lock" -> strings.t("قفل التطبيق والأمان", "App Lock & Security")
                    "currencies" -> strings.currencies
                    "specialties" -> strings.t("التخصيص", "Specialties")
                    "buyer_specialties" -> strings.t("تخصيص الشرائي", "Buyer Specialties")
                    "messages" -> strings.t("إعدادات الرسائل والواتساب", "Messaging & WhatsApp")
                    "printing" -> strings.t("إعدادات الطباعة والفخامة", "Printing Settings")
                    "trash" -> strings.t("سلة المهملات", "Trash Bin")
                    "backup" -> strings.t("النسخ الاحتياطي والبيانات", "Backup & Data")
                    "gdriveBackup" -> strings.t("النسخ الاحتياطي Google Drive", "Google Drive Backup")
                    else -> strings.settings
                },
                onBack = handleBack,
                backTestTag = "settings_back_btn"
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            when (subSection) {
                "hub" -> {
                    item {
                        SettingsMenuRow(Icons.Default.Person, strings.t("الملف الشخصي", "Profile & Branding"), "profile", Color(0xFF0284C7)) { subSection = "profile" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.AutoAwesome, strings.t("التخصيص", "Specialties & Linkages"), "specialties", Color(0xFFEAB308)) { subSection = "specialties" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.ShoppingBag, strings.t("تخصيص الشرائي", "Buyer Specialties"), "buyer_specialties", Color(0xFF10B981)) { subSection = "buyer_specialties" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.Palette, strings.t("اللغة ومظهر التطبيق والحدود", "Language, Theme & Borders"), "appearance", Color(0xFF0EA5E9)) { subSection = "appearance" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.MonetizationOn, strings.t("العملات", "Manage Currencies"), "currencies", Color(0xFFD97706)) { subSection = "currencies" }
                    }
                    item {
                        SettingsMenuRow(
                            Icons.Default.Recycling,
                            strings.t("سلة المحذوفات (${uiState.snapshot.trash.size})", "Trash (${uiState.snapshot.trash.size})"),
                            "trash",
                            Color(0xFF16A34A)
                        ) { subSection = "trash" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.Sms, strings.t("الرسائل والواتس", "WhatsApp & SMS Settings"), "messages", Color(0xFF334155)) { subSection = "messages" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.Print, strings.t("إعدادات الطباعة", "Printing & PDF Settings"), "printing", Color(0xFF475569)) { subSection = "printing" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.Lock, strings.t("قفل التطبيق", "App Lock & Biometric"), "lock", Color(0xFFCA8A04)) { subSection = "lock" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.CloudUpload, strings.t("النسخ الاحتياطي السحابي (Google Drive)", "Google Drive Cloud Backup"), "gdrive_backup", Color(0xFF2563EB)) { subSection = "gdriveBackup" }
                    }
                    item {
                        SettingsMenuRow(Icons.Default.Inventory2, strings.t("النسخ الاحتياطي على الهاتف والملفات", "Phone & File Backup"), "backup", Color(0xFF92400E)) { subSection = "backup" }
                    }
                    item {
                        StyledAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(strings.t("الدعم والتواصل", "Support & Contact"), fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            ShareHelper.openWhatsApp(context, settings.supportPhone, "مرحباً، بخصوص تطبيق الاداري برو", settings.messages)
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(strings.t("واتساب الدعم", "Support WhatsApp")) }
                                    OutlinedButton(
                                        onClick = {
                                            ShareHelper.shareText(context, strings.appTitle, "${strings.appTitle} — ${strings.appSubtitle}")
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(strings.t("مشاركة التطبيق", "Share App")) }
                                }
                            }
                        }
                    }
                }

                "profile" -> {
                    item { ProfileSettingsSection(settings, viewModel) }
                }

                "appearance" -> {
                    item { AppearanceSettingsSection(settings, viewModel) }
                }

                "lock" -> {
                    item { AppLockSection(settings, viewModel) }
                }

                "currencies" -> {
                    item { CurrenciesSection(settings, viewModel) }
                }

                "specialties" -> {
                    item { SpecialtiesAndLinksSection(uiState, viewModel, initialBuyerTab = false) }
                }

                "buyer_specialties" -> {
                    item { SpecialtiesAndLinksSection(uiState, viewModel, initialBuyerTab = true) }
                }

                "messages" -> {
                    item { MessagesSettingsSection(settings, viewModel) }
                }

                "printing" -> {
                    item { PrintingSettingsSection(settings, viewModel) }
                }

                "trash" -> {
                    if (uiState.snapshot.trash.isEmpty()) {
                        item { EmptyStateView(Icons.Default.DeleteSweep, strings.t("سلة المهملات فارغة", "Trash is Empty")) }
                    } else {
                        item {
                            OutlinedButton(onClick = { viewModel.emptyTrash() }, modifier = Modifier.fillMaxWidth()) {
                                Text(strings.t("إفراغ السلة نهائياً", "Empty Trash"))
                            }
                        }
                        items(uiState.snapshot.trash, key = { it.id }) { item ->
                            StyledAppCard(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, fontWeight = FontWeight.Bold)
                                        Text("${item.type} • ${item.deletedAt}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    TextButton(onClick = { viewModel.restoreTrash(item) }) { Text(strings.t("استعادة", "Restore")) }
                                    IconButton(onClick = { viewModel.deleteTrashItem(item.id) }) {
                                        Icon(Icons.Default.DeleteForever, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }

                "gdriveBackup" -> {
                    item { GdriveBackupSection(settings, viewModel) }
                }

                "backup" -> {
                    item {
                        StyledAppCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(strings.t("النسخ الاحتياطي على الهاتف والملفات", "Local Phone & File Backup"), fontWeight = FontWeight.Bold)
                                Button(onClick = onExportBackup, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.Download, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.t("تنزيل نسخة احتياطية إلى الهاتف (JSON)", "Download Backup (JSON)"))
                                }
                                OutlinedButton(onClick = onImportBackup, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.UploadFile, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.t("استعادة من ملف على الهاتف", "Restore from JSON File"))
                                }
                                FilledTonalButton(onClick = { viewModel.shareBackupFile() }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.Share, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.t("مشاركة / إرسال عبر Telegram أو واتساب", "Share / Send via Telegram or WhatsApp"))
                                }
                                FilledTonalButton(onClick = { subSection = "gdriveBackup" }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.CloudQueue, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.t("إعدادات النسخ السحابي Google Drive (RYD)", "Google Drive Backup Settings"))
                                }
                                HorizontalDivider()
                                OutlinedButton(
                                    onClick = { showEraseConfirm = true },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.t("مسح جميع البيانات والبدء من الصفر", "Erase All Data"))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEraseConfirm) {
        ConfirmActionDialog(
            title = strings.t("تأكيد المسح الشامل", "Confirm Erase All Data"),
            message = strings.t("سيتم حذف جميع الفواتير والحسابات والسندات نهائياً. هل أنت متأكد؟", "All records will be permanently erased. Continue?"),
            confirmText = strings.t("مسح الكل", "Erase Everything"),
            onConfirm = { viewModel.eraseAllData() },
            onDismiss = { showEraseConfirm = false }
        )
    }
}

@Composable
private fun SettingsMenuRow(
    icon: ImageVector,
    title: String,
    tag: String,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    LuxuryDrawerMenuRow(
        icon = icon,
        title = title,
        iconTint = iconTint,
        onClick = onClick,
        modifier = Modifier.testTag("settings_row_$tag")
    )
}

@Composable
private fun ProfileSettingsSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    val p = settings.profile
    var nameAr by remember(p) { mutableStateOf(p.nameAr) }
    var nameEn by remember(p) { mutableStateOf(p.nameEn) }
    var addrAr by remember(p) { mutableStateOf(p.addressAr) }
    var addrEn by remember(p) { mutableStateOf(p.addressEn) }
    var phones by remember(p) { mutableStateOf(p.contacts) }
    var phonesEn by remember(p) { mutableStateOf(p.contactsEn) }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path -> viewModel.updateSettings { it.copy(profile = it.profile.copy(logoPath = path)) } }
    }
    val stampPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path -> viewModel.updateSettings { it.copy(profile = it.profile.copy(stampPath = path)) } }
    }
    val signPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path -> viewModel.updateSettings { it.copy(profile = it.profile.copy(signPath = path)) } }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nameAr, onValueChange = { nameAr = it }, label = { Text(strings.t("الاسم التجاري (عربي)", "Business Name (AR)")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text(strings.t("الاسم (إنجليزي)", "Business Name (EN)")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = addrAr, onValueChange = { addrAr = it }, label = { Text(strings.t("العنوان (عربي)", "Address (AR)")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = addrEn, onValueChange = { addrEn = it }, label = { Text(strings.t("العنوان (إنجليزي)", "Address (EN)")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phones, onValueChange = { phones = it }, label = { Text(strings.t("أرقام التواصل", "Phone Numbers")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phonesEn, onValueChange = { phonesEn = it }, label = { Text(strings.t("أرقام التواصل (إنجليزي)", "Phone Numbers (EN)")) }, modifier = Modifier.fillMaxWidth())

                SettingSwitchRow(
                    title = strings.t("استخدام ترويسة جاهزة (صورة كاملة)", "Use Full Ready Header Banner"),
                    checked = p.useFullHeader,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(profile = it.profile.copy(useFullHeader = on)) } }
                )

                Text(strings.t("طريقة عرض المجلدات", "Folders View Mode"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.viewMode == "list",
                        onClick = { viewModel.updateSettings { it.copy(viewMode = "list") } },
                        label = { Text(strings.t("قائمة", "List")) }
                    )
                    FilterChip(
                        selected = settings.viewMode == "grid",
                        onClick = { viewModel.updateSettings { it.copy(viewMode = "grid") } },
                        label = { Text(strings.t("شبكة", "Grid")) }
                    )
                }

                HorizontalDivider()
                ProfileAssetRow(
                    label = strings.t("الشعار", "Logo"),
                    hasAsset = p.logoPath.isNotBlank(),
                    onUpload = { logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onClear = { viewModel.updateSettings { it.copy(profile = it.profile.copy(logoPath = "")) } }
                )
                ProfileAssetRow(
                    label = strings.t("الختم", "Stamp"),
                    hasAsset = p.stampPath.isNotBlank(),
                    onUpload = { stampPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onClear = { viewModel.updateSettings { it.copy(profile = it.profile.copy(stampPath = "")) } }
                )
                ProfileAssetRow(
                    label = strings.t("التوقيع", "Signature"),
                    hasAsset = p.signPath.isNotBlank(),
                    onUpload = { signPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onClear = { viewModel.updateSettings { it.copy(profile = it.profile.copy(signPath = "")) } }
                )
                Button(
                    onClick = {
                        viewModel.updateSettings {
                            it.copy(
                                profile = it.profile.copy(
                                    nameAr = nameAr.trim(),
                                    nameEn = nameEn.trim(),
                                    addressAr = addrAr.trim(),
                                    addressEn = addrEn.trim(),
                                    contacts = phones.trim(),
                                    contactsEn = phonesEn.trim()
                                )
                            )
                        }
                        viewModel.emitMessage("تم حفظ الملف الشخصي")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(strings.save) }
            }
        }
    }
}

@Composable
private fun ProfileAssetRow(label: String, hasAsset: Boolean, onUpload: () -> Unit, onClear: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.7f))
        OutlinedButton(onClick = onUpload, modifier = Modifier.weight(1.2f)) {
            Text(if (hasAsset) "✓ $label" else label)
        }
        if (hasAsset) {
            IconButton(onClick = onClear, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun AppLockSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    var pinInput by remember(settings.appLock.pin) { mutableStateOf(settings.appLock.pin) }
    StyledAppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.t("تفعيل قفل التطبيق", "Enable App Lock"))
                Switch(
                    checked = settings.appLock.enabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appLock = it.appLock.copy(enabled = on)) } }
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.t("الفتح بالبصمة", "Biometric Unlock"))
                Switch(
                    checked = settings.appLock.biometric,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(appLock = it.appLock.copy(biometric = on)) } }
                )
            }
            Text(strings.t("مدة القفل التلقائي", "Auto-Lock Delay"), style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("0" to "فوري", "30s" to "30 ثانية", "1m" to "دقيقة", "5m" to "5 دقائق", "15m" to "15 دقيقة")) { (k, lbl) ->
                    FilterChip(
                        selected = settings.appLock.autoLock == k,
                        onClick = { viewModel.updateSettings { it.copy(appLock = it.appLock.copy(autoLock = k)) } },
                        label = { Text(lbl) }
                    )
                }
            }
            WesternNumberField(value = pinInput, onValueChange = { pinInput = it }, label = strings.t("رمز القفل (4 أرقام أو أكثر)", "PIN Code"), allowDecimal = false, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (pinInput.length >= 4) {
                            viewModel.updateSettings { it.copy(appLock = it.appLock.copy(pin = pinInput, enabled = true)) }
                            viewModel.emitMessage("تم حفظ رمز القفل")
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(strings.save) }
                if (settings.appLock.pin.isNotBlank()) {
                    OutlinedButton(
                        onClick = {
                            pinInput = ""
                            viewModel.updateSettings { it.copy(appLock = it.appLock.copy(pin = "", enabled = false)) }
                            viewModel.emitMessage("تم حذف رمز القفل")
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text(strings.t("حذف الرمز", "Remove PIN")) }
                }
            }
        }
    }
}

@Composable
private fun CurrenciesSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf("") }
    var symbol by remember { mutableStateOf("") }
    var rateStr by remember { mutableStateOf("1") }

    StyledAppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            settings.currencies.forEachIndexed { idx, c ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${c.name} (${c.symbol}) • ${fmt(c.sellRate)}", fontWeight = FontWeight.Bold)
                    if (idx > 0) {
                        IconButton(onClick = {
                            val updated = settings.currencies.toMutableList().apply { removeAt(idx) }
                            viewModel.updateSettings { it.copy(currencies = updated) }
                        }) { Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error) }
                    }
                }
                HorizontalDivider()
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.t("العملة", "Name")) }, modifier = Modifier.weight(1.2f))
                OutlinedTextField(value = symbol, onValueChange = { symbol = it }, label = { Text(strings.t("الرمز", "Symbol")) }, modifier = Modifier.weight(0.7f))
                WesternNumberField(value = rateStr, onValueChange = { rateStr = it }, label = strings.t("السعر", "Rate"), modifier = Modifier.weight(0.8f))
            }
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val r = num(rateStr).let { if (it > 0) it else 1.0 }
                        val item = AppCurrency(name = name.trim(), symbol = symbol.trim().ifBlank { name.trim().take(3) }, sellRate = r, buyRate = r)
                        viewModel.updateSettings { it.copy(currencies = it.currencies + item) }
                        name = ""; symbol = ""; rateStr = "1"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(strings.t("إضافة عملة", "Add Currency")) }
        }
    }
}

@Composable
private fun SpecialtiesAndLinksSection(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    initialBuyerTab: Boolean = false
) {
    val strings = LocalAppStrings.current
    val settings = uiState.settings
    var spName by remember { mutableStateOf("") }
    var spAmt by remember { mutableStateOf("") }
    var isBuyerSp by remember(initialBuyerTab) { mutableStateOf(initialBuyerTab) }
    var tsPass by remember(settings.tasfeerPass) { mutableStateOf(settings.tasfeerPass) }

    StyledAppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !isBuyerSp, onClick = { isBuyerSp = false }, label = { Text(strings.t("تخاصيص الرئيسية", "Home")) })
                FilterChip(selected = isBuyerSp, onClick = { isBuyerSp = true }, label = { Text(strings.t("تخاصيص الشرائي", "Purchase")) })
            }
            val list = if (isBuyerSp) settings.buyerSpecialties else settings.specialties
            list.forEach { sp ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${sp.name} (${strings.t("خرج العمال:", "Workers:")} ${fmt(sp.workersAmount)})")
                    IconButton(onClick = {
                        viewModel.updateSettings { s ->
                            if (isBuyerSp) s.copy(buyerSpecialties = s.buyerSpecialties.filter { it.id != sp.id })
                            else s.copy(specialties = s.specialties.filter { it.id != sp.id })
                        }
                    }) { Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = spName, onValueChange = { spName = it }, label = { Text(strings.t("اسم التخصيص", "Specialty")) }, modifier = Modifier.weight(1.3f))
                WesternNumberField(value = spAmt, onValueChange = { spAmt = it }, label = strings.t("مبلغ العمال", "Workers"), modifier = Modifier.weight(1f))
            }
            Button(
                onClick = {
                    if (spName.isNotBlank()) {
                        val sp = Specialty(name = spName.trim(), workersAmount = num(spAmt))
                        viewModel.updateSettings { s ->
                            if (isBuyerSp) s.copy(buyerSpecialties = s.buyerSpecialties + sp)
                            else s.copy(specialties = s.specialties + sp)
                        }
                        spName = ""; spAmt = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(strings.t("إضافة تخصيص", "Add Specialty")) }

            HorizontalDivider()
            Text(strings.t("ربط الفواتير داخل المجلدات", "Invoices in Folders"), fontWeight = FontWeight.Bold)
            SettingSwitchRow(
                title = strings.t("عرض الفواتير داخل المجلد", "Show Invoices Inside Folders"),
                checked = settings.showInvoicesInFolders,
                onCheckedChange = { on -> viewModel.updateSettings { it.copy(showInvoicesInFolders = on) } }
            )
            SettingSwitchRow(
                title = strings.t("تفعيل الضغط المطوّل على الفاتورة", "Enable Invoice Long-Press Actions"),
                checked = settings.longPressActions,
                onCheckedChange = { on -> viewModel.updateSettings { it.copy(longPressActions = on) } }
            )
            HorizontalDivider()
            OutlinedTextField(value = tsPass, onValueChange = { tsPass = it }, label = { Text(strings.t("كلمة مرور الصرافة (اختياري)", "Exchange Passcode")) }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                viewModel.updateSettings { it.copy(tasfeerPass = tsPass.trim()) }
                viewModel.emitMessage("تم حفظ كلمة مرور الصرافة")
            }) { Text(strings.save) }
        }
    }
}

@Composable
private fun GdriveBackupSection(settings: AppSettings, viewModel: SmartAdminViewModel) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val activity = remember(context) {
        var ctx: Context = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) break
            ctx = ctx.baseContext
        }
        ctx as? Activity
    }
    val g = settings.gdriveBackup
    val busy by viewModel.driveBusy.collectAsState()
    val driveFiles by viewModel.driveFiles.collectAsState()
    val showFilesDialog by viewModel.showDriveFilesDialog.collectAsState()

    val authLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.handleGoogleDriveResolutionResult(activity, result.data)
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Account Status Card
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(strings.t("حساب Google Drive", "Google Drive Account"), fontWeight = FontWeight.Bold)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (g.connected) Color(0xFF16A34A).copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (g.connected) Color(0xFF16A34A).copy(alpha = 0.45f) else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (g.connected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (g.connected) Color(0xFF16A34A) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(34.dp)
                        )
                        Text(
                            text = if (g.connected) strings.t("تم الربط بحساب Google Drive", "Connected to Google Drive")
                            else strings.t("لم يتم الاتصال بخدمة Google Drive", "Not Connected to Google Drive"),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (g.connected) g.email.ifBlank { "Google Drive OAuth Active" }
                            else strings.t("اربط حساب Google لحفظ واستعادة نسخ RYD السحابية (.back)", "Connect Google account for RYD cloud backups (.back)"),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (busy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.connectGoogleDrive(activity) { req -> authLauncher.launch(req) }
                        },
                        enabled = !busy,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t(if (g.connected) "تغيير الحساب" else "الاتصال بـ Google", if (g.connected) "Switch" else "Connect Google"))
                    }
                    OutlinedButton(
                        onClick = { viewModel.disconnectGoogleDrive() },
                        enabled = g.connected && !busy,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("تسجيل الخروج", "Disconnect"))
                    }
                }
            }
        }

        // Settings & Intervals Card
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("إعدادات النسخ الاحتياطي", "Backup Settings"), fontWeight = FontWeight.Bold)
                SettingSwitchRow(
                    title = strings.t("النسخ الاحتياطي عند الخروج (التنبيه ورفع RYD)", "Backup on Exit"),
                    checked = g.backupOnExit,
                    onCheckedChange = { on -> viewModel.updateDriveSettings { it.copy(backupOnExit = on) } }
                )
                HorizontalDivider()
                SettingSwitchRow(
                    title = strings.t("النسخ المجدول التلقائي للبيانات", "Scheduled Data Backup"),
                    checked = g.dataEnabled,
                    onCheckedChange = { on -> viewModel.updateDriveSettings { it.copy(dataEnabled = on) } }
                )
                Text(strings.t("تكرار نسخ البيانات", "Data Backup Interval"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("6h" to "كل 6 ساعات", "12h" to "كل 12 ساعة", "24h" to "يومي", "7d" to "أسبوعي")) { (k, lbl) ->
                        FilterChip(
                            selected = g.dataInterval == k,
                            onClick = {
                                viewModel.updateDriveSettings { it.copy(dataInterval = k) }
                                viewModel.emitMessage("تم حفظ تكرار النسخ")
                            },
                            label = { Text(lbl) }
                        )
                    }
                }
                HorizontalDivider()
                SettingSwitchRow(
                    title = strings.t("تضمين الصور والمرفقات", "Include Images & Attachments"),
                    checked = g.imagesBackupEnabled,
                    onCheckedChange = { on -> viewModel.updateDriveSettings { it.copy(imagesBackupEnabled = on) } }
                )
                Text(strings.t("تكرار نسخ الصور", "Images Backup Interval"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("daily" to "يومي", "weekly" to "أسبوعي", "monthly" to "شهري").forEach { (k, lbl) ->
                        FilterChip(
                            selected = g.imagesInterval == k,
                            onClick = { viewModel.updateDriveSettings { it.copy(imagesInterval = k) } },
                            label = { Text(lbl) }
                        )
                    }
                }
                HorizontalDivider()
                SettingSwitchRow(
                    title = strings.t("استخدام Wi-Fi فقط للرفع", "Wi-Fi Only"),
                    checked = g.wifiOnly,
                    onCheckedChange = { on -> viewModel.updateDriveSettings { it.copy(wifiOnly = on) } }
                )

                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { viewModel.backupNowToGoogleDrive(activity, { req -> authLauncher.launch(req) }) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.t("نسخ احتياطي الآن (مجلد RYD)", "Backup Now to Drive (RYD)"))
                }
                FilledTonalButton(
                    onClick = { viewModel.restoreLatestFromGoogleDrive(activity) { req -> authLauncher.launch(req) } },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.t("استعادة من Google Drive", "Restore from Google Drive"))
                }
                OutlinedButton(
                    onClick = { viewModel.listGoogleDriveBackups(activity) { req -> authLauncher.launch(req) } },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.t("عرض النسخ الموجودة على Google Drive", "Browse Backups in RYD"))
                }
            }
        }

        // Local Backup History Card
        StyledAppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.t("سجل النسخ الاحتياطي (${g.backupHistory.size})", "Backup History (${g.backupHistory.size})"), fontWeight = FontWeight.Bold)
                if (g.backupHistory.isEmpty()) {
                    Text(strings.t("لم يتم تسجيل عمليات نسخ سحابي بعد", "No cloud backups recorded yet"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    g.backupHistory.forEach { item ->
                        val kb = (item.sizeBytes / 1024L).coerceAtLeast(1L)
                        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(item.filename.ifBlank { "نسخة احتياطية.back" }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            Text("${item.dateIso.take(19).replace('T', ' ')} • $kb KB", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showFilesDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissDriveFilesDialog() },
            title = {
                Text(strings.t("النسخ الاحتياطية — مجلد RYD (${driveFiles.size})", "RYD Cloud Backups (${driveFiles.size})"))
            },
            text = {
                if (driveFiles.isEmpty()) {
                    Text(strings.t("لا توجد ملفات .back في مجلد RYD على Google Drive.", "No .back files found in RYD folder."))
                } else {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        driveFiles.forEach { f ->
                            val sizeLabel = if (f.sizeBytes >= 1048576L) {
                                String.format(java.util.Locale.US, "%.2f MB", f.sizeBytes / 1048576.0)
                            } else {
                                "${(f.sizeBytes / 1024L).coerceAtLeast(1L)} KB"
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(f.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "المجلد: RYD · الامتداد: .back · الحجم: $sizeLabel",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "التاريخ: ${f.modifiedTime.ifBlank { f.createdTime }.take(19).replace('T', ' ')}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    FilledTonalButton(
                                        onClick = { viewModel.restoreFromGoogleDriveFile(activity, f.id) { req -> authLauncher.launch(req) } },
                                        enabled = !busy,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(strings.t("استعادة النسخة", "Restore This Backup"))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissDriveFilesDialog() }) {
                    Text(strings.close)
                }
            }
        )
    }
}

