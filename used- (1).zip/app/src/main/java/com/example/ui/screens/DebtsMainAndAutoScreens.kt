package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@Composable
fun DebtsMainScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenAutoBox: () -> Unit,
    onOpenCashbox: (DebtCashbox) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortField by remember { mutableStateOf(DebtSortField.DATE) }
    var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
    var selectAllMain by remember { mutableStateOf(false) }

    var editingCashbox by remember { mutableStateOf<DebtCashbox?>(null) }
    var showAddCashbox by remember { mutableStateOf(false) }
    var menuTargetBox by remember { mutableStateOf<DebtCashbox?>(null) } // null -> check menuAutoBox
    var menuAutoBox by remember { mutableStateOf(false) }

    val activeSpec = uiState.settings.activeSpecialty

    // Filtered Auto Clock Debt entries (match specialty + period)
    val filteredAutoEntries = remember(uiState.snapshot.clockEntries, activeSpec, fromDate, toDate) {
        uiState.snapshot.clockEntries
            .filter { it.section == ClockSection.DEBTS }
            .filter { matchesSpecialtyFilter(it.specialtyId, activeSpec) }
            .filter { e ->
                val ef = e.date.ifBlank { e.to }
                val et = e.to.ifBlank { e.date }
                (fromDate.isBlank() || et.isBlank() || et >= fromDate) &&
                    (toDate.isBlank() || ef.isBlank() || ef <= toDate)
            }
    }
    val autoTotals = remember(filteredAutoEntries) {
        var pay = 0.0
        var debt = 0.0
        filteredAutoEntries.forEach { e ->
            val amt = abs(e.amount)
            if (e.dir == "عليكم") debt += amt else pay += amt
        }
        DebtTotals(pay = pay, debt = debt)
    }

    // Filtered custom Debt Vouchers (match period + specialty)
    val filteredVouchers = remember(uiState.snapshot.debtVouchers, activeSpec, fromDate, toDate) {
        uiState.snapshot.debtVouchers
            .filter { matchesSpecialtyFilter(it.specialtyId, activeSpec) }
            .filter { v ->
                (fromDate.isBlank() || v.date.isBlank() || v.date >= fromDate) &&
                    (toDate.isBlank() || v.date.isBlank() || v.date <= toDate)
            }
    }

    val cashboxTotalsMap = remember(uiState.snapshot.debtCashboxes, uiState.snapshot.debtAccounts, filteredVouchers) {
        uiState.snapshot.debtCashboxes.associate { box ->
            val accIds = uiState.snapshot.debtAccounts.filter { it.cashboxId == box.id }.map { it.id }.toSet()
            val vs = filteredVouchers.filter { it.accountId in accIds }
            val pay = vs.filter { it.type == "pay" }.sumOf { it.amount }
            val debt = vs.filter { it.type == "debt" }.sumOf { it.amount }
            box.id to DebtTotals(pay = pay, debt = debt)
        }
    }

    val overallCustomTotals = remember(cashboxTotalsMap) {
        var pay = 0.0
        var debt = 0.0
        cashboxTotalsMap.values.forEach {
            pay += it.pay
            debt += it.debt
        }
        DebtTotals(pay = pay, debt = debt)
    }

    val sortedCashboxes = remember(uiState.snapshot.debtCashboxes, sortField, sortDir, cashboxTotalsMap) {
        val base = uiState.snapshot.debtCashboxes.sortedBy { it.order }
        val sorted = when (sortField) {
            DebtSortField.DATE -> base
            DebtSortField.NAME -> base.sortedBy { it.name }
            DebtSortField.AMOUNT -> base.sortedBy { abs(cashboxTotalsMap[it.id]?.net ?: 0.0) }
        }
        if (sortDir == DebtSortDir.DESC) sorted.reversed() else sorted
    }

    Scaffold(
        topBar = {
            DebtsTopLuxuryBar(
                title = strings.t("الديون", "Debts"),
                onBack = onBack
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showAddCashbox = true },
                contentDescription = strings.t("إضافة صندوق حسابات ديون", "Add Debt Cashbox"),
                modifier = Modifier.testTag("add_debt_cashbox_fab")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 92.dp)
        ) {
            item(key = "controls") {
                DebtsControlStrip(
                    specialties = uiState.settings.specialties,
                    activeSpecialty = activeSpec,
                    onSelectSpecialty = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    selectAllChecked = selectAllMain,
                    onToggleSelectAll = { selectAllMain = !selectAllMain },
                    totals = overallCustomTotals,
                    sortField = sortField,
                    sortDir = sortDir,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortDir = it },
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            item(key = "auto_band") {
                DebtsSectionBand(
                    title = strings.t("صندوق ثابت لاستلام سندات الدين من التفصيل", "Fixed Cashbox for Detail Debt Slips"),
                    icon = Icons.Default.MoveToInbox
                )
            }

            item(key = "auto_card") {
                DebtCashboxCard(
                    title = strings.t("الصندوق التلقائي", "Automatic Cashbox"),
                    totals = autoTotals,
                    isAutoBox = true,
                    onClick = onOpenAutoBox,
                    onLongClick = { menuAutoBox = true }
                )
            }

            item(key = "custom_band") {
                DebtsSectionBand(
                    title = strings.t("قائمة الصناديق التي تفتح حسابات العملاء داخلها في صفحة الدين", "Customer Debt Account Cashboxes")
                )
            }

            items(sortedCashboxes, key = { it.id }) { box ->
                val totals = cashboxTotalsMap[box.id] ?: DebtTotals()
                DebtCashboxCard(
                    title = box.name,
                    totals = totals,
                    imagePath = box.imagePath,
                    isAutoBox = false,
                    onClick = { onOpenCashbox(box) },
                    onLongClick = { menuTargetBox = box },
                    onEditClick = { editingCashbox = box }
                )
            }
        }
    }

    if (showAddCashbox) {
        DebtCashboxEditDialog(
            existing = null,
            defaultOrder = uiState.snapshot.debtCashboxes.size + 1,
            viewModel = viewModel,
            onDismiss = { showAddCashbox = false }
        )
    }

    editingCashbox?.let { box ->
        DebtCashboxEditDialog(
            existing = box,
            defaultOrder = box.order,
            viewModel = viewModel,
            onDismiss = { editingCashbox = null }
        )
    }

    if (menuAutoBox) {
        val fifoRows = remember(filteredAutoEntries) {
            AutoDebtFifoCalculator.computeOpenDebts(
                filteredAutoEntries.sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
            )
        }
        AlertDialog(
            onDismissRequest = { menuAutoBox = false },
            title = { Text(strings.t("الصندوق الثابت — الصندوق التلقائي", "Automatic Cashbox"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "${strings.t("الفترة:", "Period:")} ${DateHelper.displaySlash(fromDate)} — ${DateHelper.displaySlash(toDate)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    DebtMenuActionButton(strings.t("طباعة كشف للفترة المحددة", "Print Period Statement"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildAutoDebtFifoHtml(fifoRows, false, uiState.settings)
                        viewModel.printHtmlReport(activity, "كشف إجمالي الديون", html)
                        menuAutoBox = false
                    }
                    DebtMenuActionButton(strings.t("طباعة مصادقة للفترة المحددة", "Print Period Authentication"), Icons.Default.Verified) {
                        val html = PrintReportBuilders.buildAutoDebtFifoHtml(fifoRows, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة كشف الديون", html)
                        menuAutoBox = false
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuAutoBox = false }) { Text(strings.close) } }
        )
    }

    menuTargetBox?.let { box ->
        val boxAccounts = uiState.snapshot.debtAccounts.filter { it.cashboxId == box.id }
        val boxAccIds = boxAccounts.map { it.id }.toSet()
        val boxVouchers = filteredVouchers.filter { it.accountId in boxAccIds }

        AlertDialog(
            onDismissRequest = { menuTargetBox = null },
            title = { Text(box.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "${strings.t("الفترة:", "Period:")} ${DateHelper.displaySlash(fromDate)} — ${DateHelper.displaySlash(toDate)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    DebtMenuActionButton(strings.t("طباعة كشف للفترة المحددة", "Print Statement"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildDebtCashboxHtml(box.name, boxAccounts, boxVouchers, fromDate, toDate, false, uiState.settings)
                        viewModel.printHtmlReport(activity, box.name, html)
                        menuTargetBox = null
                    }
                    DebtMenuActionButton(strings.t("طباعة مصادقة للفترة المحددة", "Print Authentication"), Icons.Default.Verified) {
                        val html = PrintReportBuilders.buildDebtCashboxHtml(box.name, boxAccounts, boxVouchers, fromDate, toDate, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة ${box.name}", html)
                        menuTargetBox = null
                    }
                    DebtMenuActionButton(strings.t("تعديل اسم الصندوق", "Edit Cashbox"), Icons.Default.Edit) {
                        menuTargetBox = null
                        editingCashbox = box
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuTargetBox = null }) { Text(strings.close) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AutoDebtBoxScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val haptic = LocalHapticFeedback.current

    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var sortField by remember { mutableStateOf(DebtSortField.DATE) }
    var sortDir by remember { mutableStateOf(DebtSortDir.ASC) }
    var selectMode by remember { mutableStateOf(false) }
    val selectedIds = remember { mutableStateListOf<String>() }

    var showFifoDialog by remember { mutableStateOf(false) }
    var showManualDialog by remember { mutableStateOf<ClockEntry?>(null) }
    var showCreateManual by remember { mutableStateOf(false) }
    var menuEntry by remember { mutableStateOf<ClockEntry?>(null) }

    val activeSpec = uiState.settings.activeSpecialty

    val visibleEntries = remember(uiState.snapshot.clockEntries, activeSpec, fromDate, toDate, sortField, sortDir) {
        val list = uiState.snapshot.clockEntries
            .filter { it.section == ClockSection.DEBTS }
            .filter { matchesSpecialtyFilter(it.specialtyId, activeSpec) }
            .filter { e ->
                val ef = e.date.ifBlank { e.to }
                val et = e.to.ifBlank { e.date }
                (fromDate.isBlank() || et.isBlank() || et >= fromDate) &&
                    (toDate.isBlank() || ef.isBlank() || ef <= toDate)
            }
        val comparator = when (sortField) {
            DebtSortField.DATE -> compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp }
            DebtSortField.NAME -> compareBy<ClockEntry> { it.name }.thenBy { it.date }
            DebtSortField.AMOUNT -> compareBy<ClockEntry> { abs(it.amount) }.thenBy { it.date }
        }
        val sorted = list.sortedWith(comparator)
        if (sortDir == DebtSortDir.DESC) sorted.reversed() else sorted
    }

    val totals = remember(visibleEntries) {
        var pay = 0.0
        var debt = 0.0
        visibleEntries.forEach { e ->
            val amt = abs(e.amount)
            if (e.dir == "عليكم") debt += amt else pay += amt
        }
        DebtTotals(pay = pay, debt = debt)
    }

    val fifoRows = remember(visibleEntries) {
        AutoDebtFifoCalculator.computeOpenDebts(
            visibleEntries.sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
        )
    }

    Scaffold(
        topBar = {
            DebtsTopLuxuryBar(
                title = strings.t("الصندوق التلقائي", "Automatic Cashbox"),
                onBack = onBack,
                actions = {
                    DebtsHeaderActionButton("", Icons.Default.Inventory2, onClick = { showFifoDialog = true }, testTag = "auto_debt_fifo_btn")
                    DebtsHeaderActionButton(strings.t("طباعة", "Print"), Icons.Default.Print, onClick = {
                        val html = PrintReportBuilders.buildAutoDebtFifoHtml(fifoRows, false, uiState.settings)
                        viewModel.printHtmlReport(activity, "صندوق الديون التلقائي", html)
                    })
                    DebtsHeaderActionButton(strings.t("مصادقة", "Auth"), Icons.Default.Verified, onClick = {
                        val html = PrintReportBuilders.buildAutoDebtFifoHtml(fifoRows, true, uiState.settings)
                        viewModel.printHtmlReport(activity, "مصادقة الصندوق التلقائي", html)
                    })
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showCreateManual = true },
                contentDescription = strings.t("إضافة سند دين", "Add Debt Voucher"),
                modifier = Modifier.testTag("auto_debt_add_fab")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 92.dp)
        ) {
            item(key = "controls") {
                DebtsControlStrip(
                    specialties = uiState.settings.specialties,
                    activeSpecialty = activeSpec,
                    onSelectSpecialty = viewModel::setHomeSpecialty,
                    onAddSpecialty = viewModel::addHomeSpecialty,
                    selectAllChecked = selectMode && visibleEntries.isNotEmpty() && selectedIds.size == visibleEntries.size,
                    onToggleSelectAll = {
                        if (selectMode && selectedIds.size == visibleEntries.size) {
                            selectMode = false
                            selectedIds.clear()
                        } else {
                            selectMode = true
                            selectedIds.clear()
                            selectedIds.addAll(visibleEntries.map { it.id })
                        }
                    },
                    totals = totals,
                    sortField = sortField,
                    sortDir = sortDir,
                    onSortFieldChange = { sortField = it },
                    onSortDirChange = { sortDir = it },
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            if (selectMode) {
                item(key = "bulk_bar") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val toDel = visibleEntries.filter { it.id in selectedIds }
                                if (toDel.isNotEmpty()) {
                                    viewModel.deleteClockEntries(toDel)
                                    selectedIds.clear()
                                    selectMode = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f).heightIn(min = 46.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.t("حذف المحدد (${selectedIds.size})", "Delete (${selectedIds.size})"))
                        }
                        OutlinedButton(
                            onClick = { selectMode = false; selectedIds.clear() },
                            modifier = Modifier.heightIn(min = 46.dp)
                        ) { Text(strings.cancel) }
                    }
                }
            }

            if (visibleEntries.isEmpty()) {
                item(key = "empty") {
                    EmptyStateView(
                        icon = Icons.Default.MoveToInbox,
                        title = strings.t("لا توجد سندات دين ضمن الفترة المحددة", "No Debt Entries in Period")
                    )
                }
            } else {
                items(visibleEntries, key = { it.id }) { entry ->
                    val isSelected = entry.id in selectedIds
                    AutoDebtSlipCard(
                        entry = entry,
                        selectMode = selectMode,
                        isSelected = isSelected,
                        onClick = {
                            if (selectMode) {
                                if (isSelected) selectedIds.remove(entry.id) else selectedIds.add(entry.id)
                            } else if (entry.kind.isBlank() || !entry.auto) {
                                showManualDialog = entry
                            } else {
                                viewModel.emitMessage(strings.t("سند مرحّل من التفصيل — عدّله من صفحة التفصيل ليُحدَّث تلقائياً", "Auto entry from Detail — edit in Detail screen"))
                            }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuEntry = entry
                        }
                    )
                }
            }
        }
    }

    if (showFifoDialog) {
        AlertDialog(
            onDismissRequest = { showFifoDialog = false },
            title = { Text(strings.t("الديون المفتوحة (FIFO)", "Open Debts (FIFO)"), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.heightIn(max = 360.dp)) {
                    if (fifoRows.isEmpty()) {
                        Text(strings.t("جميع الديون التلقائية مسددة", "All automatic debts are settled"))
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(fifoRows) { r ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(r.customerName, fontWeight = FontWeight.Bold)
                                        Text("${DateHelper.displaySlash(r.date)} • ${r.detailTitle}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Text(fmt(r.remainingDebt), color = AppColors.DebitRed, fontWeight = FontWeight.Bold)
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val html = PrintReportBuilders.buildAutoDebtFifoHtml(fifoRows, false, uiState.settings)
                    viewModel.printHtmlReport(activity, "صندوق الديون التلقائي", html)
                }) { Text(strings.print) }
            },
            dismissButton = { TextButton(onClick = { showFifoDialog = false }) { Text(strings.close) } }
        )
    }

    if (showCreateManual || showManualDialog != null) {
        AutoDebtManualEntryDialog(
            existing = showManualDialog,
            defaultSpecialtyId = if (activeSpec in listOf("all", "none")) "" else activeSpec,
            specialties = uiState.settings.specialties,
            viewModel = viewModel,
            onDismiss = { showCreateManual = false; showManualDialog = null }
        )
    }

    menuEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { menuEntry = null },
            title = { Text(strings.t("خيارات المعاملة", "Entry Options"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DebtMenuActionButton(strings.t("تحديد المعاملة", "Select Entry"), Icons.Default.CheckBox) {
                        selectMode = true
                        if (entry.id !in selectedIds) selectedIds.add(entry.id)
                        menuEntry = null
                    }
                    DebtMenuActionButton(strings.t("تحديد الكل", "Select All"), Icons.Default.SelectAll) {
                        selectMode = true
                        selectedIds.clear()
                        selectedIds.addAll(visibleEntries.map { it.id })
                        menuEntry = null
                    }
                    if (!entry.auto || entry.kind.isBlank()) {
                        DebtMenuActionButton(strings.t("تعديل المعاملة", "Edit Entry"), Icons.Default.Edit) {
                            menuEntry = null
                            showManualDialog = entry
                        }
                    }
                    DebtMenuActionButton(strings.t("حذف المعاملة", "Delete Entry"), Icons.Default.Delete, isDestructive = true) {
                        viewModel.deleteClockEntry(entry)
                        menuEntry = null
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuEntry = null }) { Text(strings.close) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AutoDebtSlipCard(
    entry: ClockEntry,
    selectMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val isReceived = entry.kind == "received"
    val isDebtSale = entry.kind == "debtsale"
    val isCredit = entry.dir != "عليكم"

    val borderCol = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isReceived || (!isDebtSale && isCredit) -> AppColors.CreditGreen
        else -> AppColors.DebitRed
    }
    val periodText = if (entry.to.isNotBlank() && entry.to != entry.from && entry.to != entry.date) {
        "${strings.t("من", "From")} ${DateHelper.displaySlash(entry.date)} ${strings.t("إلى", "To")} ${DateHelper.displaySlash(entry.to)}"
    } else {
        DateHelper.displaySlash(entry.date)
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (isSelected) 3.dp else 2.dp, borderCol),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Top Slip Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isCredit) AppColors.CreditGreen.copy(alpha = 0.10f)
                        else AppColors.DebitRed.copy(alpha = 0.10f)
                    )
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (selectMode) {
                        Icon(
                            if (isSelected) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = when {
                            isReceived -> strings.t("لكم مسلم فلوس", "Paid Money (لكم)")
                            isDebtSale -> strings.t("عليكم بيع دين", "Debt Sale (عليكم)")
                            isCredit -> strings.t("لكم", "Credit")
                            else -> strings.t("عليكم", "Debt")
                        },
                        fontWeight = FontWeight.Black,
                        color = if (isCredit) AppColors.CreditGreen else AppColors.DebitRed,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                Text(
                    text = entry.name.ifBlank { "—" },
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                Text(
                    text = periodText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Sub-rows table
            if (isReceived && entry.subRows.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary).padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(strings.t("الاسم", "Name"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(2f), textAlign = TextAlign.Center)
                    Text(strings.t("المبلغ", "Amount"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                }
                entry.subRows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(row.name.ifBlank { "—" }, modifier = Modifier.weight(2f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Text(fmt(row.amount), modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            } else if (isDebtSale && entry.subRows.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(strings.t("الاسم", "Name"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(2f), textAlign = TextAlign.Center)
                    Text(strings.t("الكمية", "Qty"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text(strings.t("المبلغ", "Amt"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center)
                    Text(strings.t("المتبقي", "Rest"), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center)
                }
                entry.subRows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(row.name.ifBlank { "—" }, modifier = Modifier.weight(2f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Text(if (row.qty > 0.0) fmt(row.qty) else "—", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                        Text(fmt(row.amount), modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                        Text(
                            fmt(row.rest),
                            modifier = Modifier.weight(1.2f),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (settings.dark) AppColors.DebitRedDark else AppColors.DebitRed,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            } else if (entry.note.isNotBlank()) {
                Text(
                    text = entry.note,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            // Total Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.t("المجموع", "Total"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = fmt(abs(entry.amount)),
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = if (isCredit) AppColors.CreditGreen else AppColors.DebitRed
                )
            }
        }
    }
}

@Composable
private fun AutoDebtManualEntryDialog(
    existing: ClockEntry?,
    defaultSpecialtyId: String,
    specialties: List<Specialty>,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var dir by remember { mutableStateOf(existing?.dir ?: "لكم") }
    var date by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var spId by remember { mutableStateOf(existing?.specialtyId?.ifBlank { defaultSpecialtyId } ?: defaultSpecialtyId) }
    val rows = remember {
        mutableStateListOf<Pair<String, String>>().apply {
            val sub = existing?.subRows.orEmpty()
            if (sub.isNotEmpty()) {
                sub.forEach { add(it.name to WesternDigits.rawNumberString(it.amount)) }
            } else if (existing != null) {
                add(existing.name to WesternDigits.rawNumberString(existing.amount))
            } else {
                add("" to "")
            }
        }
    }
    var showDatePicker by remember { mutableStateOf(false) }

    val totalAmt = rows.sumOf { num(it.second) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                strings.t(if (existing != null) "تعديل سند دين تلقائي" else "سند دين: صندوق الديون التلقائي", "Auto Debt Entry"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = WesternDigits.toWestern(it) },
                    label = { Text(strings.date) },
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = strings.date)
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                rows.forEachIndexed { idx, (nm, amt) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NameSuggestTextField(
                            value = nm,
                            onValueChange = { rows[idx] = it to amt },
                            label = strings.t("الاسم", "Name"),
                            modifier = Modifier.weight(1.3f)
                        )
                        WesternNumberField(
                            value = amt,
                            onValueChange = { rows[idx] = nm to it },
                            label = strings.amount,
                            modifier = Modifier.weight(1f)
                        )
                        if (rows.size > 1) {
                            IconButton(onClick = { rows.removeAt(idx) }, modifier = Modifier.size(40.dp)) {
                                Icon(Icons.Default.Close, contentDescription = strings.delete)
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = { rows.add("" to "") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.t("إضافة صف", "Add Row"))
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(strings.t("الجملة", "Total"), fontWeight = FontWeight.Bold)
                        Text(fmt(totalAmt), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    }
                }

                SpecialtyAssignDropdown(
                    specialties = specialties,
                    selectedId = spId,
                    onAssign = { spId = it },
                    onAddSpecialty = { n, w -> viewModel.addHomeSpecialty(n, w) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = dir == "لكم", onClick = { dir = "لكم" }, label = { Text(strings.credit) }, modifier = Modifier.weight(1f))
                    FilterChip(selected = dir == "عليكم", onClick = { dir = "عليكم" }, label = { Text(strings.debit) }, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (totalAmt > 0.0) {
                    val cleanRows = rows.mapNotNull { (nm, amt) ->
                        val a = num(amt)
                        if (nm.isNotBlank() || a > 0.0) ClockDebtSubRow(name = nm.trim(), amount = a, rest = a) else null
                    }
                    val title = cleanRows.joinToString("، ") { it.name }.ifBlank { strings.t("سند دين", "Debt Entry") }
                    val entry = existing?.copy(
                        specialtyId = spId,
                        dir = dir,
                        amount = totalAmt,
                        name = title,
                        date = date.trim().ifBlank { DateHelper.todayIso() },
                        subRows = cleanRows,
                        auto = false
                    ) ?: ClockEntry(
                        section = ClockSection.DEBTS,
                        specialtyId = spId,
                        dir = dir,
                        amount = totalAmt,
                        name = title,
                        date = date.trim().ifBlank { DateHelper.todayIso() },
                        time = DateHelper.nowTime(),
                        subRows = cleanRows,
                        auto = false
                    )
                    viewModel.saveClockEntry(entry)
                    onDismiss()
                }
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )

    if (showDatePicker) {
        IsoDatePickerDialog(
            initialIso = date,
            onPicked = { date = it; showDatePicker = false },
            onDismiss = { showDatePicker = false }
        )
    }
}
