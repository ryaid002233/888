package com.example.ui.components

import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.domain.AppLockSettings
import com.example.ui.theme.AppColors
import com.example.ui.theme.AppFonts
import com.example.ui.theme.LocalAppStrings
import kotlinx.coroutines.delay

private val SplashBgTop = Color(0xFF02060F)
private val SplashBgMid = Color(0xFF050D1E)
private val SplashGold = Color(0xFFF5CF7B)
private val SplashGoldBright = Color(0xFFFFEA9F)
private val SplashGoldDark = Color(0xFFB88828)
private val SplashMuted = Color(0xFF8C9BA8)
private val SplashBlueGlow = Color(0xFF006EFF)

/**
 * Faithful Jetpack Compose recreation of the luxury welcome splash screen with fast startup speed.
 */
@Composable
fun LuxurySplashOverlay(onFinished: () -> Unit) {
    val strings = LocalAppStrings.current
    val infinite = rememberInfiniteTransition(label = "splash_anim")
    val spinDeg by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing)),
        label = "dashed_spin"
    )
    val particleFloat by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particles"
    )

    val emblemScale = remember { Animatable(0.84f) }
    val contentAlpha = remember { Animatable(0f) }
    val loaderProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        emblemScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
        )
    }

    LaunchedEffect(Unit) {
        contentAlpha.animateTo(1f, animationSpec = tween(260, easing = FastOutSlowInEasing))
    }

    LaunchedEffect(Unit) {
        delay(80L)
        loaderProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 880, easing = FastOutSlowInEasing)
        )
        delay(110L)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(SplashBgTop, SplashBgMid, SplashBgTop)
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onFinished
            )
            .testTag("luxury_splash_screen")
    ) {
        // Radial blue top glow, bottom gold waves, and floating luminous particles
        Canvas(modifier = Modifier.fillMaxSize()) {
            val topSpot = Offset(size.width * 0.5f, size.height * 0.28f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(SplashBlueGlow.copy(alpha = 0.28f), Color.Transparent),
                    center = topSpot,
                    radius = size.maxDimension * 0.52f
                ),
                center = topSpot,
                radius = size.maxDimension * 0.52f
            )

            val botGoldSpot = Offset(size.width * 0.5f, size.height * 0.88f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(SplashGoldDark.copy(alpha = 0.16f), Color.Transparent),
                    center = botGoldSpot,
                    radius = size.maxDimension * 0.45f
                ),
                center = botGoldSpot,
                radius = size.maxDimension * 0.45f
            )

            // Floating gold particles
            val particles = listOf(
                Offset(0.20f, 0.70f) to 0.0f,
                Offset(0.80f, 0.60f) to 0.35f,
                Offset(0.50f, 0.75f) to 0.65f,
                Offset(0.28f, 0.34f) to 0.20f,
                Offset(0.75f, 0.28f) to 0.50f
            )
            particles.forEach { (pos, phase) ->
                val t = (particleFloat + phase) % 1f
                val alpha = kotlin.math.sin(t * Math.PI).toFloat() * 0.78f
                val px = size.width * pos.x
                val py = size.height * pos.y - (t * 72.dp.toPx())
                drawCircle(
                    color = SplashGold.copy(alpha = alpha * 0.35f),
                    radius = 7.dp.toPx(),
                    center = Offset(px, py)
                )
                drawCircle(
                    color = SplashGoldBright.copy(alpha = alpha),
                    radius = 2.2.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }

        // 4 Golden L-shaped corner brackets inside safe insets
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp)
                .alpha(contentAlpha.value)
        ) {
            val len = 28.dp.toPx()
            val strokeW = 1.3.dp.toPx()
            val bracketColor = SplashGold.copy(alpha = 0.62f)
            val w = size.width
            val h = size.height

            // Top-Left
            drawLine(bracketColor, Offset(0f, 0f), Offset(len, 0f), strokeW)
            drawLine(bracketColor, Offset(0f, 0f), Offset(0f, len), strokeW)
            // Top-Right
            drawLine(bracketColor, Offset(w - len, 0f), Offset(w, 0f), strokeW)
            drawLine(bracketColor, Offset(w, 0f), Offset(w, len), strokeW)
            // Bottom-Left
            drawLine(bracketColor, Offset(0f, h - len), Offset(0f, h), strokeW)
            drawLine(bracketColor, Offset(0f, h), Offset(len, h), strokeW)
            // Bottom-Right
            drawLine(bracketColor, Offset(w, h - len), Offset(w, h), strokeW)
            drawLine(bracketColor, Offset(w - len, h), Offset(w, h), strokeW)
        }

        // Center content matching index_0088c0bb.html
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 56.dp)
                .alpha(contentAlpha.value)
        ) {
            // Circular Emblem (220dp)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(220.dp)
                    .scale(emblemScale.value)
            ) {
                // Soft outer blue & gold glow
                Canvas(modifier = Modifier.size(240.dp)) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF0078FF).copy(alpha = 0.42f),
                                SplashGold.copy(alpha = 0.16f),
                                Color.Transparent
                            )
                        )
                    )
                }

                // Outer disc + gold border + inner ring + rotating dashed ring
                Box(
                    modifier = Modifier
                        .size(216.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF1D61CD),
                                    Color(0xFF071F4F),
                                    Color(0xFF020A1C)
                                ),
                                center = Offset(150f, 150f),
                                radius = 420f
                            )
                        )
                        .border(BorderStroke(3.2.dp, SplashGold), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val inset1 = 5.dp.toPx()
                        drawCircle(
                            color = SplashGold.copy(alpha = 0.65f),
                            radius = (size.minDimension / 2f) - inset1,
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }

                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(spinDeg)
                    ) {
                        val inset2 = 10.dp.toPx()
                        drawCircle(
                            color = SplashGold.copy(alpha = 0.38f),
                            radius = (size.minDimension / 2f) - inset2,
                            style = Stroke(
                                width = 1.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                            )
                        )
                    }

                    // Curved metallic silver wires inside middle of emblem
                    Canvas(
                        modifier = Modifier
                            .padding(top = 50.dp)
                            .width(150.dp)
                            .height(74.dp)
                            .align(Alignment.TopCenter)
                    ) {
                        val sx = size.width / 150f
                        val sy = size.height / 74f
                        val wireBrush = Brush.linearGradient(
                            colors = listOf(Color.White, Color(0xFFA0B8D8), Color(0xFF5577A8))
                        )
                        val curves = listOf(
                            listOf(30f, 10f, 15f, 25f, 20f, 55f, 65f, 62f),
                            listOf(40f, 10f, 25f, 30f, 32f, 58f, 75f, 64f),
                            listOf(50f, 10f, 40f, 35f, 45f, 60f, 85f, 65f),
                            listOf(62f, 10f, 55f, 40f, 62f, 62f, 95f, 65f),
                            listOf(88f, 10f, 95f, 40f, 88f, 62f, 105f, 65f),
                            listOf(100f, 10f, 110f, 35f, 105f, 60f, 115f, 65f),
                            listOf(110f, 10f, 125f, 30f, 118f, 58f, 125f, 64f),
                            listOf(120f, 10f, 135f, 25f, 130f, 55f, 135f, 62f)
                        )
                        curves.forEach { c ->
                            val path = Path().apply {
                                moveTo(c[0] * sx, c[1] * sy)
                                cubicTo(
                                    c[2] * sx, c[3] * sy,
                                    c[4] * sx, c[5] * sy,
                                    c[6] * sx, c[7] * sy
                                )
                            }
                            drawPath(
                                path = path,
                                brush = wireBrush,
                                alpha = 0.86f,
                                style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }

                    // Inner vertical emblem content: Icon box + labels
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 22.dp, bottom = 18.dp, start = 14.dp, end = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top rounded icon box
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFF184C98), Color(0xFF061633))
                                    )
                                )
                                .border(2.dp, Color(0xFFA4C7FF), RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Top-right glowing dot
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 10.dp, end = 11.dp)
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF7FB2FF))
                            )
                            // White geometric arch vector
                            Canvas(modifier = Modifier.size(40.dp)) {
                                val u = size.minDimension / 24f
                                val outerArch = Path().apply {
                                    moveTo(4f * u, 18f * u)
                                    lineTo(4f * u, 9.5f * u)
                                    lineTo(12f * u, 4f * u)
                                    lineTo(20f * u, 9.5f * u)
                                    lineTo(20f * u, 18f * u)
                                }
                                val innerArch = Path().apply {
                                    moveTo(9f * u, 18f * u)
                                    lineTo(9f * u, 12f * u)
                                    lineTo(12f * u, 10f * u)
                                    lineTo(15f * u, 12f * u)
                                    lineTo(15f * u, 18f * u)
                                }
                                val strokeStyle = Stroke(
                                    width = 3.2.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                                drawPath(outerArch, Color.White, style = strokeStyle)
                                drawPath(innerArch, Color.White, style = strokeStyle)
                            }
                        }

                        // Bottom labels inside the circle
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = strings.appTitle,
                                fontFamily = AppFonts.Cairo,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                style = TextStyle(
                                    shadow = Shadow(
                                        color = SplashBlueGlow,
                                        offset = Offset(0f, 2f),
                                        blurRadius = 12f
                                    )
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(SplashGold, SplashGoldBright, SplashGold)
                                        )
                                    )
                                    .padding(horizontal = 12.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = strings.t("تصميم رياض اليافعي", "Design: Riyadh Al-Yafei"),
                                    fontFamily = AppFonts.Cairo,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF071633),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(22.dp))

            // Main Title with luxury vertical gold-to-white gradient
            Text(
                text = strings.t("الإداري برو", "Al-Idari Pro"),
                fontFamily = AppFonts.Cairo,
                fontSize = 36.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.White, SplashGoldBright, SplashGold, SplashGoldDark)
                    ),
                    shadow = Shadow(
                        color = Color.Black.copy(alpha = 0.65f),
                        offset = Offset(0f, 4f),
                        blurRadius = 10f
                    )
                )
            )

            Spacer(Modifier.height(10.dp))

            // Diamond Divider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.widthIn(max = 260.dp).fillMaxWidth(0.7f)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(
                            Brush.horizontalGradient(listOf(Color.Transparent, SplashGold))
                        )
                )
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .rotate(45f)
                        .background(SplashGoldBright)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(
                            Brush.horizontalGradient(listOf(SplashGold, Color.Transparent))
                        )
                )
            }

            Spacer(Modifier.height(10.dp))

            Text(
                text = strings.t("نظام إدارة عصري", "Modern Management System"),
                fontFamily = AppFonts.Cairo,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFE0E6ED),
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(28.dp))

            // Golden Progress Loader Capsule
            Box(
                modifier = Modifier
                    .width(230.dp)
                    .height(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.10f))
                    .border(1.dp, SplashGold.copy(alpha = 0.45f), RoundedCornerShape(50))
                    .padding(1.5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = loaderProgress.value.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(50))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(SplashGoldDark, SplashGoldBright, SplashGold)
                            )
                        )
                )
            }
        }

        // Bottom Footer Credits
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.width(34.dp).height(1.dp).background(SplashGold.copy(alpha = 0.35f)))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = SplashMuted, fontWeight = FontWeight.Normal)) {
                        append(strings.t("من تصميم ", "Designed by "))
                    }
                    withStyle(SpanStyle(color = SplashGoldBright, fontWeight = FontWeight.Bold)) {
                        append(strings.t("رياض اليافعي", "Riyadh Al-Yafei"))
                    }
                },
                fontFamily = AppFonts.Cairo,
                fontSize = 12.sp
            )
            Box(Modifier.width(34.dp).height(1.dp).background(SplashGold.copy(alpha = 0.35f)))
        }
    }
}

@Composable
fun AppLockScreen(
    lockSettings: AppLockSettings,
    onVerifyPin: (String) -> Boolean,
    onBiometricSuccess: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var entered by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    val targetLen = lockSettings.pin.length.coerceAtLeast(4)

    fun triggerBiometric() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && lockSettings.biometric) {
            val activity = context.findActivityOrNull() ?: return
            try {
                val prompt = BiometricPrompt.Builder(activity)
                    .setTitle(strings.appTitle)
                    .setSubtitle(strings.t("افتح القفل بالبصمة", "Unlock with Biometrics"))
                    .setNegativeButton(
                        strings.t("استخدام الرمز", "Use PIN"),
                        ContextCompat.getMainExecutor(activity)
                    ) { _, _ -> }
                    .build()
                prompt.authenticate(
                    CancellationSignal(),
                    ContextCompat.getMainExecutor(activity),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            onBiometricSuccess()
                        }
                    }
                )
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(lockSettings.biometric) {
        if (lockSettings.biometric) triggerBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(AppColors.NavyDeep, Color(0xFF0A193A)))
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(AppColors.GoldAccent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = AppColors.GoldLight, modifier = Modifier.size(34.dp))
            }

            Text(
                text = strings.t("التطبيق مقفل", "App Locked"),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(targetLen) { idx ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (idx < entered.length) AppColors.GoldAccent
                                else Color.White.copy(alpha = 0.25f)
                            )
                    )
                }
            }

            if (errorMsg.isNotBlank()) {
                Text(errorMsg, color = AppColors.DebitRedDark, style = MaterialTheme.typography.bodySmall)
            }

            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("BIO", "0", "DEL")
            )

            keys.forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    row.forEach { k ->
                        when (k) {
                            "BIO" -> {
                                if (lockSettings.biometric && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    FilledTonalButton(
                                        onClick = { triggerBiometric() },
                                        shape = CircleShape,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(62.dp)
                                    ) {
                                        Icon(Icons.Default.Fingerprint, contentDescription = "Biometric")
                                    }
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                            "DEL" -> {
                                FilledTonalButton(
                                    onClick = { if (entered.isNotEmpty()) entered = entered.dropLast(1) },
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = strings.delete)
                                }
                            }
                            else -> {
                                ElevatedButton(
                                    onClick = {
                                        errorMsg = ""
                                        if (entered.length < targetLen) {
                                            entered += k
                                            if (entered.length == targetLen) {
                                                if (!onVerifyPin(entered)) {
                                                    errorMsg = strings.t("الرمز غير صحيح", "Incorrect PIN")
                                                    entered = ""
                                                }
                                            }
                                        }
                                    },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.14f),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                        .testTag("pin_key_$k")
                                ) {
                                    Text(k, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

tailrec fun Context.findActivityOrNull(): android.app.Activity? = when (this) {
    is android.app.Activity -> this
    is ContextWrapper -> baseContext.findActivityOrNull()
    else -> null
}
