package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import java.util.Calendar
import java.util.Locale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.rememberAsyncImagePainter
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.sp
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.theme.LocalOnRemoveSavedName
import com.example.ui.theme.LocalSavedNames
import java.io.File

@Composable
fun AppBackgroundLayer(content: @Composable () -> Unit) {
    val settings = LocalAppSettings.current
    val bgPath = settings.appearance.backgroundPath
    val alpha = (settings.appearance.backgroundOpacity.coerceIn(10, 100) / 100f) * 0.28f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (bgPath.isNotBlank() && File(bgPath).exists()) {
            Image(
                painter = rememberAsyncImagePainter(File(bgPath)),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(alpha)
            )
        }
        content()
    }
}

@Composable
fun StyledAppCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val tokens = LocalFrameTokens.current
    val shape = RoundedCornerShape(tokens.cornerRadius)
    val style = tokens.frameStyle
    val hasBorder = tokens.frameEnabled && tokens.borderWidth > 0.dp && style != "none"
    val border = if (hasBorder && style == "solid") BorderStroke(tokens.borderWidth, tokens.borderColor) else null
    val effectiveColor = if (tokens.isGlass) containerColor.copy(alpha = 0.90f) else containerColor

    val customBorderMod = if (hasBorder && style != "solid") {
        Modifier.drawWithContent {
            drawContent()
            val strokePx = tokens.borderWidth.toPx().coerceAtLeast(1.5f)
            val radiusPx = tokens.cornerRadius.toPx()
            val cr = CornerRadius(radiusPx, radiusPx)
            val inset = strokePx / 2f
            val boxSize = Size((size.width - strokePx).coerceAtLeast(0f), (size.height - strokePx).coerceAtLeast(0f))
            when (style) {
                "dashed" -> drawRoundRect(
                    color = tokens.borderColor,
                    topLeft = Offset(inset, inset),
                    size = boxSize,
                    cornerRadius = cr,
                    style = Stroke(
                        width = strokePx,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                    )
                )
                "dotted" -> drawRoundRect(
                    color = tokens.borderColor,
                    topLeft = Offset(inset, inset),
                    size = boxSize,
                    cornerRadius = cr,
                    style = Stroke(
                        width = strokePx,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 7f), 0f)
                    )
                )
                "double" -> {
                    val outerW = (strokePx * 0.65f).coerceAtLeast(1.2f)
                    val gap = outerW * 2.2f
                    drawRoundRect(
                        color = tokens.borderColor,
                        topLeft = Offset(outerW / 2f, outerW / 2f),
                        size = Size((size.width - outerW).coerceAtLeast(0f), (size.height - outerW).coerceAtLeast(0f)),
                        cornerRadius = cr,
                        style = Stroke(width = outerW)
                    )
                    val innerCr = CornerRadius((radiusPx - gap).coerceAtLeast(0f), (radiusPx - gap).coerceAtLeast(0f))
                    drawRoundRect(
                        color = tokens.borderColor.copy(alpha = tokens.borderColor.alpha * 0.8f),
                        topLeft = Offset(gap, gap),
                        size = Size((size.width - gap * 2f).coerceAtLeast(0f), (size.height - gap * 2f).coerceAtLeast(0f)),
                        cornerRadius = innerCr,
                        style = Stroke(width = outerW)
                    )
                }
                "groove", "ridge", "inset", "outset" -> {
                    val light = Color.White.copy(alpha = 0.55f)
                    val dark = tokens.borderColor.copy(alpha = 0.85f)
                    val primaryCol = if (style == "inset" || style == "groove") dark else light
                    val secondaryCol = if (style == "inset" || style == "groove") light else dark
                    drawRoundRect(
                        color = primaryCol,
                        topLeft = Offset(inset, inset),
                        size = boxSize,
                        cornerRadius = cr,
                        style = Stroke(width = strokePx)
                    )
                    drawRoundRect(
                        color = secondaryCol,
                        topLeft = Offset(strokePx * 1.4f, strokePx * 1.4f),
                        size = Size((size.width - strokePx * 2.8f).coerceAtLeast(0f), (size.height - strokePx * 2.8f).coerceAtLeast(0f)),
                        cornerRadius = cr,
                        style = Stroke(width = (strokePx * 0.7f).coerceAtLeast(1f))
                    )
                }
                else -> drawRoundRect(
                    color = tokens.borderColor,
                    topLeft = Offset(inset, inset),
                    size = boxSize,
                    cornerRadius = cr,
                    style = Stroke(width = strokePx)
                )
            }
        }
    } else Modifier

    val baseMod = modifier
        .clip(shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }

    Surface(
        modifier = baseMod.then(customBorderMod),
        shape = shape,
        color = effectiveColor,
        tonalElevation = tokens.elevation,
        shadowElevation = tokens.elevation,
        border = border
    ) {
        Column(content = content)
    }
}

@Composable
fun CreditDebitPill(
    isCredit: Boolean,
    labelCredit: String = LocalAppStrings.current.credit,
    labelDebit: String = LocalAppStrings.current.debit
) {
    val settings = LocalAppSettings.current
    val bg = when {
        isCredit && settings.dark -> AppColors.CreditGreenContainerDark
        isCredit -> AppColors.CreditGreenContainerLight
        settings.dark -> AppColors.DebitRedContainerDark
        else -> AppColors.DebitRedContainerLight
    }
    val fg = when {
        isCredit && settings.dark -> AppColors.CreditGreenDark
        isCredit -> AppColors.CreditGreen
        settings.dark -> AppColors.DebitRedDark
        else -> AppColors.DebitRed
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = bg
    ) {
        Text(
            text = if (isCredit) labelCredit else labelDebit,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun WesternNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    allowDecimal: Boolean = true,
    readOnly: Boolean = false,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val clean = if (allowDecimal) {
                WesternDigits.cleanNumericInput(raw)
            } else {
                WesternDigits.toWestern(raw).filter { it.isDigit() }
            }
            onValueChange(clean)
        },
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        singleLine = true,
        readOnly = readOnly,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (allowDecimal) KeyboardType.Decimal else KeyboardType.Number
        ),
        trailingIcon = trailingIcon,
        modifier = modifier
    )
}

private val ArabicMonthNames = listOf(
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
)

private val ArabicWeekdayShortNames = listOf(
    "سبت", "أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة"
)

private val ArabicWeekdayFullNames = listOf(
    "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
)

@Composable
fun AppDatePickerDialog(
    initialIso: String,
    onPicked: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current

    val todayTriple = remember {
        val cal = Calendar.getInstance(Locale.US)
        Triple(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
    }

    val initialTriple = remember(initialIso) {
        val clean = WesternDigits.toWestern(initialIso).trim()
        val parts = clean.split("-", "/")
        val y = parts.getOrNull(0)?.toIntOrNull()
        val m = parts.getOrNull(1)?.toIntOrNull()
        val d = parts.getOrNull(2)?.toIntOrNull()
        if (y != null && y in 1950..2100 && m != null && m in 1..12 && d != null && d in 1..31) {
            val cal = Calendar.getInstance(Locale.US).apply {
                clear()
                set(y, m - 1, 1)
            }
            val maxD = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            Triple(y, m - 1, d.coerceIn(1, maxD))
        } else {
            todayTriple
        }
    }

    var selYear by remember(initialTriple) { mutableIntStateOf(initialTriple.first) }
    var selMonth by remember(initialTriple) { mutableIntStateOf(initialTriple.second) }
    var selDay by remember(initialTriple) { mutableIntStateOf(initialTriple.third) }

    var displayYear by remember(initialTriple) { mutableIntStateOf(initialTriple.first) }
    var displayMonth by remember(initialTriple) { mutableIntStateOf(initialTriple.second) }
    var pickerMode by remember { mutableStateOf("days") } // "days", "months", "years"

    val selectedWeekdayName = remember(selYear, selMonth, selDay) {
        val c = Calendar.getInstance(Locale.US).apply {
            clear()
            set(selYear, selMonth, selDay)
        }
        val idx = (c.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY).coerceIn(0, 6)
        ArabicWeekdayFullNames[idx]
    }

    val monthCells = remember(displayYear, displayMonth) {
        val c = Calendar.getInstance(Locale.US).apply {
            clear()
            set(displayYear, displayMonth, 1)
        }
        val daysInMonth = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        // Saturday = 0, Sunday = 1, ..., Friday = 6 (Calendar.SATURDAY == 7 -> 0, Calendar.SUNDAY == 1 -> 1)
        val leadingEmpty = c.get(Calendar.DAY_OF_WEEK) % 7
        val list = mutableListOf<Int?>()
        repeat(leadingEmpty) { list.add(null) }
        for (d in 1..daysInMonth) list.add(d)
        while (list.size % 7 != 0) list.add(null)
        list
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(16.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
                BorderStroke(1.2.dp, tokens.borderColor)
            } else null,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .widthIn(max = 400.dp)
                .testTag("arabic_date_picker_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Top Selected Date Banner
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.barBrush)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = strings.t("اختيار التاريخ", "Select Date"),
                        color = tokens.barContent.copy(alpha = 0.78f),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$selectedWeekdayName، $selDay ${ArabicMonthNames[selMonth]} سنة $selYear",
                        color = tokens.barContent,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Month & Year Header Controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = {
                            pickerMode = "days"
                            if (displayMonth == 0) {
                                displayMonth = 11
                                displayYear = (displayYear - 1).coerceAtLeast(1950)
                            } else {
                                displayMonth -= 1
                            }
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الشهر السابق"
                        )
                    }

                    Surface(
                        onClick = { pickerMode = if (pickerMode == "months") "days" else "months" },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = if (pickerMode == "months") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 40.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "شهر ${ArabicMonthNames[displayMonth]}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }

                    Surface(
                        onClick = { pickerMode = if (pickerMode == "years") "days" else "years" },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = if (pickerMode == "years") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 40.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "سنة $displayYear",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }

                    IconButton(
                        onClick = {
                            pickerMode = "days"
                            if (displayMonth == 11) {
                                displayMonth = 0
                                displayYear = (displayYear + 1).coerceAtMost(2100)
                            } else {
                                displayMonth += 1
                            }
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "الشهر التالي"
                        )
                    }
                }

                HorizontalDivider(thickness = 0.8.dp, color = MaterialTheme.colorScheme.outlineVariant)

                when (pickerMode) {
                    "months" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "اختر الشهر",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold
                            )
                            for (r in 0 until 4) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    for (c in 0 until 3) {
                                        val mIdx = r * 3 + c
                                        val isCurrent = mIdx == displayMonth
                                        Surface(
                                            onClick = {
                                                displayMonth = mIdx
                                                pickerMode = "days"
                                            },
                                            shape = RoundedCornerShape(tokens.buttonRadius),
                                            color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(6.dp)) {
                                                Text(
                                                    text = ArabicMonthNames[mIdx],
                                                    color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "years" -> {
                        val years = remember { (1990..2050).toList() }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 260.dp)
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "اختر السنة",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold
                            )
                            years.chunked(3).forEach { rowYears ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowYears.forEach { yr ->
                                        val isCurrent = yr == displayYear
                                        Surface(
                                            onClick = {
                                                displayYear = yr
                                                pickerMode = "days"
                                            },
                                            shape = RoundedCornerShape(tokens.buttonRadius),
                                            color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(4.dp)) {
                                                Text(
                                                    text = "سنة $yr",
                                                    color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Arabic Weekday Headers
                            Row(modifier = Modifier.fillMaxWidth()) {
                                ArabicWeekdayShortNames.forEach { wd ->
                                    Text(
                                        text = wd,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(vertical = 4.dp)
                                    )
                                }
                            }

                            // Calendar Days Grid
                            monthCells.chunked(7).forEach { week ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    week.forEach { dayNum ->
                                        if (dayNum == null) {
                                            Spacer(Modifier.weight(1f).height(40.dp))
                                        } else {
                                            val isSelected = displayYear == selYear && displayMonth == selMonth && dayNum == selDay
                                            val isToday = displayYear == todayTriple.first && displayMonth == todayTriple.second && dayNum == todayTriple.third
                                            Surface(
                                                onClick = {
                                                    selYear = displayYear
                                                    selMonth = displayMonth
                                                    selDay = dayNum
                                                },
                                                shape = CircleShape,
                                                color = when {
                                                    isSelected -> MaterialTheme.colorScheme.primary
                                                    isToday -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                                    else -> Color.Transparent
                                                },
                                                border = if (isToday && !isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(40.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = dayNum.toString(),
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                                        fontSize = 13.sp,
                                                        fontWeight = if (isSelected || isToday) FontWeight.Black else FontWeight.Medium,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(thickness = 0.8.dp, color = MaterialTheme.colorScheme.outlineVariant)

                // Footer Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            selYear = todayTriple.first
                            selMonth = todayTriple.second
                            selDay = todayTriple.third
                            displayYear = todayTriple.first
                            displayMonth = todayTriple.second
                            pickerMode = "days"
                        }
                    ) {
                        Text("اليوم", fontWeight = FontWeight.Bold)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = onDismiss) {
                            Text(strings.cancel)
                        }
                        Button(
                            onClick = {
                                val iso = String.format(Locale.US, "%04d-%02d-%02d", selYear, selMonth + 1, selDay)
                                onPicked(iso)
                            },
                            shape = RoundedCornerShape(tokens.buttonRadius)
                        ) {
                            Text(strings.save, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClickableDateField(
    value: String,
    onDatePicked: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val strings = LocalAppStrings.current
    var showPicker by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is PressInteraction.Release) {
                showPicker = true
            }
        }
    }

    OutlinedTextField(
        value = value,
        onValueChange = {},
        readOnly = true,
        singleLine = true,
        interactionSource = interactionSource,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        trailingIcon = {
            IconButton(
                onClick = { showPicker = true },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.CalendarMonth, contentDescription = strings.date)
            }
        },
        modifier = modifier.let { if (testTag.isNotBlank()) it.testTag(testTag) else it }
    )

    if (showPicker) {
        AppDatePickerDialog(
            initialIso = value,
            onPicked = {
                onDatePicked(it)
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
fun DateRangeBar(
    fromDate: String,
    toDate: String,
    onRangeChange: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var pickingTarget by remember { mutableStateOf<String?>(null) }

    StyledAppCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, -1)
                    onRangeChange(nf, nt)
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("date_shift_prev_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.t("الفترة السابقة", "Previous"), tint = tokens.iconTileTint)
            }

            Surface(
                onClick = { pickingTarget = "from" },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.55f)) else null,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .testTag("date_from_input")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.CalendarMonth,
                        contentDescription = strings.from,
                        tint = tokens.iconTileTint,
                        modifier = Modifier.size(16.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.from,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                        Text(
                            text = fromDate.ifBlank { "yyyy-MM-dd" },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Surface(
                onClick = { pickingTarget = "to" },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.55f)) else null,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .testTag("date_to_input")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.CalendarMonth,
                        contentDescription = strings.to,
                        tint = tokens.iconTileTint,
                        modifier = Modifier.size(16.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.to,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                        Text(
                            text = toDate.ifBlank { "yyyy-MM-dd" },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            IconButton(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, 1)
                    onRangeChange(nf, nt)
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("date_shift_next_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = strings.t("الفترة التالية", "Next"), tint = tokens.iconTileTint)
            }
        }
    }

    if (pickingTarget != null) {
        AppDatePickerDialog(
            initialIso = if (pickingTarget == "from") fromDate else toDate,
            onPicked = { picked ->
                if (pickingTarget == "from") onRangeChange(picked, toDate)
                else onRangeChange(fromDate, picked)
                pickingTarget = null
            },
            onDismiss = { pickingTarget = null }
        )
    }
}

fun matchesSpecialtyFilter(itemSpecialtyId: String, activeSpecialty: String): Boolean = when (activeSpecialty) {
    "all", "" -> true
    "none" -> itemSpecialtyId.isBlank()
    else -> itemSpecialtyId == activeSpecialty
}

@Composable
fun SpecialtyFilterBar(
    specialties: List<Specialty>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    onAddSpecialty: ((name: String, workersAmount: Double) -> Unit)? = null,
    showWorkersAmount: Boolean = true
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var expanded by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    val selectedLabel = when (selectedId) {
        "all", "" -> strings.allSpecialties
        "none" -> strings.noSpecialty
        else -> specialties.firstOrNull { it.id == selectedId }?.name ?: strings.allSpecialties
    }
    val isFiltered = selectedId.isNotBlank() && selectedId != "all"

    Box(modifier = modifier) {
        if (isFiltered) {
            FilledTonalButton(
                onClick = { expanded = true },
                shape = RoundedCornerShape(tokens.buttonRadius),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("specialty_filter_button")
            ) {
                Icon(Icons.Default.Category, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(selectedLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
        } else {
            OutlinedButton(
                onClick = { expanded = true },
                shape = RoundedCornerShape(tokens.buttonRadius),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("specialty_filter_button")
            ) {
                Icon(Icons.Default.Category, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(selectedLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { Text(strings.allSpecialties, fontWeight = if (selectedId == "all" || selectedId.isBlank()) FontWeight.Bold else FontWeight.Normal) },
                leadingIcon = {
                    if (selectedId == "all" || selectedId.isBlank()) Icon(Icons.Default.Check, contentDescription = null)
                    else Icon(Icons.Default.AllInclusive, contentDescription = null)
                },
                onClick = { onSelect("all"); expanded = false }
            )
            DropdownMenuItem(
                text = { Text(strings.noSpecialty, fontWeight = if (selectedId == "none") FontWeight.Bold else FontWeight.Normal) },
                leadingIcon = {
                    if (selectedId == "none") Icon(Icons.Default.Check, contentDescription = null)
                    else Icon(Icons.Default.LabelOff, contentDescription = null)
                },
                onClick = { onSelect("none"); expanded = false }
            )
            if (specialties.isNotEmpty()) {
                HorizontalDivider()
                specialties.forEach { sp ->
                    val isSel = selectedId == sp.id
                    DropdownMenuItem(
                        text = { Text(sp.name, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = {
                            if (isSel) Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            else Icon(Icons.Default.Label, contentDescription = null)
                        },
                        onClick = { onSelect(sp.id); expanded = false }
                    )
                }
            }
            if (onAddSpecialty != null) {
                HorizontalDivider()
                DropdownMenuItem(
                    text = {
                        Text(
                            strings.t("إضافة تخصيص جديد +", "Add Specialty +"),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    onClick = {
                        expanded = false
                        showAddDialog = true
                    }
                )
            }
        }
    }

    if (showAddDialog && onAddSpecialty != null) {
        QuickAddSpecialtyDialog(
            showWorkersAmount = showWorkersAmount,
            onSave = { name, workersAmt ->
                onAddSpecialty(name, workersAmt)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
fun SpecialtyAssignDropdown(
    specialties: List<Specialty>,
    selectedId: String,
    onAssign: (String) -> Unit,
    modifier: Modifier = Modifier,
    onAddSpecialty: ((name: String, workersAmount: Double) -> Unit)? = null,
    showWorkersAmount: Boolean = true
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var expanded by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }
    val selectedName = specialties.firstOrNull { it.id == selectedId }?.name ?: strings.noSpecialty

    Box(modifier = modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            shape = RoundedCornerShape(tokens.buttonRadius),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            modifier = Modifier.heightIn(min = 48.dp)
        ) {
            Icon(Icons.Default.Category, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "${strings.t("التخصيص", "Specialty")}: $selectedName",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { Text(strings.noSpecialty) },
                leadingIcon = {
                    if (selectedId.isBlank()) Icon(Icons.Default.Check, contentDescription = null)
                    else Icon(Icons.Default.LabelOff, contentDescription = null)
                },
                onClick = { onAssign(""); expanded = false }
            )
            if (specialties.isNotEmpty()) {
                HorizontalDivider()
                specialties.forEach { sp ->
                    DropdownMenuItem(
                        text = { Text(sp.name) },
                        leadingIcon = {
                            if (selectedId == sp.id) Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            else Icon(Icons.Default.Label, contentDescription = null)
                        },
                        onClick = { onAssign(sp.id); expanded = false }
                    )
                }
            }
            if (onAddSpecialty != null) {
                HorizontalDivider()
                DropdownMenuItem(
                    text = {
                        Text(
                            strings.t("إضافة تخصيص جديد +", "Add Specialty +"),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    onClick = {
                        expanded = false
                        showAddDialog = true
                    }
                )
            }
        }
    }

    if (showAddDialog && onAddSpecialty != null) {
        QuickAddSpecialtyDialog(
            showWorkersAmount = showWorkersAmount,
            onSave = { name, workersAmt ->
                onAddSpecialty(name, workersAmt)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun QuickAddSpecialtyDialog(
    showWorkersAmount: Boolean,
    onSave: (String, Double) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var spName by remember { mutableStateOf("") }
    var spWorkers by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.t("إضافة تخصيص جديد", "Add New Specialty"), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = spName,
                    onValueChange = { spName = it },
                    label = { Text(strings.t("اسم التخصيص *", "Specialty Name *")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (showWorkersAmount) {
                    WesternNumberField(
                        value = spWorkers,
                        onValueChange = { spWorkers = it },
                        label = strings.t("مبلغ خرج العمال (اختياري)", "Workers Amount (Optional)"),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (spName.isNotBlank()) {
                        onSave(spName.trim(), WesternDigits.num(spWorkers))
                    }
                },
                enabled = spName.isNotBlank()
            ) { Text(strings.save) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun SummaryStatCard(
    title: String,
    value: String,
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    StyledAppCard(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CalculatorDialog(
    initialValue: String = "",
    onResult: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var expr by remember { mutableStateOf(WesternDigits.toWestern(initialValue)) }
    val preview = remember(expr) { SafeExpressionEvaluator.evaluate(expr) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.calculator, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = strings.close)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = expr.ifBlank { "0" },
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.End
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = preview?.let { "= ${fmt(it)}" } ?: "",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                val rows = listOf(
                    listOf("C", "00", "000", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "-"),
                    listOf("1", "2", "3", "+"),
                    listOf("0", ".", "(", ")"),
                    listOf("%", "=")
                )

                rows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row.forEach { key ->
                            val isOp = key in listOf("÷", "×", "-", "+", "=", "C", "00", "000")
                            Button(
                                onClick = {
                                    when (key) {
                                        "C" -> expr = ""
                                        "=" -> preview?.let { expr = rawNumberString(it, 6) }
                                        else -> expr += key
                                    }
                                },
                                colors = if (key == "=") {
                                    ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                } else if (isOp) {
                                    ButtonDefaults.filledTonalButtonColors()
                                } else {
                                    ButtonDefaults.outlinedButtonColors()
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .weight(if (key == "=") 2.2f else 1f)
                                    .height(48.dp)
                            ) {
                                Text(key, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (expr.isNotEmpty()) expr = expr.dropLast(1) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = strings.delete)
                    }
                    Button(
                        onClick = {
                            val res = SafeExpressionEvaluator.evaluate(expr)
                            if (res != null) {
                                onResult(rawNumberString(res, 3))
                                onDismiss()
                            }
                        },
                        enabled = preview != null,
                        modifier = Modifier
                            .weight(2f)
                            .height(48.dp)
                            .testTag("calc_apply_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("اعتماد الناتج", "Use Result"))
                    }
                }
            }
        }
    }
}

@Composable
fun AppImageViewerDialog(
    imagePath: String,
    title: String = "",
    onSaveToGallery: () -> Unit,
    onDelete: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title.ifBlank { strings.t("معاينة الصورة", "Photo Preview") },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = strings.close)
                    }
                }
                Image(
                    painter = rememberAsyncImagePainter(File(imagePath)),
                    contentDescription = title,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 380.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = onSaveToGallery,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.t("حفظ", "Save"), maxLines = 1)
                    }
                    FilledTonalButton(
                        onClick = { ShareHelper.shareImage(context, imagePath) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.share, maxLines = 1)
                    }
                    if (onDelete != null) {
                        IconButton(
                            onClick = { onDelete(); onDismiss() },
                            modifier = Modifier
                                .size(48.dp)
                                .border(1.dp, MaterialTheme.colorScheme.error, CircleShape)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateView(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String = "",
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                            AppColors.GoldAccent.copy(alpha = 0.20f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp)
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ConfirmActionDialog(
    title: String,
    message: String,
    confirmText: String,
    isDestructive: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = { onConfirm(); onDismiss() },
                colors = if (isDestructive) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                else ButtonDefaults.buttonColors()
            ) {
                Text(confirmText)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun NameSuggestTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    singleLine: Boolean = true,
    readOnly: Boolean = false,
    shape: Shape = OutlinedTextFieldDefaults.shape,
    testTag: String = "",
    maxSuggestions: Int = 6,
    extraNames: List<String> = emptyList(),
    onRemoveSuggestion: ((String) -> Unit)? = LocalOnRemoveSavedName.current
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val globalSaved = LocalSavedNames.current
    var isFocused by remember { mutableStateOf(false) }
    var dismissedForValue by remember { mutableStateOf<String?>(null) }

    val mergedPool = remember(extraNames, globalSaved) {
        if (extraNames.isEmpty()) globalSaved
        else NameSuggestionHelper.mergeSavedNames(extraNames, globalSaved)
    }
    val suggestions = remember(value, mergedPool, maxSuggestions) {
        NameSuggestionHelper.suggestNames(
            query = value,
            savedNames = mergedPool,
            limit = maxSuggestions
        )
    }
    val showSuggestions = isFocused && !readOnly && suggestions.isNotEmpty() && dismissedForValue != value

    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = { next ->
                dismissedForValue = null
                onValueChange(next)
            },
            label = if (!label.isNullOrBlank()) {
                { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            } else null,
            placeholder = if (!placeholder.isNullOrBlank()) {
                { Text(placeholder, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            } else null,
            singleLine = singleLine,
            readOnly = readOnly,
            shape = shape,
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { state ->
                    isFocused = state.isFocused
                    if (!state.isFocused) dismissedForValue = null
                }
                .let { if (testTag.isNotBlank()) it.testTag(testTag) else it }
        )

        AnimatedVisibility(visible = showSuggestions) {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                val showRemoveAction = onRemoveSuggestion != null && maxWidth >= 220.dp
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    shadowElevation = 4.dp,
                    border = BorderStroke(
                        1.dp,
                        if (tokens.frameEnabled) tokens.borderColor.copy(alpha = 0.7f)
                        else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = strings.t("الأسماء المقترحة", "Name Suggestions"),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { dismissedForValue = value },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowUp,
                                    contentDescription = strings.t("إخفاء الاقتراحات", "Hide suggestions"),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 192.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            suggestions.forEachIndexed { idx, candidate ->
                                if (idx > 0) {
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                                    )
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .clickable {
                                            dismissedForValue = candidate
                                            onValueChange(candidate)
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = candidate,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (showRemoveAction) {
                                        IconButton(
                                            onClick = { onRemoveSuggestion?.invoke(candidate) },
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = strings.t("إزالة الاسم", "Remove name"),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
