package com.example.ui.navigation

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.theme.LocalOnRemoveSavedName
import com.example.ui.theme.LocalSavedNames
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlinx.coroutines.launch

object AppRoutes {
    const val HOME = "home"
    const val PRIVATE = "private"
    const val BUYER = "buyer"

    const val FOLDERS_HOME = "folders_home"
    const val FOLDERS_BUYER = "folders_buyer"
    const val FOLDER_DETAIL = "folder_detail/{folderId}"
    const val SELLER_INVOICE = "seller_invoice/{folderId}?invoiceId={invoiceId}"
    const val BUYER_INVOICE = "buyer_invoice/{folderId}?invoiceId={invoiceId}"
    const val WEEKLY_FILTERS = "weekly_filters"
    const val WEEKLY_EDITOR = "weekly_editor/{filterId}"
    const val DETAILS_LIST = "details_list"
    const val DETAIL_EDITOR = "detail_editor/{detailId}"
    const val CLOCK_SECTION = "clock_section/{sectionKey}"
    const val DEBT_CASHBOXES = "debt_cashboxes"
    const val AUTO_DEBT_BOX = "auto_debt_box"
    const val DEBT_ACCOUNTS = "debt_accounts/{cashboxId}"
    const val DEBT_LEDGER = "debt_ledger/{accountId}"
    const val TASFEER = "tasfeer"
    const val PRIVATE_FOLDER_ACCOUNTS = "private_folder/{folderId}"
    const val PRIVATE_STATEMENT = "private_statement/{accountId}"
    const val BUYER_TRANSFER = "buyer_transfer"
    const val BUYER_ANNUAL = "buyer_annual"
    const val BUYER_CONTROLLER = "buyer_controller/{mode}"
    const val SETTINGS = "settings?section={section}"

    fun folderDetail(folderId: String) = "folder_detail/${Uri.encode(folderId)}"
    fun sellerInvoice(folderId: String, invoiceId: String? = null) =
        "seller_invoice/${Uri.encode(folderId)}" + (if (invoiceId != null) "?invoiceId=${Uri.encode(invoiceId)}" else "")
    fun buyerInvoice(folderId: String, invoiceId: String? = null) =
        "buyer_invoice/${Uri.encode(folderId)}" + (if (invoiceId != null) "?invoiceId=${Uri.encode(invoiceId)}" else "")
    fun weeklyEditor(filterId: String) = "weekly_editor/${Uri.encode(filterId)}"
    fun detailEditor(detailId: String) = "detail_editor/${Uri.encode(detailId)}"
    fun clockSection(sec: ClockSection) = "clock_section/${sec.key}"
    fun debtAccounts(boxId: String) = "debt_accounts/${Uri.encode(boxId)}"
    fun debtLedger(accId: String) = "debt_ledger/${Uri.encode(accId)}"
    fun privateFolder(folderId: String) = "private_folder/${Uri.encode(folderId)}"
    fun privateStatement(accId: String) = "private_statement/${Uri.encode(accId)}"
    fun buyerController(mode: String) = "buyer_controller/$mode"
    fun settings(section: String = "hub") = "settings?section=${Uri.encode(section)}"
}

@Composable
fun SmartAdminRootApp(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit
) {
    val strings = LocalAppStrings.current
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.toastEvent.collect { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute in setOf(
        AppRoutes.HOME,
        AppRoutes.PRIVATE,
        AppRoutes.PRIVATE_FOLDER_ACCOUNTS,
        AppRoutes.PRIVATE_STATEMENT,
        AppRoutes.BUYER
    )

    val context = LocalContext.current
    val activity = remember(context) {
        var ctx: Context = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) break
            ctx = ctx.baseContext
        }
        ctx as? Activity
    }
    var showExitBackupDialog by remember { mutableStateOf(false) }
    val exitBackupAuthLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.handleGoogleDriveResolutionResult(activity, result.data)
    }

    if (currentRoute == AppRoutes.HOME && uiState.settings.gdriveBackup.backupOnExit && uiState.settings.gdriveBackup.connected && drawerState.isClosed) {
        BackHandler {
            showExitBackupDialog = true
        }
    }

    CompositionLocalProvider(
        LocalSavedNames provides uiState.savedNames,
        LocalOnRemoveSavedName provides viewModel::removeSavedName
    ) {
    AppBackgroundLayer {
        val tokens = LocalFrameTokens.current
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = showBottomBar,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.widthIn(max = 340.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(tokens.barBrush)
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = strings.settings,
                                    color = tokens.barContent,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = strings.t("تخصيص التطبيق", "App Customization"),
                                    color = tokens.barAccent,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(tokens.buttonRadius),
                                color = tokens.barButtonBg,
                                border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = null,
                                        tint = tokens.barAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                    if (tokens.frameEnabled && tokens.frameStyle != "none") {
                        HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .navigationBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Home,
                            title = strings.home,
                            iconTint = Color(0xFF1D4ED8),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.AccountBalance,
                            title = strings.tasfeer,
                            iconTint = Color(0xFF0F766E),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.TASFEER)
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.AccountBalanceWallet,
                            title = strings.t("صناديق الديون", "Debt Cashboxes"),
                            iconTint = Color(0xFFDC2626),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.DEBT_CASHBOXES)
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Person,
                            title = strings.t("الملف الشخصي", "Profile & Branding"),
                            iconTint = Color(0xFF0284C7),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("profile"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.AutoAwesome,
                            title = strings.t("التخصيص", "Specialties"),
                            iconTint = Color(0xFFEAB308),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("specialties"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.ShoppingBag,
                            title = strings.t("تخصيص الشرائي", "Buyer Specialties"),
                            iconTint = Color(0xFF10B981),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("buyer_specialties"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Language,
                            title = strings.t("اللغة ومظهر التطبيق", "Language & Theme"),
                            iconTint = Color(0xFF0284C7),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("appearance"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.MonetizationOn,
                            title = strings.currencies,
                            iconTint = Color(0xFFD97706),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("currencies"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Recycling,
                            title = strings.t("سلة المحذوفات (${uiState.snapshot.trash.size})", "Trash (${uiState.snapshot.trash.size})"),
                            iconTint = Color(0xFF16A34A),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("trash"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Sms,
                            title = strings.t("الرسائل والواتس", "WhatsApp & SMS"),
                            iconTint = Color(0xFF334155),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("messages"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Print,
                            title = strings.t("إعدادات الطباعة", "Printing Settings"),
                            iconTint = Color(0xFF475569),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("printing"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Group,
                            title = strings.privateAccounts,
                            iconTint = Color(0xFF1D4ED8),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.PRIVATE) {
                                    popUpTo(AppRoutes.HOME)
                                    launchSingleTop = true
                                }
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Lock,
                            title = strings.t("قفل التطبيق", "App Lock"),
                            iconTint = Color(0xFFCA8A04),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("lock"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.CloudUpload,
                            title = strings.t("النسخ السحابي Google Drive", "Google Drive Backup"),
                            iconTint = Color(0xFF2563EB),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("gdriveBackup"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Inventory2,
                            title = strings.t("النسخ الاحتياطي والاستعادة", "Backup & Restore"),
                            iconTint = Color(0xFF92400E),
                            onClick = {
                                scope.launch { drawerState.close() }
                                navController.navigate(AppRoutes.settings("backup"))
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.SupportAgent,
                            title = strings.t("واتساب الدعم", "Support WhatsApp"),
                            iconTint = Color(0xFF16A34A),
                            onClick = {
                                scope.launch { drawerState.close() }
                                ShareHelper.openWhatsApp(
                                    context,
                                    uiState.settings.supportPhone,
                                    "مرحباً، بخصوص تطبيق الاداري برو",
                                    uiState.settings.messages
                                )
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Share,
                            title = strings.t("مشاركة التطبيق", "Share App"),
                            iconTint = Color(0xFF0EA5E9),
                            onClick = {
                                scope.launch { drawerState.close() }
                                ShareHelper.shareText(
                                    context,
                                    strings.appTitle,
                                    "${strings.appTitle} — ${strings.appSubtitle}"
                                )
                            }
                        )
                        if (uiState.settings.appLock.enabled && uiState.settings.appLock.pin.isNotBlank()) {
                            LuxuryDrawerMenuRow(
                                icon = Icons.Default.Security,
                                title = strings.t("قفل التطبيق الآن", "Lock App Now"),
                                isDanger = true,
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    viewModel.lockNowIfEnabled()
                                }
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    if (showBottomBar) {
                        LuxuryBottomNavBar(
                            currentRoute = currentRoute,
                            homeRoute = AppRoutes.HOME,
                            privateRoute = AppRoutes.PRIVATE,
                            buyerRoute = AppRoutes.BUYER,
                            onSelect = { targetRoute ->
                                if (targetRoute == AppRoutes.HOME) {
                                    navController.navigate(AppRoutes.HOME) {
                                        popUpTo(AppRoutes.HOME) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                } else {
                                    navController.navigate(targetRoute) {
                                        popUpTo(AppRoutes.HOME)
                                        launchSingleTop = true
                                    }
                                }
                            }
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .let { if (showBottomBar) it.padding(innerPadding) else it }
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME
                    ) {
                        composable(AppRoutes.HOME) {
                            HomeScreen(
                                uiState = uiState,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onToggleLang = viewModel::toggleLanguage,
                                onToggleDark = viewModel::toggleDarkTheme,
                                onSelectSpecialty = viewModel::setHomeSpecialty,
                                onAddSpecialty = viewModel::addHomeSpecialty,
                                onOpenClockSection = { sec -> navController.navigate(AppRoutes.clockSection(sec)) },
                                onOpenTasfeer = { navController.navigate(AppRoutes.TASFEER) },
                                onOpenFolders = { navController.navigate(AppRoutes.FOLDERS_HOME) },
                                onOpenWeeklyFilters = { navController.navigate(AppRoutes.WEEKLY_FILTERS) },
                                onOpenDetails = { navController.navigate(AppRoutes.DETAILS_LIST) },
                                onOpenDebtCashboxes = { navController.navigate(AppRoutes.DEBT_CASHBOXES) }
                            )
                        }

                        composable(AppRoutes.PRIVATE) {
                            PrivateFoldersScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onBackToHome = {
                                    navController.navigate(AppRoutes.HOME) {
                                        popUpTo(AppRoutes.HOME) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                },
                                onOpenFolder = { f -> navController.navigate(AppRoutes.privateFolder(f.id)) },
                                onOpenAccount = { acc -> navController.navigate(AppRoutes.privateStatement(acc.id)) }
                            )
                        }

                        composable(AppRoutes.BUYER) {
                            BuyerHubScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onOpenBuyerFolders = { navController.navigate(AppRoutes.FOLDERS_BUYER) },
                                onOpenTransferSheets = { navController.navigate(AppRoutes.BUYER_TRANSFER) },
                                onOpenAnnualSheets = { navController.navigate(AppRoutes.BUYER_ANNUAL) },
                                onOpenSalesLedger = { navController.navigate(AppRoutes.buyerController("sales")) },
                                onOpenProfitLedger = { tgt -> navController.navigate(AppRoutes.buyerController(tgt)) }
                            )
                        }

                        composable(AppRoutes.FOLDERS_HOME) {
                            WeekFoldersScreen(
                                scope = FolderScope.HOME,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenFolder = { f -> navController.navigate(AppRoutes.folderDetail(f.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.FOLDERS_BUYER) {
                            WeekFoldersScreen(
                                scope = FolderScope.BUYER,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenFolder = { f -> navController.navigate(AppRoutes.folderDetail(f.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.FOLDER_DETAIL,
                            arguments = listOf(navArgument("folderId") { type = NavType.StringType })
                        ) { entry ->
                            val folderId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                            FolderDetailScreen(
                                folderId = folderId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenInvoice = { inv ->
                                    if (inv.invoiceKind == "buyer") navController.navigate(AppRoutes.buyerInvoice(folderId, inv.id))
                                    else navController.navigate(AppRoutes.sellerInvoice(folderId, inv.id))
                                },
                                onCreateInvoice = { fld ->
                                    if (fld.scope == FolderScope.BUYER) navController.navigate(AppRoutes.buyerInvoice(fld.id))
                                    else navController.navigate(AppRoutes.sellerInvoice(fld.id))
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.SELLER_INVOICE,
                            arguments = listOf(
                                navArgument("folderId") { type = NavType.StringType },
                                navArgument("invoiceId") { type = NavType.StringType; nullable = true }
                            )
                        ) { entry ->
                            val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                            val invId = entry.arguments?.getString("invoiceId")?.let { Uri.decode(it) }
                            SellerInvoiceEditorScreen(
                                folderId = fId,
                                invoiceId = invId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.BUYER_INVOICE,
                            arguments = listOf(
                                navArgument("folderId") { type = NavType.StringType },
                                navArgument("invoiceId") { type = NavType.StringType; nullable = true }
                            )
                        ) { entry ->
                            val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                            val invId = entry.arguments?.getString("invoiceId")?.let { Uri.decode(it) }
                            BuyerInvoiceEditorScreen(
                                folderId = fId,
                                invoiceId = invId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.WEEKLY_FILTERS) {
                            WeeklyFiltersListScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenFilter = { wf -> navController.navigate(AppRoutes.weeklyEditor(wf.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.WEEKLY_EDITOR,
                            arguments = listOf(navArgument("filterId") { type = NavType.StringType })
                        ) { entry ->
                            val filterId = Uri.decode(entry.arguments?.getString("filterId") ?: "")
                            WeeklyFilterEditorScreen(
                                filterId = filterId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenDetailForFilter = { wf ->
                                    val det = uiState.snapshot.details.firstOrNull { it.autoFilterId == wf.id || it.sourceFolderId == wf.sourceFolderId }
                                    if (det != null) navController.navigate(AppRoutes.detailEditor(det.id))
                                    else navController.navigate(AppRoutes.DETAILS_LIST)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.DETAILS_LIST) {
                            DetailsListScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenDetail = { det -> navController.navigate(AppRoutes.detailEditor(det.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.DETAIL_EDITOR,
                            arguments = listOf(navArgument("detailId") { type = NavType.StringType })
                        ) { entry ->
                            val detailId = Uri.decode(entry.arguments?.getString("detailId") ?: "")
                            DetailEditorScreen(
                                detailId = detailId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.CLOCK_SECTION,
                            arguments = listOf(navArgument("sectionKey") { type = NavType.StringType })
                        ) { entry ->
                            val key = entry.arguments?.getString("sectionKey") ?: "sale"
                            val sec = ClockSection.entries.firstOrNull { it.key == key } ?: ClockSection.SALE
                            if (sec == ClockSection.DEBTS) {
                                DebtsMainScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenAutoBox = { navController.navigate(AppRoutes.AUTO_DEBT_BOX) },
                                    onOpenCashbox = { box -> navController.navigate(AppRoutes.debtAccounts(box.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            } else {
                                ClockDetailScreen(
                                    section = sec,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.DEBT_CASHBOXES) {
                            DebtsMainScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenAutoBox = { navController.navigate(AppRoutes.AUTO_DEBT_BOX) },
                                onOpenCashbox = { box -> navController.navigate(AppRoutes.debtAccounts(box.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.AUTO_DEBT_BOX) {
                            AutoDebtBoxScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.DEBT_ACCOUNTS,
                            arguments = listOf(navArgument("cashboxId") { type = NavType.StringType })
                        ) { entry ->
                            val boxId = Uri.decode(entry.arguments?.getString("cashboxId") ?: "")
                            DebtAccountsScreen(
                                cashboxId = boxId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenAccount = { acc -> navController.navigate(AppRoutes.debtLedger(acc.id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.DEBT_LEDGER,
                            arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                        ) { entry ->
                            val accId = Uri.decode(entry.arguments?.getString("accountId") ?: "")
                            DebtAccountLedgerScreen(
                                accountId = accId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.TASFEER) {
                            TasfeerScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.PRIVATE_FOLDER_ACCOUNTS,
                            arguments = listOf(navArgument("folderId") { type = NavType.StringType })
                        ) { entry ->
                            val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                            PrivateFolderAccountsScreen(
                                folderId = fId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenAccount = { acc -> navController.navigate(AppRoutes.privateStatement(acc.id)) },
                                onOpenCurrencySettings = { navController.navigate(AppRoutes.settings("currencies")) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.PRIVATE_STATEMENT,
                            arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                        ) { entry ->
                            val accId = Uri.decode(entry.arguments?.getString("accountId") ?: "")
                            PrivateAccountStatementScreen(
                                accountId = accId,
                                uiState = uiState,
                                viewModel = viewModel,
                                onOpenCurrencySettings = { navController.navigate(AppRoutes.settings("currencies")) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.BUYER_TRANSFER) {
                            BuyerTransferListAndEditorScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(AppRoutes.BUYER_ANNUAL) {
                            BuyerAnnualScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.BUYER_CONTROLLER,
                            arguments = listOf(navArgument("mode") { type = NavType.StringType })
                        ) { entry ->
                            val mode = entry.arguments?.getString("mode") ?: "sales"
                            BuyerControllerLedgerScreen(
                                mode = mode,
                                uiState = uiState,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = AppRoutes.SETTINGS,
                            arguments = listOf(navArgument("section") { type = NavType.StringType; defaultValue = "hub" })
                        ) { entry ->
                            val sec = entry.arguments?.getString("section")?.let { Uri.decode(it) } ?: "hub"
                            SettingsScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onExportBackup = onExportBackup,
                                onImportBackup = onImportBackup,
                                onBack = { navController.popBackStack() },
                                initialSection = sec
                            )
                        }
                    }
                }
            }
        }
    }

    if (uiState.isLocked && !uiState.splashVisible) {
        AppLockScreen(
            lockSettings = uiState.settings.appLock,
            onVerifyPin = viewModel::verifyPin,
            onBiometricSuccess = viewModel::unlockApp
        )
    }

    AnimatedVisibility(
        visible = uiState.splashVisible,
        exit = fadeOut(animationSpec = tween(240))
    ) {
        LuxurySplashOverlay(onFinished = viewModel::dismissSplash)
    }

    if (showExitBackupDialog) {
        AlertDialog(
            onDismissRequest = { showExitBackupDialog = false },
            title = { Text(strings.t("النسخ الاحتياطي قبل الخروج", "Backup Before Exit")) },
            text = {
                Text(strings.t("هل تريد رفع نسخة احتياطية إلى Google Drive (مجلد RYD) قبل الخروج؟", "Upload a backup to Google Drive (RYD folder) before exiting?"))
            },
            confirmButton = {
                Button(onClick = {
                    showExitBackupDialog = false
                    viewModel.backupNowToGoogleDrive(
                        activity = activity,
                        onNeedResolution = { req -> exitBackupAuthLauncher.launch(req) },
                        onComplete = { activity?.finish() }
                    )
                }) {
                    Text(strings.t("نسخ احتياطي والخروج", "Backup & Exit"))
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        showExitBackupDialog = false
                        activity?.finish()
                    }) {
                        Text(strings.t("خروج فقط", "Exit Only"))
                    }
                    TextButton(onClick = { showExitBackupDialog = false }) {
                        Text(strings.cancel)
                    }
                }
            }
        )
    }
    }
}
