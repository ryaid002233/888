package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

object AppFonts {
    val Cairo = FontFamily(Font(R.font.cairo))
    val Tajawal = FontFamily(Font(R.font.tajawal))
    val Almarai = FontFamily(Font(R.font.almarai))
    val IbmPlexArabic = FontFamily(Font(R.font.ibm_plex_sans_arabic))

    fun fromKey(key: String): FontFamily = when (key) {
        "cairo" -> Cairo
        "tajawal" -> Tajawal
        "almarai" -> Almarai
        "ibm" -> IbmPlexArabic
        else -> FontFamily.Default
    }
}

fun buildAppTypography(
    fontFamilyKey: String,
    fontWeightKey: String,
    fontSizeKey: String
): Typography {
    val family = AppFonts.fromKey(fontFamilyKey)
    val scale = when (fontSizeKey) {
        "small" -> 0.90f
        "large" -> 1.14f
        else -> 1.0f
    }
    val baseWeight = when (fontWeightKey) {
        "light" -> FontWeight.Normal
        "bold" -> FontWeight.Bold
        else -> FontWeight.Medium
    }
    val boldWeight = if (fontWeightKey == "light") FontWeight.Medium else FontWeight.Bold

    return Typography(
        displaySmall = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (28 * scale).sp,
            lineHeight = (36 * scale).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (22 * scale).sp,
            lineHeight = (30 * scale).sp
        ),
        headlineSmall = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (19 * scale).sp,
            lineHeight = (26 * scale).sp
        ),
        titleLarge = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (18 * scale).sp,
            lineHeight = (24 * scale).sp
        ),
        titleMedium = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (15 * scale).sp,
            lineHeight = (22 * scale).sp
        ),
        titleSmall = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (13.5f * scale).sp,
            lineHeight = (19 * scale).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (15 * scale).sp,
            lineHeight = (22 * scale).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (13.5f * scale).sp,
            lineHeight = (20 * scale).sp
        ),
        bodySmall = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (12 * scale).sp,
            lineHeight = (17 * scale).sp
        ),
        labelLarge = TextStyle(
            fontFamily = family,
            fontWeight = boldWeight,
            fontSize = (13.5f * scale).sp,
            lineHeight = (18 * scale).sp
        ),
        labelMedium = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (12 * scale).sp,
            lineHeight = (16 * scale).sp
        ),
        labelSmall = TextStyle(
            fontFamily = family,
            fontWeight = baseWeight,
            fontSize = (10.5f * scale).sp,
            lineHeight = (14 * scale).sp
        )
    )
}
