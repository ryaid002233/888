package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WeeklyFiltersListScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenFilter: (WeeklyFilter) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val currentYear = DateHelper.todayIso().take(4).ifBlank { "2026" }
    var sortField by remember { mutableStateOf("date") }
    var sortAsc by remember { mutableStateOf(true) }
    var fromDate by remember { mutableStateOf("$currentYear-01-01") }
    var toDate by remember { mutableStateOf("$currentYear-12-31") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val filters = remember(
        uiState.snapshot.weeklyFilters,
        uiState.settings.activeSpecialty,
        fromDate,
        toDate,
        sortField,
        sortAsc
    ) {
        val list = uiState.snapshot.weeklyFilters
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.activeSpecialty) }
            .filter { wf ->
                val wfFrom = wf.fromDate.ifBlank { wf.toDate }
                val wfTo = wf.toDate.ifBlank { wf.fromDate }
                (fromDate.isBlank() || wfTo.isBlank() || wfTo >= fromDate) &&
                    (toDate.isBlank() || wfFrom.isBlank() || wfFrom <= toDate)
            }
        val comparator: Comparator<WeeklyFilter> = when (sortField) {
            "name" -> compareBy { it.name }
            "total" -> compareBy { WeeklyFilterCalculator.calculate(it).totSalesAll }
            else -> compareBy<WeeklyFilter> { it.fromDate }.thenBy { it.name }
        }
        val sorted = list.sortedWith(comparator)
        if (sortAsc) sorted else sorted.reversed()
    }
    val allSelected = filters.isNotEmpty() && selectedIds.size == filters.size

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = strings.weeklyFilter,
                onBack = onBack,
                actions = {
                    if (selectedIds.isNotEmpty()) {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Print,
                            contentDescription = strings.print,
                            onClick = {
                                val chosen = filters.filter { it.id in selectedIds }
                                if (chosen.size == 1) {
                                    viewModel.printHtmlReport(
                                        activity,
                                        chosen.first().name,
                                        PrintReportBuilders.buildWeeklyFilterHtml(chosen.first(), uiState.settings)
                                    )
                                } else if (chosen.isNotEmpty()) {
                                    val combined = chosen.joinToString("<hr style='margin:24px 0'/>") {
                                        PrintReportBuilders.buildWeeklyFilterHtml(it, uiState.settings)
                                    }
                                    viewModel.printHtmlReport(activity, strings.weeklyFilter, combined)
                                }
                            }
                        )
                    }
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showCreateDialog = true },
                contentDescription = strings.t("إضافة فلتر أسبوعي", "Add Weekly Filter")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            LuxurySortBar(
                options = listOf(
                    "date" to strings.t("التاريخ 📅", "Date"),
                    "name" to strings.t("الاسم", "Name"),
                    "total" to strings.t("المبيعات", "Sales")
                ),
                selected = sortField,
                sortAsc = sortAsc,
                onSelect = { sortField = it },
                onDirectionChange = { sortAsc = it }
            )

            LuxuryDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t }
            )

            LuxurySpecialtyHeaderBar(
                specialties = uiState.settings.specialties,
                selectedId = uiState.settings.activeSpecialty,
                onSelect = viewModel::setHomeSpecialty,
                onAddSpecialty = viewModel::addHomeSpecialty,
                showWorkersAmount = true,
                showManageButton = true,
                showSelectAll = true,
                selectAllChecked = allSelected,
                onToggleSelectAll = {
                    selectedIds = if (allSelected) emptySet() else filters.map { it.id }.toSet()
                }
            )

            if (filters.isEmpty()) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        icon = Icons.Default.FilterAlt,
                        title = strings.t("لا توجد فلاتر أسبوعية", "No Weekly Filters"),
                        subtitle = strings.t("يتم توليد الفلتر الأسبوعي تلقائياً عند إنشاء مجلد فواتير أو اضغط + للإضافة", "Generated from folders or tap + to add")
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 2.dp, bottom = 88.dp)
                ) {
                    items(filters, key = { it.id }) { wf ->
                        val isSel = wf.id in selectedIds
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else Color.Transparent,
                            border = BorderStroke(
                                width = if (isSel) 1.5.dp else 1.dp,
                                color = if (isSel) MaterialTheme.colorScheme.primary else LuxuryPalette.Gold.copy(alpha = 0.55f)
                            ),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        if (selectedIds.isNotEmpty()) {
                                            selectedIds = if (isSel) selectedIds - wf.id else selectedIds + wf.id
                                        } else {
                                            onOpenFilter(wf)
                                        }
                                    },
                                    onLongClick = {
                                        selectedIds = if (isSel) selectedIds - wf.id else selectedIds + wf.id
                                    }
                                )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LuxuryPalette.creamBrush(uiState.settings.dark))
                                    .padding(horizontal = 12.dp, vertical = 14.dp),
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = Color(0xFFEAB308),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = wf.name.ifBlank { strings.weeklyFilter },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (isSel) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${strings.t("من", "From")} ${DateHelper.displaySlash(wf.fromDate)} ${strings.t("إلى", "To")} ${DateHelper.displaySlash(wf.toDate)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        val today = DateHelper.todayIso()
        var name by remember { mutableStateOf("") }
        var cFrom by remember { mutableStateOf(today) }
        var cTo by remember { mutableStateOf(DateHelper.addDays(today, 6)) }
        var spId by remember {
            mutableStateOf(
                if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty
            )
        }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text(strings.t("فلتر أسبوعي جديد", "New Weekly Filter"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NameSuggestTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = strings.t("اسم الفلتر *", "Filter Name *"),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ClickableDateField(value = cFrom, onDatePicked = { cFrom = it }, label = strings.from, modifier = Modifier.weight(1f))
                        ClickableDateField(value = cTo, onDatePicked = { cTo = it }, label = strings.to, modifier = Modifier.weight(1f))
                    }
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = spId,
                        onAssign = { spId = it },
                        onAddSpecialty = viewModel::addHomeSpecialty,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            val wf = WeeklyFilter(
                                name = name.trim(),
                                fromDate = cFrom,
                                toDate = cTo,
                                specialtyId = spId
                            )
                            viewModel.saveWeeklyFilter(wf)
                            showCreateDialog = false
                            onOpenFilter(wf)
                        }
                    },
                    enabled = name.isNotBlank()
                ) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text(strings.cancel) } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyFilterEditorScreen(
    filterId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenDetailForFilter: (WeeklyFilter) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val stored = uiState.snapshot.weeklyFilters.firstOrNull { it.id == filterId }
    if (stored == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    var filter by remember(stored) { mutableStateOf(stored) }
    val calc = remember(filter) { WeeklyFilterCalculator.calculate(filter) }
    var pickingRowDateIdx by remember { mutableStateOf<Int?>(null) }
    var pickingHeaderDateKind by remember { mutableStateOf<String?>(null) } // "from" or "to"
    var showClearConfirm by remember { mutableStateOf(false) }

    val primaryColor = MaterialTheme.colorScheme.primary
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer
    val borderCol = MaterialTheme.colorScheme.outlineVariant
    val softBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    val rowBg = MaterialTheme.colorScheme.surface

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = filter.name.ifBlank { strings.weeklyFilter },
                onBack = onBack,
                actions = {
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Assessment,
                        contentDescription = strings.detail,
                        onClick = { onOpenDetailForFilter(filter) },
                        testTag = "weekly_open_detail_btn"
                    )
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Print,
                        contentDescription = strings.print,
                        onClick = {
                            val html = PrintReportBuilders.buildWeeklyFilterHtml(filter, uiState.settings)
                            viewModel.printHtmlReport(activity, filter.name, html)
                        },
                        testTag = "weekly_print_btn"
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. ترويسة الجدول (.header-info) + التخصيص
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WeeklyHeaderInfoTile(
                            label = strings.t("الاسم", "Name"),
                            value = filter.name.ifBlank { "-" },
                            modifier = Modifier.weight(1f)
                        )
                        WeeklyHeaderInfoTile(
                            label = strings.t("من تاريخ", "From Date"),
                            value = DateHelper.displaySlash(filter.fromDate).ifBlank { "-" },
                            onClick = { pickingHeaderDateKind = "from" },
                            modifier = Modifier.weight(1f)
                        )
                        WeeklyHeaderInfoTile(
                            label = strings.t("إلى تاريخ", "To Date"),
                            value = DateHelper.displaySlash(filter.toDate).ifBlank { "-" },
                            onClick = { pickingHeaderDateKind = "to" },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = filter.specialtyId,
                        onAssign = { filter = filter.copy(specialtyId = it) },
                        onAddSpecialty = { name, amt -> viewModel.addHomeSpecialty(name, amt) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 2. الجدول الأول: عمود الكميه
            WeeklySectionBanner(title = strings.t("عمود الكميه", "Quantities Column"))
            val qtyScroll = rememberScrollState()
            Surface(
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, borderCol),
                color = rowBg,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.horizontalScroll(qtyScroll)) {
                    Row(modifier = Modifier.background(primaryColor)) {
                        WeeklyHeaderCell("", 110.dp)
                        WeeklyHeaderCell(strings.t("الكميه", "Qty"), 86.dp)
                        WeeklyHeaderCell(strings.t("نقد", "Cash"), 86.dp)
                        WeeklyHeaderCell(strings.t("دين", "Debt"), 86.dp)
                        WeeklyHeaderCell(strings.t("خرج", "Exp"), 86.dp)
                        WeeklyHeaderCell(strings.t("الباقي", "Rem"), 92.dp)
                    }
                    filter.qtyRows.forEachIndexed { idx, r ->
                        val rem = calc.rowQtyRemaining.getOrElse(idx) { 0.0 }
                        Row(
                            modifier = Modifier
                                .border(0.5.dp, borderCol)
                                .background(rowBg),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WeeklyDayUnitCell(
                                day = r.day,
                                dateIso = r.date,
                                width = 110.dp,
                                onClick = { pickingRowDateIdx = idx }
                            )
                            WeeklyReadonlyValueCell(r.qty, 86.dp)
                            WeeklyReadonlyValueCell(r.cash, 86.dp)
                            WeeklyReadonlyValueCell(r.debt, 86.dp)
                            WeeklyReadonlyValueCell(r.expense, 86.dp)
                            WeeklyComputedCell(
                                text = fmt(rem),
                                width = 92.dp,
                                bgColor = softBg,
                                textColor = if (abs(rem) < 1e-6) AppColors.CreditGreen else primaryColor
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .background(primaryContainer.copy(alpha = 0.72f))
                            .border(1.dp, primaryColor.copy(alpha = 0.35f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WeeklyTotalCell(strings.t("الجملة", "Total"), 110.dp)
                        WeeklyTotalCell(fmt(calc.totQty), 86.dp)
                        WeeklyTotalCell(fmt(calc.totCashQty), 86.dp)
                        WeeklyTotalCell(fmt(calc.totDebtQty), 86.dp)
                        WeeklyTotalCell(fmt(calc.totExpQty), 86.dp)
                        WeeklyTotalCell(fmt(calc.totQtyRemaining), 92.dp)
                    }
                }
            }

            // 3. الجدول الثاني: عمود البيع
            WeeklySectionBanner(title = strings.t("عمود البيع", "Sales Column"))
            val salesScroll = rememberScrollState()
            Surface(
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, borderCol),
                color = rowBg,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.horizontalScroll(salesScroll)) {
                    Row(modifier = Modifier.background(primaryColor)) {
                        WeeklyHeaderCell(strings.t("اليوم", "Day"), 110.dp)
                        WeeklyHeaderCell(strings.t("نقد الباقي", "Net Cash"), 94.dp)
                        WeeklyHeaderCell(strings.t("مسلم فلوس", "Received"), 126.dp)
                        WeeklyHeaderCell(strings.t("مسلم أسبوع", "Weekly Paid"), 126.dp)
                        WeeklyHeaderCell(strings.t("السحب فلوس", "Withdrawals"), 126.dp)
                        WeeklyHeaderCell(strings.t("= جملة يومية", "= Daily Total"), 104.dp)
                    }
                    filter.salesRows.forEachIndexed { idx, r ->
                        val rowTot = calc.rowSalesTotals.getOrElse(idx) { 0.0 }
                        Row(
                            modifier = Modifier
                                .height(IntrinsicSize.Min)
                                .border(0.5.dp, borderCol)
                                .background(rowBg),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WeeklyDayUnitCell(
                                day = r.day,
                                dateIso = r.date,
                                width = 110.dp,
                                onClick = { pickingRowDateIdx = idx }
                            )
                            WeeklyReadonlyValueCell(r.cash, 94.dp)
                            WeeklyAmountWithNoteCell(
                                amount = r.weeklyAmt,
                                note = r.weeklyNote,
                                width = 126.dp,
                                notePlaceholder = strings.t("ملاحظة", "Note"),
                                onNoteChange = { text ->
                                    val updated = filter.salesRows.toMutableList()
                                    updated[idx] = r.copy(weeklyNote = text)
                                    filter = filter.copy(salesRows = updated)
                                }
                            )
                            WeeklyAmountWithNoteCell(
                                amount = r.weeklySalesAmt,
                                note = r.weeklySalesNote,
                                width = 126.dp,
                                notePlaceholder = strings.t("ملاحظة", "Note"),
                                onNoteChange = { text ->
                                    val updated = filter.salesRows.toMutableList()
                                    updated[idx] = r.copy(weeklySalesNote = text)
                                    filter = filter.copy(salesRows = updated)
                                }
                            )
                            WeeklyAmountWithNoteCell(
                                amount = r.prevAmt,
                                note = r.prevNote,
                                width = 126.dp,
                                notePlaceholder = strings.t("ملاحظة", "Note"),
                                onNoteChange = { text ->
                                    val updated = filter.salesRows.toMutableList()
                                    updated[idx] = r.copy(prevNote = text)
                                    filter = filter.copy(salesRows = updated)
                                }
                            )
                            WeeklyComputedCell(
                                text = fmt(rowTot),
                                width = 104.dp,
                                bgColor = softBg,
                                textColor = primaryColor
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .background(primaryContainer.copy(alpha = 0.72f))
                            .border(1.dp, primaryColor.copy(alpha = 0.35f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WeeklyTotalCell(strings.t("الجملة", "Total"), 110.dp)
                        WeeklyTotalCell(fmt(calc.totSalesCash), 94.dp)
                        WeeklyTotalCell(fmt(calc.totSalesWeekly), 126.dp)
                        WeeklyTotalCell(fmt(calc.totSalesWeeklySales), 126.dp)
                        WeeklyTotalCell(fmt(calc.totSalesPrev), 126.dp)
                        WeeklyTotalCell(fmt(calc.totSalesAll), 104.dp)
                    }
                }
            }

            // 4. الجدول الثالث: العملات (رأس مدمج من صفين)
            WeeklySectionBanner(title = strings.t("العملات", "Currencies"))
            val moneyScroll = rememberScrollState()
            Surface(
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, borderCol),
                color = rowBg,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.horizontalScroll(moneyScroll)) {
                    Row(
                        modifier = Modifier
                            .height(58.dp)
                            .background(primaryColor),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WeeklyHeaderCell("", 110.dp, height = 58.dp)
                        WeeklyHeaderCell(strings.t("يمني\nصرفها", "Yemeni\nExch"), 90.dp, height = 58.dp)
                        WeeklyMergedGroupHeader(
                            groupTitle = strings.t("سعودي", "Saudi"),
                            leftSub = strings.t("المبلغ", "Amt"),
                            rightSub = strings.t("صرفها", "Exch"),
                            subWidth = 84.dp
                        )
                        WeeklyMergedGroupHeader(
                            groupTitle = strings.t("عماني", "Omani"),
                            leftSub = strings.t("المبلغ", "Amt"),
                            rightSub = strings.t("صرفها", "Exch"),
                            subWidth = 84.dp
                        )
                        WeeklyMergedGroupHeader(
                            groupTitle = strings.t("درهم", "Dirham"),
                            leftSub = strings.t("المبلغ", "Amt"),
                            rightSub = strings.t("صرفها", "Exch"),
                            subWidth = 84.dp
                        )
                        WeeklyHeaderCell(strings.t("جملة يومية", "Daily Total"), 98.dp, height = 58.dp)
                    }
                    filter.moneyRows.forEachIndexed { idx, r ->
                        val rowTot = calc.rowMoneyTotals.getOrElse(idx) { 0.0 }
                        Row(
                            modifier = Modifier
                                .border(0.5.dp, borderCol)
                                .background(rowBg),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WeeklyDayUnitCell(
                                day = r.day,
                                dateIso = r.date,
                                width = 110.dp,
                                onClick = { pickingRowDateIdx = idx }
                            )
                            WeeklyReadonlyValueCell(r.yemeni, 90.dp)
                            WeeklyReadonlyValueCell(r.saudiAmt, 84.dp)
                            WeeklyReadonlyValueCell(r.saudiExch, 84.dp)
                            WeeklyReadonlyValueCell(r.omaniAmt, 84.dp)
                            WeeklyReadonlyValueCell(r.omaniExch, 84.dp)
                            WeeklyReadonlyValueCell(r.dirhamAmt, 84.dp)
                            WeeklyReadonlyValueCell(r.dirhamExch, 84.dp)
                            WeeklyComputedCell(
                                text = fmt(rowTot),
                                width = 98.dp,
                                bgColor = softBg,
                                textColor = primaryColor
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .background(primaryContainer.copy(alpha = 0.72f))
                            .border(1.dp, primaryColor.copy(alpha = 0.35f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WeeklyTotalCell(strings.t("الجملة", "Total"), 110.dp)
                        WeeklyTotalCell(fmt(calc.totYemeni), 90.dp)
                        WeeklyTotalCell(fmt(calc.totSaudiAmt), 84.dp)
                        WeeklyTotalCell(fmt(calc.totSaudiExch), 84.dp)
                        WeeklyTotalCell(fmt(calc.totOmaniAmt), 84.dp)
                        WeeklyTotalCell(fmt(calc.totOmaniExch), 84.dp)
                        WeeklyTotalCell(fmt(calc.totDirhamAmt), 84.dp)
                        WeeklyTotalCell(fmt(calc.totDirhamExch), 84.dp)
                        WeeklyTotalCell(fmt(calc.totMoneyAll), 98.dp)
                    }
                }
            }

            // 5. التجميل النهائي (.calc-box)
            WeeklySectionBanner(title = strings.t("التجميل النهائي", "Final Summary"))
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    WeeklyCalcRowItem(strings.t("إجمالي نقد الباقي", "Total Net Cash"), fmt(calc.totSalesCash))
                    WeeklyCalcRowItem(strings.t("إجمالي مسلم فلوس", "Total Received Cash"), fmt(calc.totSalesWeekly))
                    WeeklyCalcRowItem(strings.t("إجمالي مسلم أسبوع", "Total Weekly Paid"), fmt(calc.totSalesWeeklySales))
                    WeeklyCalcRowItem(strings.t("إجمالي السحب فلوس", "Total Withdrawals"), fmt(calc.totSalesPrev))
                    WeeklyCalcRowItem(
                        label = strings.t("إجمالي جملة جدول فلوس البيع والمسلم", "Total Sales & Received Table"),
                        value = fmt(calc.totSalesAll),
                        isTotal = true,
                        valueColor = Color(0xFF1E88E5)
                    )
                    WeeklyCalcRowItem(strings.t("إجمالي العملة اليمنية", "Total Yemeni Currency"), fmt(calc.totYemeni))
                    WeeklyCalcRowItem(strings.t("إجمالي صرف السعودي", "Total Saudi Exchanged"), fmt(calc.totSaudiExch))
                    WeeklyCalcRowItem(strings.t("إجمالي صرف العماني", "Total Omani Exchanged"), fmt(calc.totOmaniExch))
                    WeeklyCalcRowItem(strings.t("إجمالي صرف الدرهم", "Total Dirham Exchanged"), fmt(calc.totDirhamExch))
                    WeeklyCalcRowItem(
                        label = strings.t("إجمالي جدول العملات", "Total Currencies Table"),
                        value = fmt(calc.totMoneyAll),
                        isTotal = true,
                        valueColor = Color(0xFF43A047)
                    )
                    val diffColor = when {
                        abs(calc.diff) < 1e-6 -> Color(0xFF43A047)
                        calc.diff > 0 -> Color(0xFF1E88E5)
                        else -> Color(0xFFE53935)
                    }
                    WeeklyCalcRowItem(
                        label = strings.t("الفارق (يجب أن يكون صفر)", "Difference (must be zero)"),
                        value = if (abs(calc.diff) < 1e-6) "0" else fmt(abs(calc.diff)),
                        isTotal = true,
                        labelColor = if (abs(calc.diff) < 1e-6) MaterialTheme.colorScheme.onSurface else Color(0xFFE53935),
                        valueColor = diffColor,
                        showDivider = false
                    )
                }
            }

            // 6. أزرار التحكم (.actions-bar)
            HorizontalDivider(thickness = 1.5.dp, color = borderCol)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("weekly_back_btn"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = strings.t("← رجوع", "← Back"),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = { viewModel.saveWeeklyFilter(filter) },
                    modifier = Modifier
                        .weight(1.15f)
                        .heightIn(min = 48.dp)
                        .testTag("weekly_save_btn"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = strings.t("💾 حفظ الجدول", "💾 Save Table"),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = { showClearConfirm = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE53935),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(0.85f)
                        .heightIn(min = 48.dp)
                        .testTag("weekly_clear_btn"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = strings.t("مسح", "Clear"),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text(strings.t("مسح البيانات", "Clear Filter"), fontWeight = FontWeight.Bold) },
            text = { Text(strings.t("هل أنت متأكد من مسح الملاحظات وإعادة ضبط الفلتر؟", "Are you sure you want to clear filter notes?")) },
            confirmButton = {
                Button(
                    onClick = {
                        val clearedSales = filter.salesRows.map {
                            it.copy(weeklyNote = "", weeklySalesNote = "", prevNote = "")
                        }
                        filter = filter.copy(salesRows = clearedSales)
                        viewModel.saveWeeklyFilter(filter)
                        showClearConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                ) { Text(strings.t("مسح", "Clear")) }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text(strings.cancel) }
            }
        )
    }

    pickingHeaderDateKind?.let { kind ->
        val initIso = if (kind == "from") filter.fromDate else filter.toDate
        AppDatePickerDialog(
            initialIso = initIso.ifBlank { DateHelper.todayIso() },
            onPicked = { picked ->
                filter = if (kind == "from") filter.copy(fromDate = picked) else filter.copy(toDate = picked)
                pickingHeaderDateKind = null
            },
            onDismiss = { pickingHeaderDateKind = null }
        )
    }

    pickingRowDateIdx?.let { idx ->
        val currentIso = filter.qtyRows.getOrNull(idx)?.date
            ?: filter.salesRows.getOrNull(idx)?.date
            ?: filter.moneyRows.getOrNull(idx)?.date
            ?: DateHelper.todayIso()
        AppDatePickerDialog(
            initialIso = currentIso,
            onPicked = { newIso ->
                val dayName = DateHelper.dayNameAr(newIso).ifBlank { filter.qtyRows.getOrNull(idx)?.day.orEmpty() }
                val nQty = filter.qtyRows.toMutableList().apply {
                    if (idx < size) set(idx, get(idx).copy(date = newIso, day = dayName))
                }
                val nSales = filter.salesRows.toMutableList().apply {
                    if (idx < size) set(idx, get(idx).copy(date = newIso, day = dayName))
                }
                val nMoney = filter.moneyRows.toMutableList().apply {
                    if (idx < size) set(idx, get(idx).copy(date = newIso, day = dayName))
                }
                filter = filter.copy(qtyRows = nQty, salesRows = nSales, moneyRows = nMoney)
                pickingRowDateIdx = null
            },
            onDismiss = { pickingRowDateIdx = null }
        )
    }
}

@Composable
private fun WeeklyHeaderInfoTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .heightIn(min = 52.dp)
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun WeeklySectionBanner(title: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primary,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onPrimary,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun WeeklyHeaderCell(text: String, width: Dp, height: Dp = 40.dp) {
    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .border(0.5.dp, Color.White.copy(alpha = 0.22f))
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = MaterialTheme.colorScheme.onPrimary,
            fontSize = 11.5.sp,
            lineHeight = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WeeklyMergedGroupHeader(
    groupTitle: String,
    leftSub: String,
    rightSub: String,
    subWidth: Dp
) {
    Column(modifier = Modifier.width(subWidth * 2).height(58.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .border(0.5.dp, Color.White.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = groupTitle,
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
        }
        Row(modifier = Modifier.fillMaxWidth().height(28.dp)) {
            Box(
                modifier = Modifier
                    .width(subWidth)
                    .fillMaxHeight()
                    .border(0.5.dp, Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = leftSub,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Box(
                modifier = Modifier
                    .width(subWidth)
                    .fillMaxHeight()
                    .border(0.5.dp, Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rightSub,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun WeeklyDayUnitCell(
    day: String,
    dateIso: String,
    width: Dp,
    onClick: () -> Unit
) {
    val cleanDay = remember(day) {
        day.replace(Regex("""\s*[\u0660-\u06690-9]+\s*-\s*[\u0660-\u06690-9]+\s*$"""), "").trim()
    }
    Box(
        modifier = Modifier
            .width(width)
            .heightIn(min = 48.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = cleanDay.ifBlank { DateHelper.dayNameAr(dateIso) },
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = DateHelper.displaySlash(dateIso),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun WeeklyReadonlyValueCell(value: String, width: Dp) {
    Box(
        modifier = Modifier
            .width(width)
            .heightIn(min = 48.dp)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = value.ifBlank { "" },
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WeeklyComputedCell(
    text: String,
    width: Dp,
    bgColor: Color,
    textColor: Color
) {
    Box(
        modifier = Modifier
            .width(width)
            .heightIn(min = 48.dp)
            .background(bgColor)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.ExtraBold,
            color = textColor,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WeeklyAmountWithNoteCell(
    amount: String,
    note: String,
    width: Dp,
    notePlaceholder: String,
    onNoteChange: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .width(width)
            .heightIn(min = 52.dp)
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .padding(horizontal = 5.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = amount.ifBlank { "0" },
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                .padding(horizontal = 5.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            if (note.isEmpty()) {
                Text(
                    text = notePlaceholder,
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
            BasicTextField(
                value = note,
                onValueChange = onNoteChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.SemiBold
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun WeeklyTotalCell(text: String, width: Dp) {
    Box(
        modifier = Modifier
            .width(width)
            .heightIn(min = 42.dp)
            .border(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WeeklyCalcRowItem(
    label: String,
    value: String,
    isTotal: Boolean = false,
    labelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    showDivider: Boolean = true
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        if (isTotal) {
            HorizontalDivider(thickness = 1.5.dp, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = if (isTotal) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodySmall,
                fontWeight = if (isTotal) FontWeight.Black else FontWeight.Bold,
                color = labelColor,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp)
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.widthIn(min = 128.dp)
            ) {
                Text(
                    text = value,
                    color = valueColor,
                    fontSize = if (isTotal) 15.sp else 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
        }
        if (showDivider && !isTotal) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailsListScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenDetail: (DetailRecord) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val currentYear = DateHelper.todayIso().take(4).ifBlank { "2026" }
    var sortField by remember { mutableStateOf("date") }
    var sortAsc by remember { mutableStateOf(true) }
    var fromDate by remember { mutableStateOf("$currentYear-01-01") }
    var toDate by remember { mutableStateOf("$currentYear-12-31") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val list = remember(
        uiState.snapshot.details,
        uiState.settings.activeSpecialty,
        fromDate,
        toDate,
        sortField,
        sortAsc
    ) {
        val filtered = uiState.snapshot.details
            .filter { matchesSpecialtyFilter(it.specialtyId, uiState.settings.activeSpecialty) }
            .filter { det ->
                val dFrom = det.initDateFrom.ifBlank { det.initDateTo }
                val dTo = det.initDateTo.ifBlank { det.initDateFrom }
                (fromDate.isBlank() || dTo.isBlank() || dTo >= fromDate) &&
                    (toDate.isBlank() || dFrom.isBlank() || dFrom <= toDate)
            }
        val comparator: Comparator<DetailRecord> = when (sortField) {
            "name" -> compareBy { it.initDetail }
            "total" -> compareBy { DetailCalculator.recalculate(it.formData).calcSGrand }
            else -> compareBy<DetailRecord> { it.initDateFrom }.thenBy { it.initDetail }
        }
        val sorted = filtered.sortedWith(comparator)
        if (sortAsc) sorted else sorted.reversed()
    }
    val specMap = remember(uiState.settings.specialties) {
        uiState.settings.specialties.associate { it.id to it.name }
    }
    val allSelected = list.isNotEmpty() && selectedIds.size == list.size

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = strings.detail,
                onBack = onBack,
                actions = {
                    if (selectedIds.isNotEmpty()) {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Print,
                            contentDescription = strings.print,
                            onClick = {
                                val chosen = list.filter { it.id in selectedIds }
                                if (chosen.size == 1) {
                                    viewModel.printHtmlReport(
                                        activity,
                                        chosen.first().initDetail.ifBlank { strings.detail },
                                        PrintReportBuilders.buildDetailHtml(chosen.first(), uiState.settings)
                                    )
                                } else if (chosen.isNotEmpty()) {
                                    val combined = chosen.joinToString("<hr style='margin:24px 0'/>") {
                                        PrintReportBuilders.buildDetailHtml(it, uiState.settings)
                                    }
                                    viewModel.printHtmlReport(activity, strings.detail, combined)
                                }
                            }
                        )
                    }
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { showCreateDialog = true },
                contentDescription = strings.t("إضافة تفصيل", "Add Detail")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            LuxurySortBar(
                options = listOf(
                    "date" to strings.t("التاريخ 📅", "Date"),
                    "name" to strings.t("الاسم", "Name"),
                    "total" to strings.t("الإجمالي", "Total")
                ),
                selected = sortField,
                sortAsc = sortAsc,
                onSelect = { sortField = it },
                onDirectionChange = { sortAsc = it }
            )

            LuxuryDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t }
            )

            LuxurySpecialtyHeaderBar(
                specialties = uiState.settings.specialties,
                selectedId = uiState.settings.activeSpecialty,
                onSelect = viewModel::setHomeSpecialty,
                onAddSpecialty = viewModel::addHomeSpecialty,
                showWorkersAmount = true,
                showManageButton = true,
                showSelectAll = true,
                selectAllChecked = allSelected,
                onToggleSelectAll = {
                    selectedIds = if (allSelected) emptySet() else list.map { it.id }.toSet()
                }
            )

            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        icon = Icons.Default.Assessment,
                        title = strings.t("لا توجد تفاصيلات", "No Detail Sheets"),
                        subtitle = strings.t("يتم إنشاء التفصيل تلقائياً من مجلدات الفواتير أو اضغط + للإضافة", "Generated from weekly folders or tap + to add")
                    )
                }
            } else {
                // Table Card with Dark Header matching Screenshot 6
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, LuxuryPalette.Gold.copy(alpha = 0.55f)),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(LuxuryPalette.darkCardBrush())
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.detail,
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1.3f)
                            )
                            Text(
                                text = strings.t("الفترة", "Period"),
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1.1f)
                            )
                            Text(
                                text = strings.total,
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(bottom = 8.dp)
                        ) {
                            itemsIndexed(list, key = { _, det -> det.id }) { idx, det ->
                                val fd = remember(det) { DetailCalculator.recalculate(det.formData) }
                                val spName = specMap[det.specialtyId] ?: ""
                                val isSel = det.id in selectedIds
                                val title = det.initDetail.ifBlank { strings.detail }
                                val sub = det.initFilter.ifBlank { spName.ifBlank { title } }

                                Column {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                                else MaterialTheme.colorScheme.surface
                                            )
                                            .combinedClickable(
                                                onClick = {
                                                    if (selectedIds.isNotEmpty()) {
                                                        selectedIds = if (isSel) selectedIds - det.id else selectedIds + det.id
                                                    } else {
                                                        onOpenDetail(det)
                                                    }
                                                },
                                                onLongClick = {
                                                    selectedIds = if (isSel) selectedIds - det.id else selectedIds + det.id
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1.3f),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (isSel) {
                                                    Icon(
                                                        Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "${idx + 1}. $title",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            Text(
                                                text = sub,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Column(
                                            modifier = Modifier.weight(1.1f),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = det.initDateFrom.ifBlank { "-" },
                                                style = MaterialTheme.typography.labelMedium,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = det.initDateTo.ifBlank { "-" },
                                                style = MaterialTheme.typography.labelMedium,
                                                maxLines = 1
                                            )
                                        }
                                        Text(
                                            text = fmt(fd.calcSGrand, 0),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(0.8f)
                                        )
                                    }
                                    if (idx < list.lastIndex) {
                                        HorizontalDivider(color = LuxuryPalette.Gold.copy(alpha = 0.25f))
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(72.dp))
            }
        }
    }

    if (showCreateDialog) {
        val today = DateHelper.todayIso()
        var title by remember { mutableStateOf("") }
        var cFrom by remember { mutableStateOf(today) }
        var cTo by remember { mutableStateOf(DateHelper.addDays(today, 6)) }
        var spId by remember {
            mutableStateOf(
                if (uiState.settings.activeSpecialty in listOf("all", "none")) "" else uiState.settings.activeSpecialty
            )
        }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text(strings.t("تفصيل جديد", "New Detail Sheet"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NameSuggestTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = strings.t("اسم التفصيل *", "Detail Title *"),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ClickableDateField(value = cFrom, onDatePicked = { cFrom = it }, label = strings.from, modifier = Modifier.weight(1f))
                        ClickableDateField(value = cTo, onDatePicked = { cTo = it }, label = strings.to, modifier = Modifier.weight(1f))
                    }
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.specialties,
                        selectedId = spId,
                        onAssign = { spId = it },
                        onAddSpecialty = viewModel::addHomeSpecialty,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            val rec = DetailRecord(
                                initDetail = title.trim(),
                                initFilter = title.trim(),
                                initDateFrom = cFrom,
                                initDateTo = cTo,
                                specialtyId = spId
                            )
                            viewModel.saveDetailRecord(rec, pushToClock = false)
                            showCreateDialog = false
                            onOpenDetail(rec)
                        }
                    },
                    enabled = title.isNotBlank()
                ) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text(strings.cancel) } }
        )
    }
}


