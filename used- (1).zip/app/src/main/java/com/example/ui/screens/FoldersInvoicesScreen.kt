package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import java.util.UUID

@Composable
fun WeekFoldersScreen(
    scope: FolderScope,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenFolder: (WeekFolder) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val settings = uiState.settings
    val specialties = if (scope == FolderScope.BUYER) settings.buyerSpecialties else settings.specialties
    val activeSpec = if (scope == FolderScope.BUYER) settings.buyerActiveSpecialty else settings.activeSpecialty

    var sortType by remember { mutableStateOf(FolderSortType.DATE) }
    var sortDir by remember { mutableStateOf(SortDir.ASC) }
    var search by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var showAddEditDialog by remember { mutableStateOf<WeekFolder?>(null) }
    var isCreating by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<WeekFolder?>(null) }

    val folders = remember(uiState.snapshot.weekFolders, scope, activeSpec, sortType, sortDir, search) {
        val scoped = uiState.snapshot.weekFolders.filter { it.scope == scope }
        val bySpec = when (activeSpec) {
            "all", "" -> scoped
            "none" -> scoped.filter { it.specialtyId.isBlank() }
            else -> scoped.filter { it.specialtyId == activeSpec }
        }
        val bySearch = if (search.isBlank()) bySpec else bySpec.filter {
            it.name.contains(search, ignoreCase = true) || it.note.contains(search, ignoreCase = true)
        }
        val comparator = when (sortType) {
            FolderSortType.DATE -> compareBy<WeekFolder> { it.startDate }.thenBy { it.createdAt }
            FolderSortType.NAME -> compareBy { it.name }
            FolderSortType.ORDER -> compareBy<WeekFolder> { it.order }.thenBy { it.createdAt }
        }
        val sorted = bySearch.sortedWith(comparator)
        if (sortDir == SortDir.DESC) sorted.reversed() else sorted
    }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = if (scope == FolderScope.BUYER) strings.t("فواتير الشرائي", "Purchase Invoices")
                else strings.invoices,
                onBack = onBack,
                actions = {
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Search,
                        contentDescription = strings.t("بحث", "Search"),
                        onClick = {
                            showSearch = !showSearch
                            if (!showSearch) search = ""
                        }
                    )
                    LuxuryHeaderIconBtn(
                        icon = if (settings.viewMode == "list") Icons.Default.GridView else Icons.Default.ViewList,
                        contentDescription = "View Mode",
                        onClick = {
                            viewModel.updateSettings { s ->
                                s.copy(viewMode = if (s.viewMode == "list") "grid" else "list")
                            }
                        }
                    )
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = {
                    isCreating = true
                    val nextOrder = (folders.maxOfOrNull { it.order } ?: 0) + 1
                    val start = DateHelper.todayIso()
                    val end = DateHelper.addDays(start, 6)
                    showAddEditDialog = WeekFolder(
                        scope = scope,
                        startDate = start,
                        endDate = end,
                        order = nextOrder,
                        specialtyId = if (activeSpec != "all" && activeSpec != "none") activeSpec else ""
                    )
                },
                contentDescription = strings.t("مجلد جديد", "New Folder"),
                modifier = Modifier.testTag("add_folder_fab")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            AnimatedVisibility(visible = showSearch) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text(strings.t("بحث باسم المجلد...", "Search folders...")) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("folder_search_input")
                )
            }

            // Dark Specialty Selector Card matching Screenshots 1 & 3
            LuxurySpecialtyHeaderBar(
                specialties = specialties,
                selectedId = activeSpec,
                onSelect = { id ->
                    if (scope == FolderScope.BUYER) viewModel.setBuyerSpecialty(id)
                    else viewModel.setHomeSpecialty(id)
                },
                onAddSpecialty = { name, amt ->
                    if (scope == FolderScope.BUYER) viewModel.addBuyerSpecialty(name, amt)
                    else viewModel.addHomeSpecialty(name, amt)
                },
                showWorkersAmount = scope == FolderScope.HOME,
                showManageButton = true
            )

            // Sort Bar matching Screenshots 1 & 3
            LuxurySortBar(
                options = listOf(
                    FolderSortType.DATE to strings.t("التاريخ 📅", "Date"),
                    FolderSortType.NAME to strings.t("الاسم", "Name"),
                    FolderSortType.ORDER to strings.t("الترتيب", "Order")
                ),
                selected = sortType,
                sortAsc = sortDir == SortDir.ASC,
                onSelect = { sortType = it },
                onDirectionChange = { asc -> sortDir = if (asc) SortDir.ASC else SortDir.DESC }
            )

            if (folders.isEmpty()) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        icon = Icons.Default.FolderOpen,
                        title = strings.t("لا توجد مجلدات أسبوعية بعد", "No Weekly Folders Yet"),
                        subtitle = strings.t("اضغط زر + لإنشاء مجلد أسبوعي وتوليد الفواتير والفلتر والتفصيل تلقائياً", "Tap + to create a weekly folder")
                    )
                }
            } else if (settings.viewMode != "list") {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val colCount = if (maxWidth > 540.dp) 3 else 2
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(colCount),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 88.dp)
                    ) {
                        items(folders, key = { it.id }) { folder ->
                            FolderGridCardItem(
                                folder = folder,
                                specialties = specialties,
                                isDark = settings.dark,
                                onClick = { onOpenFolder(folder) },
                                onEdit = { isCreating = false; showAddEditDialog = folder },
                                onToggleLock = { viewModel.toggleFolderLock(folder) },
                                onDelete = { confirmDelete = folder }
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 88.dp)
                ) {
                    items(folders, key = { it.id }) { folder ->
                        FolderListCardItem(
                            folder = folder,
                            specialties = specialties,
                            isDark = settings.dark,
                            onClick = { onOpenFolder(folder) },
                            onEdit = { isCreating = false; showAddEditDialog = folder },
                            onToggleLock = { viewModel.toggleFolderLock(folder) },
                            onDelete = { confirmDelete = folder }
                        )
                    }
                }
            }
        }
    }

    showAddEditDialog?.let { editing ->
        AddEditFolderDialog(
            initial = editing,
            specialties = specialties,
            isNew = isCreating,
            viewModel = viewModel,
            onSave = { saved ->
                viewModel.saveWeekFolder(saved) {
                    showAddEditDialog = null
                    if (isCreating) onOpenFolder(saved)
                }
            },
            onDismiss = { showAddEditDialog = null }
        )
    }

    confirmDelete?.let { f ->
        ConfirmActionDialog(
            title = strings.delete,
            message = strings.t("هل تريد نقل المجلد (${f.name}) وفواتيره إلى سلة المهملات؟", "Move folder (${f.name}) to Trash?"),
            confirmText = strings.delete,
            onConfirm = { viewModel.deleteWeekFolder(f) },
            onDismiss = { confirmDelete = null }
        )
    }
}

@Composable
private fun FolderGridCardItem(
    folder: WeekFolder,
    specialties: List<Specialty>,
    isDark: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onToggleLock: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val specName = specialties.firstOrNull { it.id == folder.specialtyId }?.name ?: ""
    var menuOpen by remember { mutableStateOf(false) }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, LuxuryPalette.Gold.copy(alpha = 0.55f)),
        shadowElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("folder_card_${folder.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LuxuryPalette.creamBrush(isDark))
        ) {
            Box(modifier = Modifier.align(Alignment.TopEnd)) {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp)) {
                    Icon(
                        Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
                FolderCardDropdown(
                    expanded = menuOpen,
                    locked = folder.locked,
                    onDismiss = { menuOpen = false },
                    onEdit = onEdit,
                    onToggleLock = onToggleLock,
                    onDelete = onDelete
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(2.dp, Color(0xFF0F172A), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (folder.imagePath.isNotBlank() && File(folder.imagePath).exists()) {
                        Image(
                            painter = rememberAsyncImagePainter(File(folder.imagePath)),
                            contentDescription = folder.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    } else {
                        Icon(
                            imageVector = if (folder.locked) Icons.Default.Lock else Icons.Default.Group,
                            contentDescription = folder.name,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Text(
                    text = "${folder.name} 📅",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "${strings.t("من", "From")} ${folder.startDate} ${strings.t("إلى", "to")} ${folder.endDate}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (specName.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = LuxuryPalette.Gold.copy(alpha = 0.16f)
                    ) {
                        Text(
                            text = specName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FolderListCardItem(
    folder: WeekFolder,
    specialties: List<Specialty>,
    isDark: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onToggleLock: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val specName = specialties.firstOrNull { it.id == folder.specialtyId }?.name ?: ""
    var menuOpen by remember { mutableStateOf(false) }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, LuxuryPalette.Gold.copy(alpha = 0.55f)),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("folder_card_${folder.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(LuxuryPalette.creamBrush(isDark))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.5.dp, Color(0xFF0F172A), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (folder.imagePath.isNotBlank() && File(folder.imagePath).exists()) {
                        Image(
                            painter = rememberAsyncImagePainter(File(folder.imagePath)),
                            contentDescription = folder.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    } else {
                        Icon(
                            if (folder.locked) Icons.Default.Lock else Icons.Default.Group,
                            contentDescription = folder.name,
                            tint = Color(0xFF0284C7)
                        )
                    }
                }
                Column {
                    Text(
                        text = "${folder.name} 📅",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${strings.t("من", "From")} ${folder.startDate} ${strings.t("إلى", "to")} ${folder.endDate}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (specName.isNotBlank()) {
                        Text(specName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Options")
                }
                FolderCardDropdown(
                    expanded = menuOpen,
                    locked = folder.locked,
                    onDismiss = { menuOpen = false },
                    onEdit = onEdit,
                    onToggleLock = onToggleLock,
                    onDelete = onDelete
                )
            }
        }
    }
}

@Composable
private fun FolderCardDropdown(
    expanded: Boolean,
    locked: Boolean,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onToggleLock: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text(strings.edit) },
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
            onClick = { onDismiss(); onEdit() }
        )
        DropdownMenuItem(
            text = { Text(if (locked) strings.t("فتح القفل", "Unlock") else strings.t("قفل المجلد", "Lock")) },
            leadingIcon = { Icon(if (locked) Icons.Default.LockOpen else Icons.Default.Lock, contentDescription = null) },
            onClick = { onDismiss(); onToggleLock() }
        )
        DropdownMenuItem(
            text = { Text(strings.delete, color = MaterialTheme.colorScheme.error) },
            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            onClick = { onDismiss(); onDelete() }
        )
    }
}

@Composable
private fun AddEditFolderDialog(
    initial: WeekFolder,
    specialties: List<Specialty>,
    isNew: Boolean,
    viewModel: SmartAdminViewModel,
    onSave: (WeekFolder) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf(initial.name) }
    var startDate by remember { mutableStateOf(initial.startDate) }
    var endDate by remember { mutableStateOf(initial.endDate) }
    var note by remember { mutableStateOf(initial.note) }
    var orderStr by remember { mutableStateOf(initial.order.toString()) }
    var specId by remember { mutableStateOf(initial.specialtyId) }
    var imgPath by remember { mutableStateOf(initial.imagePath) }
    var errMsg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { path -> imgPath = path }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (isNew) strings.t("مجلد أسبوعي جديد", "New Weekly Folder")
                else strings.t("تعديل المجلد", "Edit Folder"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NameSuggestTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = strings.t("اسم المجلد *", "Folder Name *"),
                    testTag = "folder_name_input",
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ClickableDateField(
                        value = startDate,
                        onDatePicked = { startDate = it },
                        label = strings.from,
                        modifier = Modifier.weight(1f),
                        testTag = "folder_start_date_input"
                    )
                    ClickableDateField(
                        value = endDate,
                        onDatePicked = { endDate = it },
                        label = strings.to,
                        modifier = Modifier.weight(1f),
                        testTag = "folder_end_date_input"
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    WesternNumberField(
                        value = orderStr,
                        onValueChange = { orderStr = it },
                        label = strings.t("الترتيب", "Order"),
                        allowDecimal = false,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.t("صورة", "Photo"))
                    }
                }
                SpecialtyAssignDropdown(
                    specialties = specialties,
                    selectedId = specId,
                    onAssign = { specId = it },
                    onAddSpecialty = { n, w ->
                        if (initial.scope == FolderScope.BUYER) viewModel.addBuyerSpecialty(n, w)
                        else viewModel.addHomeSpecialty(n, w)
                    },
                    showWorkersAmount = initial.scope == FolderScope.HOME,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(strings.note) },
                    modifier = Modifier.fillMaxWidth()
                )
                if (errMsg.isNotBlank()) {
                    Text(errMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = name.trim()
                    if (trimmed.isEmpty()) {
                        errMsg = strings.t("يرجى كتابة اسم المجلد", "Folder name is required")
                        return@Button
                    }
                    onSave(
                        initial.copy(
                            name = trimmed,
                            startDate = startDate.trim(),
                            endDate = endDate.trim(),
                            note = note.trim(),
                            order = orderStr.toIntOrNull() ?: 1,
                            specialtyId = specId,
                            imagePath = imgPath
                        )
                    )
                },
                modifier = Modifier.testTag("save_folder_confirm_btn")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FolderDetailScreen(
    folderId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenInvoice: (FolderInvoice) -> Unit,
    onCreateInvoice: (WeekFolder) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val folder = uiState.snapshot.weekFolders.firstOrNull { it.id == folderId }

    if (folder == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val context = LocalContext.current
    val invoices = remember(folder.invoices) {
        folder.invoices.sortedBy { it.initDateISO }
    }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var targetFolderAction by remember { mutableStateOf<Boolean?>(null) } // true=move, false=copy
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var previewInvoice by remember { mutableStateOf<FolderInvoice?>(null) }
    var previewPhotoPath by remember { mutableStateOf<String?>(null) }
    var revealHiddenInvoices by remember { mutableStateOf(false) }

    val selectionActive = selectedIds.isNotEmpty()
    val otherFolders = remember(uiState.snapshot.weekFolders, folder) {
        uiState.snapshot.weekFolders.filter { it.id != folder.id && it.scope == folder.scope }
    }

    Scaffold(
        topBar = {
            if (selectionActive) {
                TopAppBar(
                    title = { Text("${selectedIds.size} ${strings.t("محدد", "selected")}") },
                    navigationIcon = {
                        IconButton(onClick = { selectedIds = emptySet() }) {
                            Icon(Icons.Default.Close, contentDescription = strings.cancel)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            selectedIds = if (selectedIds.size == invoices.size) emptySet()
                            else invoices.map { it.id }.toSet()
                        }) {
                            Icon(Icons.Default.SelectAll, contentDescription = strings.selectAll)
                        }
                        if (otherFolders.isNotEmpty()) {
                            IconButton(onClick = { targetFolderAction = false }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = strings.copy)
                            }
                            IconButton(onClick = { targetFolderAction = true }) {
                                Icon(Icons.AutoMirrored.Filled.DriveFileMove, contentDescription = strings.move)
                            }
                        }
                        IconButton(onClick = { confirmBulkDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(folder.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${DateHelper.displaySlash(folder.startDate)} → ${DateHelper.displaySlash(folder.endDate)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.toggleFolderLock(folder) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                if (folder.locked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "Lock"
                            )
                        }
                    }
                )
            }
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            if (!folder.locked) {
                FloatingActionButton(
                    onClick = { onCreateInvoice(folder) },
                    modifier = Modifier.testTag("create_invoice_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = strings.t("فاتورة جديدة", "New Invoice"))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (folder.locked) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.t("هذا المجلد مقفل — افتح القفل من الأعلى للإضافة أو التعديل", "Folder is locked"),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            if (!uiState.settings.showInvoicesInFolders && !revealHiddenInvoices) {
                StyledAppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(strings.t("تم إخفاء الفواتير داخل المجلد من الإعدادات", "Invoices inside folders are hidden in Settings"), fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { revealHiddenInvoices = true }) {
                            Text(strings.t("عرض الفواتير الآن (${invoices.size})", "Show Invoices Now (${invoices.size})"))
                        }
                    }
                }
            } else if (invoices.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Description,
                    title = strings.t("لا توجد فواتير داخل المجلد", "No Invoices in Folder"),
                    subtitle = strings.t("اضغط + لإضافة أول فاتورة في هذا الأسبوع", "Tap + to add the first invoice")
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(invoices, key = { it.id }) { inv ->
                        val isSel = inv.id in selectedIds
                        val isBuyer = inv.invoiceKind == "buyer" || folder.scope == FolderScope.BUYER
                        val sellerCalc = remember(inv) {
                            if (!isBuyer) SellerInvoiceCalculator.calculate(inv.formData) else null
                        }
                        var invMenuOpen by remember { mutableStateOf(false) }
                        StyledAppCard(
                            containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        if (selectionActive) {
                                            selectedIds = if (isSel) selectedIds - inv.id else selectedIds + inv.id
                                        } else {
                                            onOpenInvoice(inv)
                                        }
                                    },
                                    onLongClick = {
                                        if (uiState.settings.longPressActions && !folder.locked) {
                                            selectedIds = if (isSel) selectedIds - inv.id else selectedIds + inv.id
                                        }
                                    }
                                )
                                .testTag("invoice_item_${inv.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        text = DateHelper.formatInvoiceDate(inv.initDateISO, uiState.settings.lang == "en"),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = inv.initSeller.ifBlank { strings.t("بدون اسم", "No Name") },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    if (isBuyer) {
                                        Text(
                                            text = "${strings.net}: ${fmt(inv.buyerNet, 2)}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = AppColors.CreditGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${strings.t("مجموع", "Sum")}: ${fmt(inv.buyerTotal, 2)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    } else if (sellerCalc != null) {
                                        Text(
                                            text = fmt(sellerCalc.cashBalance),
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${strings.t("كمية", "Qty")}: ${fmt(sellerCalc.enteredQty)} | ${strings.t("بقية", "Rem")}: ${fmt(sellerCalc.qtyBalance)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        val html = if (isBuyer) PrintReportBuilders.buildBuyerInvoiceHtml(inv, uiState.settings)
                                        else PrintReportBuilders.buildSellerInvoiceHtml(inv, uiState.settings)
                                        viewModel.printHtmlReport(activity, inv.initDateISO, html, isVoucher = false)
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = strings.print)
                                }

                                Box {
                                    IconButton(onClick = { invMenuOpen = true }, modifier = Modifier.size(48.dp)) {
                                        Icon(Icons.Default.MoreVert, contentDescription = strings.t("خيارات الفاتورة", "Invoice options"))
                                    }
                                    DropdownMenu(expanded = invMenuOpen, onDismissRequest = { invMenuOpen = false }) {
                                        DropdownMenuItem(
                                            text = { Text(strings.t("معاينة سريعة", "Quick Preview")) },
                                            leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                                            onClick = { invMenuOpen = false; previewInvoice = inv }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.t("مشاركة كنص", "Share as Text")) },
                                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                                            onClick = {
                                                invMenuOpen = false
                                                val txt = buildInvoiceShareText(inv, isBuyer)
                                                ShareHelper.shareText(context, inv.initDateISO, txt)
                                            }
                                        )
                                        if (inv.sellerPhotoPath.isNotBlank() && File(inv.sellerPhotoPath).exists()) {
                                            DropdownMenuItem(
                                                text = { Text(strings.t("عرض صورة البياع", "View Seller Photo")) },
                                                leadingIcon = { Icon(Icons.Default.Photo, contentDescription = null) },
                                                onClick = { invMenuOpen = false; previewPhotoPath = inv.sellerPhotoPath }
                                            )
                                        }
                                        if (!folder.locked) {
                                            DropdownMenuItem(
                                                text = { Text(strings.t("حفظ نسخة", "Save a Copy")) },
                                                leadingIcon = { Icon(Icons.Default.FileCopy, contentDescription = null) },
                                                onClick = {
                                                    invMenuOpen = false
                                                    viewModel.saveInvoice(
                                                        inv.copy(
                                                            id = UUID.randomUUID().toString(),
                                                            createdAt = System.currentTimeMillis()
                                                        )
                                                    )
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text(strings.delete, color = MaterialTheme.colorScheme.error) },
                                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                onClick = { invMenuOpen = false; viewModel.deleteInvoice(inv) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    previewInvoice?.let { inv ->
        val isBuyer = inv.invoiceKind == "buyer" || folder.scope == FolderScope.BUYER
        val txt = remember(inv) { buildInvoiceShareText(inv, isBuyer) }
        AlertDialog(
            onDismissRequest = { previewInvoice = null },
            title = { Text(strings.t("معاينة الفاتورة", "Invoice Preview"), fontWeight = FontWeight.Bold) },
            text = { Text(txt, style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(onClick = { previewInvoice = null; onOpenInvoice(inv) }) {
                    Text(strings.t("فتح وتعديل", "Open Editor"))
                }
            },
            dismissButton = { TextButton(onClick = { previewInvoice = null }) { Text(strings.close) } }
        )
    }

    previewPhotoPath?.let { p ->
        AppImageViewerDialog(imagePath = p, onSaveToGallery = { viewModel.saveImageToGallery(p) }, onDismiss = { previewPhotoPath = null })
    }

    targetFolderAction?.let { isMove ->
        AlertDialog(
            onDismissRequest = { targetFolderAction = null },
            title = { Text(if (isMove) strings.t("نقل إلى مجلد", "Move to Folder") else strings.t("نسخ إلى مجلد", "Copy to Folder")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    otherFolders.forEach { target ->
                        OutlinedButton(
                            onClick = {
                                val chosen = invoices.filter { it.id in selectedIds }
                                viewModel.copyOrMoveInvoices(chosen, target.id, move = isMove)
                                selectedIds = emptySet()
                                targetFolderAction = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(target.name)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { targetFolderAction = null }) { Text(strings.cancel) } }
        )
    }

    if (confirmBulkDelete) {
        ConfirmActionDialog(
            title = strings.delete,
            message = strings.t("نقل ${selectedIds.size} فاتورة إلى سلة المهملات؟", "Move ${selectedIds.size} invoices to Trash?"),
            confirmText = strings.delete,
            onConfirm = {
                invoices.filter { it.id in selectedIds }.forEach { viewModel.deleteInvoice(it) }
                selectedIds = emptySet()
            },
            onDismiss = { confirmBulkDelete = false }
        )
    }
}

private fun buildInvoiceShareText(inv: FolderInvoice, isBuyer: Boolean): String = buildString {
    appendLine("📄 فاتورة: ${DateHelper.displaySlash(inv.initDateISO)}")
    if (inv.initSeller.isNotBlank()) appendLine("الاسم: ${inv.initSeller}")
    if (isBuyer) {
        appendLine("الإجمالي: ${fmt(inv.buyerTotal, 2)}")
        appendLine("عدد البنود: ${inv.buyerRows.size}")
        appendLine("المصاريف: ${fmt(inv.buyerExpense, 2)}")
        appendLine("الصافي: ${fmt(inv.buyerNet, 2)}")
    } else {
        val calc = SellerInvoiceCalculator.calculate(inv.formData)
        appendLine("مبلغ البيع النقدي: ${fmt(calc.saleCash)}")
        appendLine("الكمية المدخلة: ${fmt(calc.enteredQty)}")
        appendLine("الكمية الباقية: ${fmt(calc.qtyBalance)}")
        appendLine("الرصيد النقدي: ${fmt(calc.cashBalance)}")
    }
}
