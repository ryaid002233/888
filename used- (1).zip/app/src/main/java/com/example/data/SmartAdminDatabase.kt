package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        WeekFolderEntity::class,
        FolderInvoiceEntity::class,
        WeeklyFilterEntity::class,
        DetailRecordEntity::class,
        ClockEntryEntity::class,
        DebtCashboxEntity::class,
        DebtAccountEntity::class,
        DebtVoucherEntity::class,
        CurrencyReceiptEntity::class,
        CurrencyExchangeEntity::class,
        TsFolderEntity::class,
        TsAccountEntity::class,
        TsFundEntity::class,
        TsVoucherEntity::class,
        PrivateFolderEntity::class,
        PrivateAccountEntity::class,
        PrivateTxEntity::class,
        BuyerTransferEntity::class,
        BuyerAnnualFolderEntity::class,
        BuyerSaleEntity::class,
        BuyerProfitEntity::class,
        TrashItemEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class SmartAdminDatabase : RoomDatabase() {
    abstract fun dao(): SmartAdminDao

    companion object {
        @Volatile
        private var INSTANCE: SmartAdminDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE debt_vouchers ADD COLUMN specialtyId TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clock_entries ADD COLUMN rowsJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE clock_entries ADD COLUMN img TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE clock_entries ADD COLUMN tsVoucherId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE clock_entries ADD COLUMN tsKind TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ts_folders ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE ts_accounts ADD COLUMN limitAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE ts_funds ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE ts_vouchers ADD COLUMN pg TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE ts_vouchers ADD COLUMN specialtyId TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getInstance(context: Context): SmartAdminDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SmartAdminDatabase::class.java,
                    "smart_admin_pro.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
            }
        }
    }
}
