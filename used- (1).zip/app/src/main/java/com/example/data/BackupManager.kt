package com.example.data

import android.content.Context
import com.example.data.EntityMappers.toDomain
import com.example.data.EntityMappers.toEntity
import com.example.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupManager {

    private const val FORMAT = "smart-admin-unified-backup"

    suspend fun exportToJson(
        context: Context,
        dao: SmartAdminDao,
        settingsStore: SettingsDataStore,
        settings: AppSettings,
        includeImages: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val folders = dao.getWeekFolders()
        val invoices = dao.getInvoices()
        val filters = dao.getWeeklyFilters()
        val details = dao.getDetails()
        val clock = dao.getClockEntries()
        val cashboxes = dao.getDebtCashboxes()
        val debtAccounts = dao.getDebtAccounts()
        val debtVouchers = dao.getDebtVouchers()
        val curReceipts = dao.getCurrencyReceipts()
        val curExchanges = dao.getCurrencyExchanges()
        val tsFolders = dao.getTsFolders()
        val tsAccounts = dao.getTsAccounts()
        val tsFunds = dao.getTsFunds()
        val tsVouchers = dao.getTsVouchers()
        val pFolders = dao.getPrivateFolders()
        val pAccounts = dao.getPrivateAccounts()
        val pTxs = dao.getPrivateTxs()
        val bTransfers = dao.getBuyerTransfers()
        val bAnnual = dao.getBuyerAnnualFolders()
        val bSales = dao.getBuyerSales()
        val bProfits = dao.getBuyerProfits()
        val trash = dao.getTrash()

        val nativePayload = JSONObject().apply {
            put("settings", JSONObject(settingsStore.encode(settings)))
            put("weekFolders", JSONArray().apply {
                folders.forEach { f ->
                    put(JSONObject().apply {
                        put("id", f.id); put("name", f.name); put("imagePath", f.imagePath)
                        put("note", f.note); put("sortOrder", f.sortOrder); put("scope", f.scope)
                        put("startDate", f.startDate); put("endDate", f.endDate)
                        put("specialtyId", f.specialtyId); put("locked", f.locked); put("createdAt", f.createdAt)
                    })
                }
            })
            put("invoices", JSONArray().apply {
                invoices.forEach { i ->
                    put(JSONObject().apply {
                        put("id", i.id); put("folderId", i.folderId); put("invoiceKind", i.invoiceKind)
                        put("initDate", i.initDate); put("initDateISO", i.initDateISO)
                        put("initSeller", i.initSeller); put("initPlace", i.initPlace)
                        put("initWeeklyFilter", i.initWeeklyFilter); put("initNo", i.initNo)
                        put("note", i.note); put("specialtyId", i.specialtyId)
                        put("sellerPhotoPath", i.sellerPhotoPath); put("invoicePaperPhotoPath", i.invoicePaperPhotoPath)
                        put("formDataJson", i.formDataJson); put("buyerRowsJson", i.buyerRowsJson)
                        put("buyerTotal", i.buyerTotal); put("buyerExpense", i.buyerExpense); put("buyerNet", i.buyerNet)
                        put("createdAt", i.createdAt); put("updatedAt", i.updatedAt)
                    })
                }
            })
            put("weeklyFilters", JSONArray().apply {
                filters.forEach { w ->
                    put(JSONObject().apply {
                        put("id", w.id); put("name", w.name); put("fromDate", w.fromDate); put("toDate", w.toDate)
                        put("sourceFolderId", w.sourceFolderId); put("specialtyId", w.specialtyId)
                        put("payloadJson", w.payloadJson); put("updatedAt", w.updatedAt)
                    })
                }
            })
            put("details", JSONArray().apply {
                details.forEach { d ->
                    put(JSONObject().apply {
                        put("id", d.id); put("autoFilterId", d.autoFilterId); put("sourceFolderId", d.sourceFolderId)
                        put("specialtyId", d.specialtyId); put("initDetail", d.initDetail)
                        put("initDateFrom", d.initDateFrom); put("initDateTo", d.initDateTo)
                        put("initNo", d.initNo); put("initFilter", d.initFilter); put("note", d.note)
                        put("formDataJson", d.formDataJson); put("createdAt", d.createdAt); put("updatedAt", d.updatedAt)
                    })
                }
            })
            put("clockEntries", JSONArray().apply {
                clock.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id); put("section", c.section); put("srcDetailId", c.srcDetailId)
                        put("specialtyId", c.specialtyId); put("dir", c.dir); put("amount", c.amount)
                        put("name", c.name); put("date", c.date); put("time", c.time)
                        put("fromDate", c.fromDate); put("toDate", c.toDate); put("note", c.note)
                        put("days", c.days); put("qty", c.qty); put("cur", c.cur)
                        put("curAmount", c.curAmount); put("curRate", c.curRate); put("kind", c.kind)
                        put("subRowsJson", c.subRowsJson); put("rowsJson", c.rowsJson)
                        put("img", c.img); put("tsVoucherId", c.tsVoucherId); put("tsKind", c.tsKind)
                        put("auto", c.auto); put("sentStamp", c.sentStamp)
                    })
                }
            })
            put("debtCashboxes", JSONArray().apply {
                cashboxes.forEach { b ->
                    put(JSONObject().apply {
                        put("id", b.id); put("name", b.name); put("imagePath", b.imagePath)
                        put("note", b.note); put("sortOrder", b.sortOrder); put("locked", b.locked); put("createdAt", b.createdAt)
                    })
                }
            })
            put("debtAccounts", JSONArray().apply {
                debtAccounts.forEach { a ->
                    put(JSONObject().apply {
                        put("id", a.id); put("cashboxId", a.cashboxId); put("name", a.name); put("phone", a.phone)
                        put("limitEnabled", a.limitEnabled); put("limitAmount", a.limitAmount)
                        put("messageSend", a.messageSend); put("createdAt", a.createdAt)
                    })
                }
            })
            put("debtVouchers", JSONArray().apply {
                debtVouchers.forEach { v ->
                    put(JSONObject().apply {
                        put("id", v.id); put("accountId", v.accountId); put("specialtyId", v.specialtyId); put("type", v.type); put("amount", v.amount)
                        put("currency", v.currency); put("note", v.note); put("date", v.date); put("time", v.time)
                        put("imagePath", v.imagePath); put("autoSourceKey", v.autoSourceKey); put("createdAt", v.createdAt)
                    })
                }
            })
            put("currencyReceipts", JSONArray().apply {
                curReceipts.forEach { r ->
                    put(JSONObject().apply {
                        put("id", r.id); put("fromFundId", r.fromFundId); put("toAccountId", r.toAccountId)
                        put("toAccountName", r.toAccountName); put("currency", r.currency); put("amount", r.amount)
                        put("rate", r.rate); put("fee", r.fee); put("date", r.date); put("note", r.note); put("createdAt", r.createdAt)
                    })
                }
            })
            put("currencyExchanges", JSONArray().apply {
                curExchanges.forEach { x ->
                    put(JSONObject().apply {
                        put("id", x.id); put("fromCurrency", x.fromCurrency); put("fromAmount", x.fromAmount)
                        put("toCurrency", x.toCurrency); put("rate", x.rate); put("toAmount", x.toAmount)
                        put("date", x.date); put("note", x.note); put("createdAt", x.createdAt)
                    })
                }
            })
            put("tsFolders", JSONArray().apply {
                tsFolders.forEach { f -> put(JSONObject().apply { put("id", f.id); put("name", f.name); put("parentId", f.parentId); put("img", f.img); put("sortOrder", f.sortOrder) }) }
            })
            put("tsAccounts", JSONArray().apply {
                tsAccounts.forEach { a -> put(JSONObject().apply { put("id", a.id); put("folderId", a.folderId); put("name", a.name); put("phone", a.phone); put("img", a.img); put("limitAmount", a.limitAmount) }) }
            })
            put("tsFunds", JSONArray().apply {
                tsFunds.forEach { f -> put(JSONObject().apply { put("id", f.id); put("name", f.name); put("img", f.img); put("sortOrder", f.sortOrder) }) }
            })
            put("tsVouchers", JSONArray().apply {
                tsVouchers.forEach { v ->
                    put(JSONObject().apply {
                        put("id", v.id); put("kind", v.kind); put("dir", v.dir); put("date", v.date); put("time", v.time)
                        put("accId", v.accId); put("fundId", v.fundId); put("fromFundId", v.fromFundId); put("toFundId", v.toFundId)
                        put("note", v.note); put("img", v.img); put("cur", v.cur); put("amount", v.amount); put("rate", v.rate)
                        put("rowsJson", v.rowsJson); put("fromCur", v.fromCur); put("fromAmt", v.fromAmt)
                        put("toCur", v.toCur); put("toAmt", v.toAmt); put("sender", v.sender); put("receiver", v.receiver)
                        put("dest", v.dest); put("transferNo", v.transferNo); put("com", v.com); put("comCur", v.comCur)
                        put("pg", v.pg); put("specialtyId", v.specialtyId)
                        put("srcClockId", v.srcClockId); put("createdAt", v.createdAt)
                    })
                }
            })
            put("privateFolders", JSONArray().apply {
                pFolders.forEach { f -> put(JSONObject().apply { put("id", f.id); put("name", f.name); put("img", f.img); put("createdAt", f.createdAt) }) }
            })
            put("privateAccounts", JSONArray().apply {
                pAccounts.forEach { a ->
                    put(JSONObject().apply {
                        put("id", a.id); put("folderId", a.folderId); put("name", a.name); put("phone", a.phone)
                        put("cap", a.cap); put("send", a.send); put("img", a.img); put("createdAt", a.createdAt)
                    })
                }
            })
            put("privateTxs", JSONArray().apply {
                pTxs.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id); put("accountId", t.accountId); put("currency", t.currency)
                        put("date", t.date); put("time", t.time); put("amount", t.amount); put("type", t.type)
                        put("linesJson", t.linesJson); put("img", t.img); put("xfer", t.xfer); put("createdAt", t.createdAt)
                    })
                }
            })
            put("buyerTransfers", JSONArray().apply {
                bTransfers.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id); put("folderId", t.folderId); put("specialtyId", t.specialtyId)
                        put("name", t.name); put("fromDate", t.fromDate); put("toDate", t.toDate)
                        put("rowsJson", t.rowsJson); put("oldPrice", t.oldPrice); put("newPrice", t.newPrice)
                        put("rentRada", t.rentRada); put("rentShip", t.rentShip); put("weeklySale", t.weeklySale)
                        put("habbaCount", t.habbaCount); put("diffAccountName", t.diffAccountName)
                        put("diffNote", t.diffNote); put("updatedAt", t.updatedAt)
                    })
                }
            })
            put("buyerAnnualFolders", JSONArray().apply {
                bAnnual.forEach { a ->
                    put(JSONObject().apply {
                        put("id", a.id); put("specialtyId", a.specialtyId); put("name", a.name)
                        put("rowsJson", a.rowsJson); put("updatedAt", a.updatedAt)
                    })
                }
            })
            put("buyerSales", JSONArray().apply {
                bSales.forEach { s ->
                    put(JSONObject().apply {
                        put("id", s.id); put("dir", s.dir); put("date", s.date); put("fromDate", s.fromDate)
                        put("toDate", s.toDate); put("amount", s.amount); put("qty", s.qty); put("unitPrice", s.unitPrice)
                        put("specialtyId", s.specialtyId); put("note", s.note); put("sender", s.sender)
                        put("receiver", s.receiver); put("refNo", s.refNo); put("entity", s.entity)
                        put("commission", s.commission); put("curMapJson", s.curMapJson)
                        put("img", s.img); put("auto", s.auto); put("autoKey", s.autoKey)
                    })
                }
            })
            put("buyerProfits", JSONArray().apply {
                bProfits.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id); put("target", p.target); put("type", p.type); put("kind", p.kind)
                        put("date", p.date); put("fromDate", p.fromDate); put("toDate", p.toDate)
                        put("amount", p.amount); put("specialtyId", p.specialtyId); put("note", p.note)
                        put("autoProfit", p.autoProfit); put("autoKey", p.autoKey)
                    })
                }
            })
            put("trash", JSONArray().apply {
                trash.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id); put("type", t.type); put("name", t.name)
                        put("parentId", t.parentId); put("payloadJson", t.payloadJson); put("deletedAt", t.deletedAt)
                    })
                }
            })
        }

        val imagesObj = JSONObject()
        if (includeImages) {
            val paths = linkedSetOf<String>()
            fun collect(p: String?) { if (!p.isNullOrBlank()) paths.add(p) }
            collect(settings.profile.logoPath)
            collect(settings.profile.stampPath)
            collect(settings.profile.signPath)
            collect(settings.appearance.backgroundPath)
            collect(settings.printing.lux.bgPath)
            folders.forEach { collect(it.imagePath) }
            invoices.forEach { collect(it.sellerPhotoPath); collect(it.invoicePaperPhotoPath) }
            clock.forEach { collect(it.img) }
            cashboxes.forEach { collect(it.imagePath) }
            debtVouchers.forEach { collect(it.imagePath) }
            tsFolders.forEach { collect(it.img) }
            tsAccounts.forEach { collect(it.img) }
            tsFunds.forEach { collect(it.img) }
            tsVouchers.forEach { collect(it.img) }
            pFolders.forEach { collect(it.img) }
            pAccounts.forEach { collect(it.img) }
            pTxs.forEach { collect(it.img) }
            bSales.forEach { collect(it.img) }
            paths.forEach { path ->
                val f = File(path)
                if (f.exists() && f.isFile && f.length() in 1L..(3L * 1024L * 1024L)) {
                    val b64 = android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP)
                    imagesObj.put(f.name, b64)
                }
            }
        }

        JSONObject().apply {
            put("format", FORMAT)
            put("version", 3)
            put("platform", "android-native")
            put("createdAt", DateHelper.todayIso())
            put("native", nativePayload)
            if (imagesObj.length() > 0) put("images", imagesObj)
        }.toString(2)
    }

    suspend fun importFromJson(
        rawJson: String,
        dao: SmartAdminDao,
        settingsStore: SettingsDataStore,
        context: Context? = null
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(rawJson)
            val n = root.optJSONObject("native")
                ?: return@withContext Result.failure(IllegalArgumentException("صيغة ملف النسخة غير صالحة"))

            val mediaDir = context?.let { File(it.filesDir, "media").apply { if (!exists()) mkdirs() } }
            val restoredPaths = mutableMapOf<String, String>()
            root.optJSONObject("images")?.let { imgs ->
                if (mediaDir != null) {
                    val mediaCanonical = mediaDir.canonicalPath
                    val keys = imgs.keys()
                    while (keys.hasNext()) {
                        val rawName = keys.next()
                        val safeName = File(rawName).name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                        if (safeName.isBlank()) continue
                        val dest = File(mediaDir, safeName)
                        if (!dest.canonicalPath.startsWith(mediaCanonical + File.separator)) continue
                        val b64 = imgs.optString(rawName)
                        if (b64.isNotBlank()) {
                            runCatching {
                                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                                if (bytes.size <= 4 * 1024 * 1024) {
                                    dest.writeBytes(bytes)
                                    restoredPaths[safeName] = dest.absolutePath
                                }
                            }
                        }
                    }
                }
            }
            fun remapPath(p: String): String {
                if (p.isBlank()) return ""
                val key = File(p).name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                return restoredPaths[key] ?: p
            }

            dao.clearWeekFolders(); dao.clearInvoices(); dao.clearWeeklyFilters(); dao.clearDetails()
            dao.clearClockEntries(); dao.clearDebtCashboxes(); dao.clearDebtAccounts(); dao.clearDebtVouchers()
            dao.clearCurrencyReceipts(); dao.clearCurrencyExchanges()
            dao.clearTsFolders(); dao.clearTsAccounts(); dao.clearTsFunds(); dao.clearTsVouchers()
            dao.clearPrivateFolders(); dao.clearPrivateAccounts(); dao.clearPrivateTxs()
            dao.clearBuyerTransfers(); dao.clearBuyerAnnualFolders(); dao.clearBuyerSales(); dao.clearBuyerProfits()
            dao.emptyTrash()

            var count = 0
            n.optJSONObject("settings")?.let { sObj ->
                val decoded = settingsStore.decode(sObj.toString())
                val remapped = decoded.copy(
                    profile = decoded.profile.copy(
                        logoPath = remapPath(decoded.profile.logoPath),
                        stampPath = remapPath(decoded.profile.stampPath),
                        signPath = remapPath(decoded.profile.signPath)
                    ),
                    appearance = decoded.appearance.copy(
                        backgroundPath = remapPath(decoded.appearance.backgroundPath)
                    ),
                    printing = decoded.printing.copy(
                        lux = decoded.printing.lux.copy(bgPath = remapPath(decoded.printing.lux.bgPath))
                    )
                )
                settingsStore.replace(remapped)
                count++
            }

            fun <T> readList(key: String, mapFn: (JSONObject) -> T): List<T> {
                val arr = n.optJSONArray(key) ?: return emptyList()
                return (0 until arr.length()).map { mapFn(arr.getJSONObject(it)) }
            }

            val wf = readList("weekFolders") { o ->
                WeekFolderEntity(o.getString("id"), o.getString("name"), remapPath(o.optString("imagePath")), o.optString("note"), o.optInt("sortOrder", 1), o.optString("scope", "home"), o.optString("startDate"), o.optString("endDate"), o.optString("specialtyId"), o.optBoolean("locked"), o.optLong("createdAt"))
            }
            dao.upsertWeekFolders(wf); count += wf.size

            val inv = readList("invoices") { o ->
                FolderInvoiceEntity(o.getString("id"), o.getString("folderId"), o.optString("invoiceKind", "seller"), o.optString("initDate"), o.optString("initDateISO"), o.optString("initSeller"), o.optString("initPlace"), o.optString("initWeeklyFilter"), o.optString("initNo"), o.optString("note"), o.optString("specialtyId"), remapPath(o.optString("sellerPhotoPath")), remapPath(o.optString("invoicePaperPhotoPath")), o.optString("formDataJson"), o.optString("buyerRowsJson"), o.optDouble("buyerTotal"), o.optDouble("buyerExpense"), o.optDouble("buyerNet"), o.optLong("createdAt"), o.optLong("updatedAt"))
            }
            dao.upsertInvoices(inv); count += inv.size

            val fl = readList("weeklyFilters") { o ->
                WeeklyFilterEntity(o.getString("id"), o.getString("name"), o.optString("fromDate"), o.optString("toDate"), o.optString("sourceFolderId"), o.optString("specialtyId"), o.optString("payloadJson"), o.optLong("updatedAt"))
            }
            dao.upsertWeeklyFilters(fl); count += fl.size

            val dt = readList("details") { o ->
                DetailRecordEntity(o.getString("id"), o.optString("autoFilterId"), o.optString("sourceFolderId"), o.optString("specialtyId"), o.optString("initDetail"), o.optString("initDateFrom"), o.optString("initDateTo"), o.optString("initNo"), o.optString("initFilter"), o.optString("note"), o.optString("formDataJson"), o.optLong("createdAt"), o.optLong("updatedAt"))
            }
            dao.upsertDetails(dt); count += dt.size

            val ck = readList("clockEntries") { o ->
                ClockEntryEntity(
                    o.getString("id"), o.optString("section"), o.optString("srcDetailId"), o.optString("specialtyId"),
                    o.optString("dir", "لكم"), o.optDouble("amount"), o.optString("name"), o.optString("date"),
                    o.optString("time"), o.optString("fromDate"), o.optString("toDate"), o.optString("note"),
                    o.optInt("days"), o.optDouble("qty"), o.optString("cur"), o.optDouble("curAmount"),
                    o.optDouble("curRate", 1.0), o.optString("kind"), o.optString("subRowsJson"),
                    o.optString("rowsJson", "[]"), remapPath(o.optString("img")), o.optString("tsVoucherId"),
                    o.optString("tsKind"), o.optBoolean("auto"), o.optLong("sentStamp")
                )
            }
            dao.upsertClockEntries(ck); count += ck.size

            val cb = readList("debtCashboxes") { o ->
                DebtCashboxEntity(o.getString("id"), o.getString("name"), remapPath(o.optString("imagePath")), o.optString("note"), o.optInt("sortOrder", 1), o.optBoolean("locked"), o.optLong("createdAt"))
            }
            dao.upsertDebtCashboxes(cb); count += cb.size

            val da = readList("debtAccounts") { o ->
                DebtAccountEntity(o.getString("id"), o.getString("cashboxId"), o.getString("name"), o.optString("phone"), o.optBoolean("limitEnabled"), o.optDouble("limitAmount"), o.optString("messageSend", "confirm"), o.optLong("createdAt"))
            }
            dao.upsertDebtAccounts(da); count += da.size

            val dv = readList("debtVouchers") { o ->
                DebtVoucherEntity(o.getString("id"), o.getString("accountId"), o.optString("specialtyId", ""), o.optString("type", "debt"), o.optDouble("amount"), o.optString("currency"), o.optString("note"), o.optString("date"), o.optString("time"), remapPath(o.optString("imagePath")), o.optString("autoSourceKey"), o.optLong("createdAt"))
            }
            dao.upsertDebtVouchers(dv); count += dv.size

            val cr = readList("currencyReceipts") { o ->
                CurrencyReceiptEntity(o.getString("id"), o.optString("fromFundId"), o.optString("toAccountId"), o.optString("toAccountName"), o.optString("currency"), o.optDouble("amount"), o.optDouble("rate", 1.0), o.optDouble("fee"), o.optString("date"), o.optString("note"), o.optLong("createdAt"))
            }
            dao.upsertCurrencyReceipts(cr); count += cr.size

            val ce = readList("currencyExchanges") { o ->
                CurrencyExchangeEntity(o.getString("id"), o.optString("fromCurrency"), o.optDouble("fromAmount"), o.optString("toCurrency"), o.optDouble("rate", 1.0), o.optDouble("toAmount"), o.optString("date"), o.optString("note"), o.optLong("createdAt"))
            }
            dao.upsertCurrencyExchanges(ce); count += ce.size

            val tf = readList("tsFolders") { o -> TsFolderEntity(o.getString("id"), o.getString("name"), o.optString("parentId"), remapPath(o.optString("img")), o.optInt("sortOrder", 1)) }
            dao.upsertTsFolders(tf); count += tf.size

            val ta = readList("tsAccounts") { o -> TsAccountEntity(o.getString("id"), o.getString("folderId"), o.getString("name"), o.optString("phone"), remapPath(o.optString("img")), o.optDouble("limitAmount", 0.0)) }
            dao.upsertTsAccounts(ta); count += ta.size

            val tfd = readList("tsFunds") { o -> TsFundEntity(o.getString("id"), o.getString("name"), remapPath(o.optString("img")), o.optInt("sortOrder", 1)) }
            dao.upsertTsFunds(tfd); count += tfd.size

            val tv = readList("tsVouchers") { o ->
                TsVoucherEntity(
                    o.getString("id"), o.optString("kind"), o.optString("dir"), o.optString("date"),
                    o.optString("time"), o.optString("accId"), o.optString("fundId"), o.optString("fromFundId"),
                    o.optString("toFundId"), o.optString("note"), remapPath(o.optString("img")), o.optString("cur"),
                    o.optDouble("amount"), o.optDouble("rate", 1.0), o.optString("rowsJson"),
                    o.optString("fromCur"), o.optDouble("fromAmt"), o.optString("toCur"), o.optDouble("toAmt"),
                    o.optString("sender"), o.optString("receiver"), o.optString("dest"), o.optString("transferNo"),
                    o.optDouble("com"), o.optString("comCur"), o.optString("pg"), o.optString("specialtyId"),
                    o.optString("srcClockId"), o.optLong("createdAt")
                )
            }
            dao.upsertTsVouchers(tv); count += tv.size

            val pf = readList("privateFolders") { o -> PrivateFolderEntity(o.getString("id"), o.getString("name"), remapPath(o.optString("img")), o.optLong("createdAt")) }
            dao.upsertPrivateFolders(pf); count += pf.size

            val pa = readList("privateAccounts") { o -> PrivateAccountEntity(o.getString("id"), o.getString("folderId"), o.getString("name"), o.optString("phone"), o.optDouble("cap"), o.optString("send", "confirm"), remapPath(o.optString("img")), o.optLong("createdAt")) }
            dao.upsertPrivateAccounts(pa); count += pa.size

            val pt = readList("privateTxs") { o -> PrivateTxEntity(o.getString("id"), o.getString("accountId"), o.optString("currency"), o.optString("date"), o.optString("time"), o.optDouble("amount"), o.optString("type"), o.optString("linesJson"), remapPath(o.optString("img")), o.optBoolean("xfer"), o.optLong("createdAt")) }
            dao.upsertPrivateTxs(pt); count += pt.size

            val bt = readList("buyerTransfers") { o ->
                BuyerTransferEntity(o.getString("id"), o.optString("folderId"), o.optString("specialtyId"), o.optString("name"), o.optString("fromDate"), o.optString("toDate"), o.optString("rowsJson"), o.optDouble("oldPrice"), o.optDouble("newPrice"), o.optDouble("rentRada"), o.optDouble("rentShip"), o.optDouble("weeklySale"), o.optDouble("habbaCount"), o.optString("diffAccountName"), o.optString("diffNote"), o.optLong("updatedAt"))
            }
            dao.upsertBuyerTransfers(bt); count += bt.size

            val ba = readList("buyerAnnualFolders") { o ->
                BuyerAnnualFolderEntity(o.getString("id"), o.optString("specialtyId"), o.optString("name"), o.optString("rowsJson"), o.optLong("updatedAt"))
            }
            dao.upsertBuyerAnnualFolders(ba); count += ba.size

            val bs = readList("buyerSales") { o ->
                BuyerSaleEntity(o.getString("id"), o.optString("dir"), o.optString("date"), o.optString("fromDate"), o.optString("toDate"), o.optDouble("amount"), o.optDouble("qty"), o.optDouble("unitPrice"), o.optString("specialtyId"), o.optString("note"), o.optString("sender"), o.optString("receiver"), o.optString("refNo"), o.optString("entity"), o.optDouble("commission"), o.optString("curMapJson"), remapPath(o.optString("img")), o.optBoolean("auto"), o.optString("autoKey"))
            }
            dao.upsertBuyerSales(bs); count += bs.size

            val bp = readList("buyerProfits") { o ->
                BuyerProfitEntity(o.getString("id"), o.optString("target"), o.optString("type"), o.optString("kind"), o.optString("date"), o.optString("fromDate"), o.optString("toDate"), o.optDouble("amount"), o.optString("specialtyId"), o.optString("note"), o.optBoolean("autoProfit"), o.optString("autoKey"))
            }
            dao.upsertBuyerProfits(bp); count += bp.size

            val tr = readList("trash") { o -> TrashItemEntity(o.getString("id"), o.getString("type"), o.getString("name"), o.optString("parentId"), o.optString("payloadJson"), o.optString("deletedAt")) }
            dao.upsertTrashAll(tr); count += tr.size

            Result.success(count)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun writeTempBackupFile(context: Context, json: String): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "shared").apply { if (!exists()) mkdirs() }
        val file = File(dir, "al_idari_pro_backup_${DateHelper.todayIso()}.json")
        file.writeText(json, Charsets.UTF_8)
        file
    }
}
