package com.example.data

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.domain.DriveBackupHistoryItem
import com.example.domain.DriveBackupSettings
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class GoogleDriveFileItem(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val createdTime: String,
    val modifiedTime: String
)

object GoogleDriveBackupManager {

    private const val SCOPE_DRIVE_FILE = "https://www.googleapis.com/auth/drive.file"
    private const val SCOPE_EMAIL = "https://www.googleapis.com/auth/userinfo.email"
    private const val SCOPE_PROFILE = "https://www.googleapis.com/auth/userinfo.profile"
    private const val FOLDER_NAME = "RYD"
    private const val WORK_NAME = "smart_admin_gdrive_auto_backup"

    @Volatile
    private var cachedAccessToken: String? = null

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    fun buildAuthorizationRequest(): AuthorizationRequest {
        return AuthorizationRequest.builder()
            .setRequestedScopes(
                listOf(
                    Scope(SCOPE_DRIVE_FILE),
                    Scope(SCOPE_EMAIL),
                    Scope(SCOPE_PROFILE)
                )
            )
            .build()
    }

    suspend fun authorize(activity: Activity): AuthorizationResult {
        return suspendCancellableCoroutine { cont ->
            Identity.getAuthorizationClient(activity)
                .authorize(buildAuthorizationRequest())
                .addOnSuccessListener { res ->
                    if (cont.isActive) cont.resume(res)
                }
                .addOnFailureListener { err ->
                    if (cont.isActive) cont.resumeWithException(err)
                }
        }
    }

    suspend fun authorizeSilent(context: Context): String? = withContext(Dispatchers.IO) {
        cachedAccessToken?.takeIf { it.isNotBlank() }?.let { return@withContext it }
        try {
            val res = suspendCancellableCoroutine<AuthorizationResult> { cont ->
                Identity.getAuthorizationClient(context)
                    .authorize(buildAuthorizationRequest())
                    .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                    .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
            }
            if (!res.hasResolution() && !res.accessToken.isNullOrBlank()) {
                cachedAccessToken = res.accessToken
                res.accessToken
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun cacheToken(token: String?) {
        if (!token.isNullOrBlank()) {
            cachedAccessToken = token
        }
    }

    fun clearSession() {
        cachedAccessToken = null
    }

    fun isWifiConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun isNetworkConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun fetchUserEmail(accessToken: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://www.googleapis.com/oauth2/v3/userinfo")
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IllegalStateException("فشل قراءة بيانات الحساب (${resp.code})")
            JSONObject(body).optString("email", "")
        }
    }

    suspend fun findOrCreateRydFolder(accessToken: String): String = withContext(Dispatchers.IO) {
        val query = "name='$FOLDER_NAME' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        val encodedQ = URLEncoder.encode(query, "UTF-8")
        val searchReq = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?q=$encodedQ&fields=files(id,name)&spaces=drive")
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        httpClient.newCall(searchReq).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (resp.code == 401) {
                cachedAccessToken = null
                throw IllegalStateException("انتهت صلاحية جلسة Google، أعد ربط الحساب")
            }
            if (!resp.isSuccessful) throw IllegalStateException("تعذر البحث عن مجلد $FOLDER_NAME (${resp.code})")
            val arr = JSONObject(body).optJSONArray("files")
            if (arr != null && arr.length() > 0) {
                val id = arr.getJSONObject(0).optString("id")
                if (id.isNotBlank()) return@withContext id
            }
        }

        val meta = JSONObject().apply {
            put("name", FOLDER_NAME)
            put("mimeType", "application/vnd.google-apps.folder")
        }.toString()
        val createReq = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?fields=id")
            .header("Authorization", "Bearer $accessToken")
            .post(meta.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(createReq).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IllegalStateException("تعذر إنشاء مجلد $FOLDER_NAME (${resp.code})")
            JSONObject(body).getString("id")
        }
    }

    suspend fun uploadBackupToRyd(
        accessToken: String,
        payloadJson: String,
        filename: String
    ): GoogleDriveFileItem = withContext(Dispatchers.IO) {
        val folderId = findOrCreateRydFolder(accessToken)
        val safeFilename = if (filename.endsWith(".back")) filename else "${filename.removeSuffix(".json")}.back"
        val metadataJson = JSONObject().apply {
            put("name", safeFilename)
            put("parents", JSONArray(listOf(folderId)))
            put("mimeType", "application/json")
        }.toString()

        val body = MultipartBody.Builder()
            .setType("multipart/related".toMediaType())
            .addPart(metadataJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .addPart(payloadJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val req = Request.Builder()
            .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime")
            .header("Authorization", "Bearer $accessToken")
            .post(body)
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (resp.code == 401) {
                cachedAccessToken = null
                throw IllegalStateException("انتهت صلاحية جلسة Google، أعد ربط الحساب")
            }
            if (!resp.isSuccessful) throw IllegalStateException("فشل رفع النسخة إلى Drive (${resp.code})")
            val o = JSONObject(raw)
            GoogleDriveFileItem(
                id = o.optString("id"),
                name = o.optString("name", safeFilename),
                sizeBytes = o.optString("size", payloadJson.toByteArray().size.toString()).toLongOrNull()
                    ?: payloadJson.toByteArray().size.toLong(),
                createdTime = o.optString("createdTime"),
                modifiedTime = o.optString("modifiedTime")
            )
        }
    }

    suspend fun listRydBackups(accessToken: String): List<GoogleDriveFileItem> = withContext(Dispatchers.IO) {
        val folderId = findOrCreateRydFolder(accessToken)
        val q = "'$folderId' in parents and trashed=false and mimeType!='application/vnd.google-apps.folder'"
        val encodedQ = URLEncoder.encode(q, "UTF-8")
        val url = "https://www.googleapis.com/drive/v3/files?q=$encodedQ&orderBy=modifiedTime%20desc&pageSize=30&fields=files(id,name,size,createdTime,modifiedTime)"
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (resp.code == 401) {
                cachedAccessToken = null
                throw IllegalStateException("انتهت صلاحية جلسة Google، أعد ربط الحساب")
            }
            if (!resp.isSuccessful) throw IllegalStateException("تعذر جلب قائمة النسخ من Drive (${resp.code})")
            val arr = JSONObject(raw).optJSONArray("files") ?: return@withContext emptyList()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                GoogleDriveFileItem(
                    id = o.optString("id"),
                    name = o.optString("name", "backup.back"),
                    sizeBytes = o.optString("size", "0").toLongOrNull() ?: 0L,
                    createdTime = o.optString("createdTime"),
                    modifiedTime = o.optString("modifiedTime")
                )
            }
        }
    }

    suspend fun downloadBackupContent(accessToken: String, fileId: String): String = withContext(Dispatchers.IO) {
        val safeId = URLEncoder.encode(fileId, "UTF-8")
        val req = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files/$safeId?alt=media")
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (resp.code == 401) {
                cachedAccessToken = null
                throw IllegalStateException("انتهت صلاحية جلسة Google، أعد ربط الحساب")
            }
            if (!resp.isSuccessful) throw IllegalStateException("تعذر تنزيل النسخة من Drive (${resp.code})")
            raw
        }
    }

    fun generateBackupFilename(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        return "SmartAdmin-Pro-Backup_${fmt.format(Date())}.back"
    }

    fun schedulePeriodicBackup(context: Context, gdrive: DriveBackupSettings) {
        val wm = WorkManager.getInstance(context)
        if (!gdrive.connected || !gdrive.dataEnabled) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val hours = when (gdrive.dataInterval) {
            "6h" -> 6L
            "12h" -> 12L
            "7d" -> 24L * 7L
            else -> 24L
        }
        val netType = if (gdrive.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(netType)
            .build()
        val request = PeriodicWorkRequestBuilder<DriveAutoBackupWorker>(hours, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun appendHistory(
        current: DriveBackupSettings,
        uploaded: GoogleDriveFileItem
    ): DriveBackupSettings {
        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())
        val item = DriveBackupHistoryItem(
            filename = uploaded.name,
            dateIso = uploaded.createdTime.ifBlank { nowIso },
            sizeBytes = uploaded.sizeBytes,
            fileId = uploaded.id
        )
        val merged = (listOf(item) + current.backupHistory).take(30)
        return current.copy(
            lastDataBackup = System.currentTimeMillis(),
            backupHistory = merged
        )
    }
}

class DriveAutoBackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val repo = SmartAdminRepository(applicationContext)
        val settings = repo.settingsFlow.first()
        val g = settings.gdriveBackup
        if (!g.connected || !g.dataEnabled) return Result.success()
        if (g.wifiOnly && !GoogleDriveBackupManager.isWifiConnected(applicationContext)) {
            return Result.retry()
        }
        val token = GoogleDriveBackupManager.authorizeSilent(applicationContext) ?: return Result.retry()
        return try {
            val payload = BackupManager.exportToJson(
                context = applicationContext,
                dao = repo.dao,
                settingsStore = repo.settingsStore,
                settings = settings,
                includeImages = g.imagesBackupEnabled
            )
            val filename = GoogleDriveBackupManager.generateBackupFilename()
            val uploaded = GoogleDriveBackupManager.uploadBackupToRyd(token, payload, filename)
            repo.updateSettings { cur ->
                cur.copy(gdriveBackup = GoogleDriveBackupManager.appendHistory(cur.gdriveBackup, uploaded))
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
