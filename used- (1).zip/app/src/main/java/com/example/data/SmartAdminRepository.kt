package com.example.data

import android.content.Context
import androidx.room.withTransaction
import com.example.data.EntityMappers.toDomain
import com.example.data.EntityMappers.toEntity
import com.example.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class AppDatabaseSnapshot(
    val weekFolders: List<WeekFolder> = emptyList(),
    val weeklyFilters: List<WeeklyFilter> = emptyList(),
    val details: List<DetailRecord> = emptyList(),
    val clockEntries: List<ClockEntry> = emptyList(),
    val debtCashboxes: List<DebtCashbox> = emptyList(),
    val debtAccounts: List<DebtAccount> = emptyList(),
    val debtVouchers: List<DebtVoucher> = emptyList(),
    val currencyReceipts: List<CurrencyReceipt> = emptyList(),
    val currencyExchanges: List<CurrencyExchangeOp> = emptyList(),
    val tsFolders: List<TsFolder> = emptyList(),
    val tsAccounts: List<TsAccount> = emptyList(),
    val tsFunds: List<TsFund> = emptyList(),
    val tsVouchers: List<TsVoucher> = emptyList(),
    val privateFolders: List<PrivateFolder> = emptyList(),
    val privateAccounts: List<PrivateAccount> = emptyList(),
    val privateTxs: List<PrivateTx> = emptyList(),
    val buyerTransfers: List<BuyerTransferSheet> = emptyList(),
    val buyerAnnualFolders: List<BuyerAnnualFolder> = emptyList(),
    val buyerSales: List<BuyerSaleEntry> = emptyList(),
    val buyerProfits: List<BuyerProfitEntry> = emptyList(),
    val trash: List<TrashItem> = emptyList()
)

class SmartAdminRepository(private val context: Context) {

    private val db = SmartAdminDatabase.getInstance(context)
    val dao = db.dao()
    val settingsStore = SettingsDataStore(context)
    private val syncMutex = Mutex()

    val settingsFlow: Flow<AppSettings> = settingsStore.settingsFlow

    private val corePartFlow = combine(
        dao.observeWeekFolders(),
        dao.observeInvoices(),
        dao.observeWeeklyFilters(),
        dao.observeDetails(),
        dao.observeClockEntries()
    ) { folders, invoices, filters, details, clock ->
        val byFolder = invoices.map { it.toDomain() }.groupBy { it.folderId }
        val fullFolders = folders.map { f -> f.toDomain(byFolder[f.id].orEmpty()) }
        Tuple5(
            fullFolders,
            filters.map { it.toDomain() },
            details.map { it.toDomain() },
            clock.map { it.toDomain() },
            Unit
        )
    }

    private val debtsCurrencyPartFlow = combine(
        dao.observeDebtCashboxes(),
        dao.observeDebtAccounts(),
        dao.observeDebtVouchers(),
        dao.observeCurrencyReceipts(),
        dao.observeCurrencyExchanges()
    ) { boxes, accs, vchs, receipts, exch ->
        Tuple5(
            boxes.map { it.toDomain() },
            accs.map { it.toDomain() },
            vchs.map { it.toDomain() },
            receipts.map { it.toDomain() },
            exch.map { it.toDomain() }
        )
    }

    private val tasfeerPartFlow = combine(
        dao.observeTsFolders(),
        dao.observeTsAccounts(),
        dao.observeTsFunds(),
        dao.observeTsVouchers(),
        dao.observeTrash()
    ) { folders, accs, funds, vchs, trash ->
        Tuple5(
            folders.map { it.toDomain() },
            accs.map { it.toDomain() },
            funds.map { it.toDomain() },
            vchs.map { it.toDomain() },
            trash.map { it.toDomain() }
        )
    }

    private val privatePartFlow = combine(
        dao.observePrivateFolders(),
        dao.observePrivateAccounts(),
        dao.observePrivateTxs()
    ) { folders, accs, txs ->
        Triple(
            folders.map { it.toDomain() },
            accs.map { it.toDomain() },
            txs.map { it.toDomain() }
        )
    }

    private val buyerPartFlow = combine(
        dao.observeBuyerTransfers(),
        dao.observeBuyerAnnualFolders(),
        dao.observeBuyerSales(),
        dao.observeBuyerProfits()
    ) { transfers, annual, sales, profits ->
        Tuple4(
            transfers.map { it.toDomain() },
            annual.map { it.toDomain() },
            sales.map { it.toDomain() },
            profits.map { it.toDomain() }
        )
    }

    val snapshotFlow: Flow<AppDatabaseSnapshot> = combine(
        corePartFlow,
        debtsCurrencyPartFlow,
        tasfeerPartFlow,
        privatePartFlow,
        buyerPartFlow
    ) { core, dc, ts, priv, buy ->
        AppDatabaseSnapshot(
            weekFolders = core.a,
            weeklyFilters = core.b,
            details = core.c,
            clockEntries = core.d,
            debtCashboxes = dc.a,
            debtAccounts = dc.b,
            debtVouchers = dc.c,
            currencyReceipts = dc.d,
            currencyExchanges = dc.e,
            tsFolders = ts.a,
            tsAccounts = ts.b,
            tsFunds = ts.c,
            tsVouchers = ts.d,
            privateFolders = priv.first,
            privateAccounts = priv.second,
            privateTxs = priv.third,
            buyerTransfers = buy.a,
            buyerAnnualFolders = buy.b,
            buyerSales = buy.c,
            buyerProfits = buy.d,
            trash = ts.e
        )
    }.flowOn(Dispatchers.Default)

    suspend fun ensureMinimumContainers() {
        syncMutex.withLock {
            if (dao.getDebtCashboxes().isEmpty()) {
                dao.upsertDebtCashbox(
                    DebtCashbox(id = "default-accounts", name = "حسابات", order = 1).toEntity()
                )
            }
            if (dao.getTsFunds().isEmpty()) {
                dao.upsertTsFund(
                    TsFund(id = "ts_fund_main", name = "صندوق التوريد الرئيسي", order = 1).toEntity()
                )
            }
            if (dao.getTsFolders().isEmpty()) {
                dao.upsertTsFolder(
                    TsFolder(id = "ts_folder_main", name = "مجلد حسابات 1", order = 1).toEntity()
                )
            }
        }
    }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settingsStore.update(transform)
    }

    suspend fun rememberNames(vararg names: String) {
        rememberNames(names.toList())
    }

    suspend fun rememberNames(names: Collection<String>) {
        val valid = names.map { NameSuggestionHelper.cleanDisplayName(it) }
            .filter { NameSuggestionHelper.isStorableName(it) }
        if (valid.isEmpty()) return
        settingsStore.update { s ->
            val updated = NameSuggestionHelper.addNamesToSaved(s.savedNames, valid)
            if (updated == s.savedNames) s else s.copy(savedNames = updated)
        }
    }

    suspend fun removeSavedName(name: String) {
        settingsStore.update { s ->
            val updated = NameSuggestionHelper.removeName(s.savedNames, name)
            if (updated == s.savedNames) s else s.copy(savedNames = updated)
        }
    }

    // --- Week Folders & Seller / Buyer Invoices + Auto-Sync ---

    suspend fun saveWeekFolder(folder: WeekFolder) {
        dao.upsertWeekFolder(folder.toEntity())
        rememberNames(folder.name)
        if (folder.scope == FolderScope.HOME) {
            syncHomeFolderPipeline(folder.id)
        } else {
            ensureBuyerTransferForFolder(folder)
        }
    }

    suspend fun deleteWeekFolderToTrash(folder: WeekFolder) {
        val payload = org.json.JSONObject().apply {
            put("id", folder.id); put("name", folder.name)
            put("scope", folder.scope.key); put("startDate", folder.startDate); put("endDate", folder.endDate)
            put("specialtyId", folder.specialtyId); put("note", folder.note); put("sortOrder", folder.order)
            put("imagePath", folder.imagePath); put("createdAt", folder.createdAt)
        }.toString()
        dao.upsertTrash(
            TrashItem(
                type = "folder",
                name = folder.name,
                parentId = "",
                payloadJson = payload,
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        dao.deleteInvoicesForFolder(folder.id)
        dao.deleteWeekFolder(folder.id)
    }

    suspend fun saveInvoice(invoice: FolderInvoice) {
        dao.upsertInvoice(invoice.toEntity())
        val namesToRemember = buildList {
            add(invoice.initSeller)
            invoice.formData.salesRows.forEach {
                add(it.dname)
                add(it.oname)
            }
            invoice.formData.receivedRows.forEach { add(it.name) }
            invoice.formData.outRows.forEach { add(it.name) }
            invoice.formData.withdrawRows.forEach { add(it.name) }
            invoice.formData.weeklyRows.forEach { add(it.name) }
            invoice.buyerRows.forEach { add(it.name) }
        }
        rememberNames(namesToRemember)
        val folder = dao.getWeekFolders().firstOrNull { it.id == invoice.folderId }
        if (folder?.scope == FolderScope.BUYER.key) {
            val allInvs = dao.getInvoices().filter { it.folderId == folder.id }.map { it.toDomain() }
            syncBuyerFolderInvoicesToTransfer(folder.toDomain(allInvs))
        } else {
            syncHomeFolderPipeline(invoice.folderId)
        }
    }

    suspend fun deleteInvoiceToTrash(invoice: FolderInvoice) {
        val payload = org.json.JSONObject().apply {
            put("id", invoice.id); put("folderId", invoice.folderId)
            put("invoiceKind", invoice.invoiceKind)
            put("initDate", invoice.initDate); put("initDateISO", invoice.initDateISO)
            put("initSeller", invoice.initSeller); put("initNo", invoice.initNo)
            put("note", invoice.note); put("specialtyId", invoice.specialtyId)
            put("formDataJson", JsonCodec.encodeSellerForm(invoice.formData).toString())
            put("buyerRowsJson", JsonCodec.encodeBuyerRows(invoice.buyerRows))
            put("buyerTotal", invoice.buyerTotal); put("buyerExpense", invoice.buyerExpense); put("buyerNet", invoice.buyerNet)
        }.toString()
        dao.upsertTrash(
            TrashItem(
                type = "invoice",
                name = "${invoice.initSeller} (${invoice.initDateISO})",
                parentId = invoice.folderId,
                payloadJson = payload,
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        dao.deleteInvoice(invoice.id)
        val folder = dao.getWeekFolders().firstOrNull { it.id == invoice.folderId }
        if (folder?.scope == FolderScope.HOME.key) {
            syncHomeFolderPipeline(invoice.folderId)
        } else if (folder != null) {
            val remInvs = dao.getInvoices().filter { it.folderId == folder.id }.map { it.toDomain() }
            syncBuyerFolderInvoicesToTransfer(folder.toDomain(remInvs))
        }
    }

    suspend fun copyOrMoveInvoices(invoices: List<FolderInvoice>, targetFolderId: String, move: Boolean) {
        if (invoices.isEmpty()) return
        val sourceFolderId = invoices.first().folderId
        val now = System.currentTimeMillis()
        db.withTransaction {
            invoices.forEachIndexed { idx, inv ->
                val newInv = if (move) {
                    inv.copy(folderId = targetFolderId, updatedAt = now + idx)
                } else {
                    inv.copy(id = newId("inv"), folderId = targetFolderId, createdAt = now + idx, updatedAt = now + idx)
                }
                dao.upsertInvoice(newInv.toEntity())
            }
        }
        val folders = dao.getWeekFolders()
        val targetFolder = folders.firstOrNull { it.id == targetFolderId }
        if (targetFolder?.scope == FolderScope.BUYER.key) {
            val targetInvs = dao.getInvoices().filter { it.folderId == targetFolderId }.map { it.toDomain() }
            syncBuyerFolderInvoicesToTransfer(targetFolder.toDomain(targetInvs))
        } else {
            syncHomeFolderPipeline(targetFolderId)
        }
        if (move && sourceFolderId != targetFolderId) {
            val sourceFolder = folders.firstOrNull { it.id == sourceFolderId }
            if (sourceFolder?.scope == FolderScope.BUYER.key) {
                val srcInvs = dao.getInvoices().filter { it.folderId == sourceFolderId }.map { it.toDomain() }
                syncBuyerFolderInvoicesToTransfer(sourceFolder.toDomain(srcInvs))
            } else {
                syncHomeFolderPipeline(sourceFolderId)
            }
        }
    }

    suspend fun syncHomeFolderPipeline(folderId: String) = syncMutex.withLock {
        val folderEntity = dao.getWeekFolders().firstOrNull { it.id == folderId } ?: return@withLock
        if (folderEntity.scope == FolderScope.BUYER.key) return@withLock
        val invoices = dao.getInvoices().filter { it.folderId == folderId }.map { it.toDomain() }
        val folder = folderEntity.toDomain(invoices)
        if (folder.startDate.isBlank() || folder.endDate.isBlank()) return@withLock

        val existingFilter = dao.getWeeklyFilters().map { it.toDomain() }
            .firstOrNull { it.sourceFolderId == folder.id || it.name == folder.name }
        val rebuiltFilter = WeeklyFilterCalculator.buildFilterFromFolder(folder, existingFilter)
        dao.upsertWeeklyFilter(rebuiltFilter.toEntity())

        val settings = settingsStore.settingsFlow.first()
        val existingDetail = dao.getDetails().map { it.toDomain() }
            .firstOrNull { it.autoFilterId == rebuiltFilter.id || it.sourceFolderId == folder.id }

        val autoDetailForm = DetailCalculator.buildDetailFormFromFolder(
            folder = folder,
            weeklyFilter = rebuiltFilter,
            specialties = settings.specialties,
            existingForm = existingDetail?.formData
        )
        val detailRecord = DetailRecord(
            id = existingDetail?.id ?: newId("det"),
            autoFilterId = rebuiltFilter.id,
            sourceFolderId = folder.id,
            specialtyId = folder.specialtyId,
            initDetail = folder.name,
            initDateFrom = folder.startDate,
            initDateTo = folder.endDate,
            initNo = existingDetail?.initNo ?: "",
            initFilter = rebuiltFilter.name,
            note = existingDetail?.note ?: autoDetailForm.note,
            formData = autoDetailForm,
            createdAt = existingDetail?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertDetail(detailRecord.toEntity())

        if (invoices.isNotEmpty() || existingDetail != null) {
            syncDetailToClockInternal(detailRecord, settings.specialties)
        }
    }

    suspend fun saveWeeklyFilter(filter: WeeklyFilter) {
        dao.upsertWeeklyFilter(filter.toEntity())
        rememberNames(filter.name)
        val existingDetail = dao.getDetails().map { it.toDomain() }
            .firstOrNull { it.autoFilterId == filter.id }
        if (existingDetail != null) {
            dao.upsertDetail(
                existingDetail.copy(
                    initDetail = filter.name,
                    initDateFrom = filter.fromDate,
                    initDateTo = filter.toDate,
                    initFilter = filter.name,
                    updatedAt = System.currentTimeMillis()
                ).toEntity()
            )
        }
    }

    suspend fun deleteWeeklyFilterToTrash(filter: WeeklyFilter) {
        dao.upsertTrash(
            TrashItem(
                type = "weeklyFilter",
                name = filter.name,
                parentId = filter.sourceFolderId,
                payloadJson = JsonCodec.encodeWeeklyFilterPayload(filter),
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        dao.deleteWeeklyFilter(filter.id)
    }

    suspend fun saveDetailRecord(record: DetailRecord, pushToClock: Boolean = true) {
        val recalced = record.copy(
            formData = DetailCalculator.recalculate(record.formData),
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertDetail(recalced.toEntity())
        rememberNames(
            buildList {
                add(recalced.initDetail)
                recalced.formData.receivedRows.forEach { add(it.name) }
                recalced.formData.debtRows.forEach { add(it.name) }
            }
        )
        if (pushToClock) {
            val settings = settingsStore.settingsFlow.first()
            syncMutex.withLock {
                syncDetailToClockInternal(recalced, settings.specialties)
            }
        }
    }

    suspend fun pushDetailToClock(record: DetailRecord) {
        val settings = settingsStore.settingsFlow.first()
        syncMutex.withLock {
            syncDetailToClockInternal(record, settings.specialties)
        }
    }

    private suspend fun syncDetailToClockInternal(record: DetailRecord, specialties: List<Specialty>) {
        dao.deleteClockEntriesForDetail(record.id)
        val entries = DetailCalculator.buildClockEntries(record, specialties)
        if (entries.isNotEmpty()) {
            dao.upsertClockEntries(entries.map { it.toEntity() })
        }
    }

    suspend fun deleteDetailToTrash(record: DetailRecord) {
        dao.upsertTrash(
            TrashItem(
                type = "detail",
                name = record.initDetail.ifBlank { "تفصيل" },
                parentId = record.autoFilterId,
                payloadJson = JsonCodec.encodeDetailForm(record.formData),
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        dao.deleteClockEntriesForDetail(record.id)
        dao.deleteDetail(record.id)
    }

    // --- Clock Entries ---
    suspend fun saveClockEntry(entry: ClockEntry) {
        dao.upsertClockEntry(entry.toEntity())
        if (!entry.auto) rememberNames(entry.name)
    }

    suspend fun deleteClockEntryToTrash(entry: ClockEntry) {
        dao.upsertTrash(
            TrashItem(
                type = "clockEntry",
                name = "${entry.section.labelAr} — ${entry.name.ifBlank { entry.date }}",
                parentId = entry.section.key,
                payloadJson = entry.id,
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        dao.deleteClockEntry(entry.id)
    }

    suspend fun deleteClockEntriesToTrash(entries: List<ClockEntry>) {
        entries.forEach { deleteClockEntryToTrash(it) }
    }

    // --- Debts (Cashboxes, Accounts, Vouchers) ---
    suspend fun saveDebtCashbox(box: DebtCashbox) {
        dao.upsertDebtCashbox(box.toEntity())
        rememberNames(box.name)
    }
    suspend fun deleteDebtCashbox(id: String) = deleteDebtCashboxCascade(id)

    suspend fun deleteDebtCashboxCascade(id: String) {
        val accIds = dao.getDebtAccounts().filter { it.cashboxId == id }.map { it.id }.toSet()
        if (accIds.isNotEmpty()) {
            dao.getDebtVouchers().filter { it.accountId in accIds }.forEach {
                dao.deleteDebtVoucher(it.id)
            }
            accIds.forEach { dao.deleteDebtAccount(it) }
        }
        dao.deleteDebtCashbox(id)
    }

    suspend fun saveDebtAccount(account: DebtAccount) {
        dao.upsertDebtAccount(account.toEntity())
        rememberNames(account.name)
    }
    suspend fun deleteDebtAccount(account: DebtAccount) {
        dao.getDebtVouchers().filter { it.accountId == account.id }.forEach {
            dao.deleteDebtVoucher(it.id)
        }
        dao.deleteDebtAccount(account.id)
    }

    suspend fun copyOrMoveDebtAccount(account: DebtAccount, targetCashboxId: String, move: Boolean) {
        if (move) {
            dao.upsertDebtAccount(account.copy(cashboxId = targetCashboxId).toEntity())
        } else {
            val now = System.currentTimeMillis()
            val newAccId = newId("da")
            val copyAcc = account.copy(
                id = newAccId,
                cashboxId = targetCashboxId,
                name = "${account.name} (نسخة)",
                createdAt = now
            )
            dao.upsertDebtAccount(copyAcc.toEntity())
            val accVouchers = dao.getDebtVouchers().filter { it.accountId == account.id }.map { it.toDomain() }
            accVouchers.forEachIndexed { idx, v ->
                dao.upsertDebtVoucher(
                    v.copy(id = newId("dv"), accountId = newAccId, createdAt = now + idx).toEntity()
                )
            }
        }
    }

    suspend fun saveDebtVoucher(voucher: DebtVoucher) = dao.upsertDebtVoucher(voucher.toEntity())
    suspend fun deleteDebtVoucher(id: String) = dao.deleteDebtVoucher(id)

    suspend fun deleteDebtVouchers(ids: List<String>) {
        ids.forEach { dao.deleteDebtVoucher(it) }
    }

    suspend fun copyOrMoveDebtVouchers(vouchers: List<DebtVoucher>, targetAccountId: String, move: Boolean) {
        val now = System.currentTimeMillis()
        vouchers.forEachIndexed { idx, v ->
            val updated = if (move) {
                v.copy(accountId = targetAccountId)
            } else {
                v.copy(id = newId("dv"), accountId = targetAccountId, createdAt = now + idx)
            }
            dao.upsertDebtVoucher(updated.toEntity())
        }
    }

    // --- Currency Strip Ops ---
    suspend fun saveCurrencyReceipt(receipt: CurrencyReceipt) {
        dao.upsertCurrencyReceipt(receipt.toEntity())
        rememberNames(receipt.toAccountName)
    }
    suspend fun deleteCurrencyReceipt(id: String) = dao.deleteCurrencyReceipt(id)
    suspend fun saveCurrencyExchange(exchange: CurrencyExchangeOp) = dao.upsertCurrencyExchange(exchange.toEntity())
    suspend fun deleteCurrencyExchange(id: String) = dao.deleteCurrencyExchange(id)

    // --- Tasfeer ---
    suspend fun saveTsFolder(folder: TsFolder) {
        dao.upsertTsFolder(folder.toEntity())
        rememberNames(folder.name)
    }
    suspend fun deleteTsFolder(id: String) = dao.deleteTsFolder(id)
    suspend fun saveTsAccount(account: TsAccount) {
        dao.upsertTsAccount(account.toEntity())
        rememberNames(account.name)
    }

    suspend fun deleteTsAccount(id: String) {
        val accVouchers = dao.getTsVouchers().filter { it.accId == id }
        accVouchers.forEach { dao.deleteClockEntriesByTsVoucher(it.id) }
        dao.deleteTsVouchersByAccId(id)
        dao.deleteTsAccount(id)
    }

    suspend fun copyOrMoveTsAccount(account: TsAccount, targetFolderId: String, move: Boolean) {
        if (move) {
            dao.upsertTsAccount(account.copy(folderId = targetFolderId).toEntity())
        } else {
            val now = System.currentTimeMillis()
            val newAccId = newId("tsa")
            val copyAcc = account.copy(
                id = newAccId,
                folderId = targetFolderId,
                name = "${account.name} (نسخة)"
            )
            dao.upsertTsAccount(copyAcc.toEntity())
            val oldVouchers = dao.getTsVouchers().filter { it.accId == account.id }.map { it.toDomain() }
            oldVouchers.forEachIndexed { idx, v ->
                dao.upsertTsVoucher(
                    v.copy(id = newId("tsv"), accId = newAccId, createdAt = now + idx).toEntity()
                )
            }
        }
    }

    suspend fun saveTsFund(fund: TsFund) {
        dao.upsertTsFund(fund.toEntity())
        rememberNames(fund.name)
    }
    suspend fun deleteTsFund(id: String) = dao.deleteTsFund(id)

    suspend fun saveTsVoucher(voucher: TsVoucher) = saveTsVoucherWithLink(voucher)

    suspend fun saveTsVoucherWithLink(v: TsVoucher) {
        dao.upsertTsVoucher(v.toEntity())
        rememberNames(v.sender, v.receiver)
        dao.deleteClockEntriesByTsVoucher(v.id)
        clockLinkInternal(v)
    }

    private suspend fun clockLinkInternal(v: TsVoucher) {
        val (targetSection, tsKind) = when (v.kind) {
            "clockacc" -> {
                val sec = when (v.pg) {
                    "جملة البيع النهائية" -> ClockSection.SALE
                    "خرج العمال" -> ClockSection.WORKERS
                    "السحب" -> ClockSection.WITHDRAW
                    "الديون" -> ClockSection.DEBTS
                    "العملات" -> ClockSection.CURRENCY
                    else -> null
                } ?: return
                sec to "acc"
            }
            "receipt" -> ClockSection.CURRENCY to "fund"
            else -> return
        }

        val settings = settingsStore.settingsFlow.first()
        val baseCur = settings.currencies.firstOrNull()?.name ?: "ريال يمني"
        val accName = if (v.accId.isNotBlank()) {
            dao.getTsAccounts().firstOrNull { it.id == v.accId }?.name ?: ""
        } else ""
        val fundName = if (v.fundId.isNotBlank()) {
            dao.getTsFunds().firstOrNull { it.id == v.fundId }?.name ?: ""
        } else ""
        val linkedName = accName.ifBlank { fundName }
        val rows = if (v.rows.isNotEmpty()) v.rows
        else if (v.amount > 0.0) listOf(TsRowCurrency(cur = v.cur.ifBlank { baseCur }, a = v.amount, r = v.rate))
        else emptyList()
        val total = TasfeerFxEngine.voucherTotalBase(v, baseCur)
        val linkedDir = if (v.dir == "out") "لكم" else "عليكم"

        dao.upsertClockEntry(
            ClockEntry(
                id = "ck_ts_${v.id}",
                section = targetSection,
                specialtyId = v.specialtyId,
                dir = linkedDir,
                amount = total,
                name = linkedName,
                date = v.date,
                time = v.time,
                note = v.note,
                cur = rows.firstOrNull()?.cur ?: "",
                curAmount = rows.firstOrNull()?.a ?: 0.0,
                curRate = rows.firstOrNull()?.r ?: 1.0,
                rows = rows,
                img = v.img,
                tsVoucherId = v.id,
                tsKind = tsKind,
                auto = false,
                sentStamp = System.currentTimeMillis()
            ).toEntity()
        )
    }

    suspend fun deleteTsVoucher(id: String) {
        dao.deleteTsVoucher(id)
        dao.deleteClockEntriesByTsVoucher(id)
    }

    suspend fun deleteTsVouchers(ids: List<String>) {
        ids.forEach { id ->
            dao.deleteTsVoucher(id)
            dao.deleteClockEntriesByTsVoucher(id)
        }
    }

    suspend fun resetTasfeerAll() {
        dao.getTsVouchers().forEach { dao.deleteClockEntriesByTsVoucher(it.id) }
        dao.clearTsVouchers()
        dao.clearTsAccounts()
        dao.clearTsFolders()
        dao.clearTsFunds()
        dao.upsertTsFund(TsFund(id = "ts_fund_main", name = "صندوق التوريد الرئيسي", order = 1).toEntity())
        dao.upsertTsFolder(TsFolder(id = "ts_folder_main", name = "مجلد حسابات 1", order = 1).toEntity())
    }

    // --- Private Accounts ---
    suspend fun savePrivateFolder(folder: PrivateFolder) {
        dao.upsertPrivateFolder(folder.toEntity())
        rememberNames(folder.name)
    }
    suspend fun deletePrivateFolder(id: String) = dao.deletePrivateFolder(id)

    suspend fun savePrivateAccount(account: PrivateAccount) {
        dao.upsertPrivateAccount(account.toEntity())
        rememberNames(account.name)
    }
    suspend fun deletePrivateAccountToTrash(account: PrivateAccount) {
        val txs = dao.getPrivateTxs().filter { it.accountId == account.id }
        val payload = org.json.JSONObject().apply {
            put("id", account.id); put("folderId", account.folderId)
            put("name", account.name); put("phone", account.phone)
            put("cap", account.cap); put("send", account.send); put("img", account.img)
        }.toString()
        dao.upsertTrash(
            TrashItem(
                type = "paAccount",
                name = account.name,
                parentId = account.folderId,
                payloadJson = payload,
                deletedAt = "${DateHelper.todayIso()} ${DateHelper.nowTime()}"
            ).toEntity()
        )
        txs.forEach { dao.deletePrivateTx(it.id) }
        dao.deletePrivateAccount(account.id)
    }

    suspend fun savePrivateTx(tx: PrivateTx) = dao.upsertPrivateTx(tx.toEntity())
    suspend fun savePrivateTransfer(
        fromAccount: PrivateAccount,
        toAccount: PrivateAccount,
        currency: String,
        amount: Double,
        typeOnSource: String,
        note: String
    ) {
        val d = DateHelper.todayIso()
        val tm = DateHelper.nowTime()
        val baseNote = note.ifBlank { "قيد بين الحسابات" }
        val tx1 = PrivateTx(
            accountId = fromAccount.id,
            currency = currency,
            date = d,
            time = tm,
            amount = amount,
            type = typeOnSource,
            lines = listOf("$baseNote (إلى ${toAccount.name})"),
            xfer = true
        )
        val tx2 = PrivateTx(
            accountId = toAccount.id,
            currency = currency,
            date = d,
            time = tm,
            amount = amount,
            type = if (typeOnSource == "عليه") "له" else "عليه",
            lines = listOf("$baseNote (من ${fromAccount.name})"),
            xfer = true
        )
        dao.upsertPrivateTx(tx1.toEntity())
        dao.upsertPrivateTx(tx2.toEntity())
    }

    suspend fun deletePrivateTx(id: String) = dao.deletePrivateTx(id)

    suspend fun deletePrivateTxs(ids: List<String>) {
        ids.forEach { dao.deletePrivateTx(it) }
    }

    suspend fun copyOrMovePrivateAccount(account: PrivateAccount, targetFolderId: String, move: Boolean) {
        if (move) {
            dao.upsertPrivateAccount(account.copy(folderId = targetFolderId).toEntity())
        } else {
            val now = System.currentTimeMillis()
            val newAccId = newId("pa")
            val copyAcc = account.copy(
                id = newAccId,
                folderId = targetFolderId,
                name = "${account.name} (نسخة)",
                createdAt = now
            )
            dao.upsertPrivateAccount(copyAcc.toEntity())
            val accTxs = dao.getPrivateTxs().filter { it.accountId == account.id }.map { it.toDomain() }
            accTxs.forEachIndexed { idx, tx ->
                dao.upsertPrivateTx(
                    tx.copy(id = newId("pt"), accountId = newAccId, createdAt = now + idx).toEntity()
                )
            }
        }
    }

    suspend fun copyOrMovePrivateTxs(txs: List<PrivateTx>, targetAccountId: String, move: Boolean) {
        val now = System.currentTimeMillis()
        txs.forEachIndexed { idx, tx ->
            val updated = if (move) {
                tx.copy(accountId = targetAccountId)
            } else {
                tx.copy(id = newId("pt"), accountId = targetAccountId, createdAt = now + idx)
            }
            dao.upsertPrivateTx(updated.toEntity())
        }
    }

    // --- Buyer / Purchase ---
    private suspend fun ensureBuyerTransferForFolder(folder: WeekFolder) {
        val existing = dao.getBuyerTransfers().firstOrNull { it.folderId == folder.id }
        if (existing == null) {
            dao.upsertBuyerTransfer(
                BuyerTransferSheet(
                    id = "bt_${folder.id}",
                    folderId = folder.id,
                    specialtyId = folder.specialtyId,
                    name = folder.name,
                    fromDate = folder.startDate,
                    toDate = folder.endDate
                ).toEntity()
            )
            syncBuyerEcosystemNow()
        }
    }

    private suspend fun syncBuyerFolderInvoicesToTransfer(folder: WeekFolder) {
        val existing = dao.getBuyerTransfers().firstOrNull { it.folderId == folder.id }?.toDomain()
            ?: BuyerTransferSheet(
                id = "bt_${folder.id}",
                folderId = folder.id,
                specialtyId = folder.specialtyId,
                name = folder.name,
                fromDate = folder.startDate,
                toDate = folder.endDate
            )
        val autoRows = folder.invoices.sortedBy { it.initDateISO }.map { inv ->
            BuyerTransferRow(
                id = "inv_${inv.id}",
                name = inv.initSeller.ifBlank { inv.initDate },
                buy = inv.buyerTotal,
                exp = inv.buyerExpense
            )
        }
        val merged = existing.copy(
            specialtyId = folder.specialtyId,
            name = folder.name,
            fromDate = folder.startDate,
            toDate = folder.endDate,
            rows = autoRows,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertBuyerTransfer(merged.toEntity())
        syncBuyerEcosystemNow()
    }

    suspend fun saveBuyerTransferSheet(sheet: BuyerTransferSheet) {
        dao.upsertBuyerTransfer(sheet.copy(updatedAt = System.currentTimeMillis()).toEntity())
        rememberNames(listOf(sheet.name, sheet.diffAccountName) + sheet.rows.map { it.name })
        syncBuyerEcosystemNow()
    }

    suspend fun deleteBuyerTransferSheet(id: String) {
        dao.deleteBuyerTransfer(id)
        syncBuyerEcosystemNow()
    }

    suspend fun saveBuyerAnnualFolder(folder: BuyerAnnualFolder) {
        dao.upsertBuyerAnnualFolder(folder.copy(updatedAt = System.currentTimeMillis()).toEntity())
        syncBuyerEcosystemNow()
    }

    suspend fun saveBuyerSaleEntry(entry: BuyerSaleEntry) {
        dao.upsertBuyerSale(entry.toEntity())
        rememberNames(entry.sender, entry.receiver, entry.entity)
    }

    suspend fun deleteBuyerSaleEntry(id: String) = dao.deleteBuyerSale(id)

    suspend fun saveBuyerProfitEntry(entry: BuyerProfitEntry) {
        dao.upsertBuyerProfit(entry.toEntity())
    }

    suspend fun deleteBuyerProfitEntry(id: String) = dao.deleteBuyerProfit(id)

    suspend fun syncBuyerEcosystemNow() = syncMutex.withLock {
        val settings = settingsStore.settingsFlow.first()
        val folders = dao.getWeekFolders().map { it.toDomain(emptyList()) }
        val transfers = dao.getBuyerTransfers().map { it.toDomain() }
        val annual = dao.getBuyerAnnualFolders().map { it.toDomain() }
        val sales = dao.getBuyerSales().map { it.toDomain() }
        val profits = dao.getBuyerProfits().map { it.toDomain() }

        val (syncedAnnual, syncedSales, syncedProfits) = BuyerCalculators.syncBuyerEcosystem(
            folders = folders,
            specialties = settings.buyerSpecialties,
            transferSheets = transfers,
            existingAnnualFolders = annual,
            existingSales = sales,
            existingProfits = profits
        )
        db.withTransaction {
            dao.clearBuyerAnnualFolders()
            dao.upsertBuyerAnnualFolders(syncedAnnual.map { it.toEntity() })
            dao.clearAutoBuyerSales()
            dao.upsertBuyerSales(syncedSales.map { it.toEntity() })
            dao.clearAutoBuyerProfits()
            dao.upsertBuyerProfits(syncedProfits.map { it.toEntity() })
        }
    }

    // --- Trash & Full Reset ---
    suspend fun deleteTrashItem(id: String) = dao.deleteTrash(id)
    suspend fun emptyTrash() = dao.emptyTrash()

    suspend fun restoreTrashItem(item: TrashItem): Boolean {
        return try {
            when (item.type) {
                "folder" -> {
                    val o = org.json.JSONObject(item.payloadJson)
                    val f = WeekFolder(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        imagePath = o.optString("imagePath"),
                        note = o.optString("note"),
                        order = o.optInt("sortOrder", 1),
                        scope = FolderScope.fromKey(o.optString("scope", "home")),
                        startDate = o.optString("startDate"),
                        endDate = o.optString("endDate"),
                        specialtyId = o.optString("specialtyId"),
                        createdAt = o.optLong("createdAt")
                    )
                    dao.upsertWeekFolder(f.toEntity())
                }
                "invoice" -> {
                    val o = org.json.JSONObject(item.payloadJson)
                    val inv = FolderInvoice(
                        id = o.getString("id"),
                        folderId = o.getString("folderId"),
                        invoiceKind = o.optString("invoiceKind", "seller"),
                        initDate = o.optString("initDate"),
                        initDateISO = o.optString("initDateISO"),
                        initSeller = o.optString("initSeller"),
                        initNo = o.optString("initNo"),
                        note = o.optString("note"),
                        specialtyId = o.optString("specialtyId"),
                        formData = JsonCodec.decodeSellerForm(o.optString("formDataJson")),
                        buyerRows = JsonCodec.decodeBuyerRows(o.optString("buyerRowsJson")),
                        buyerTotal = o.optDouble("buyerTotal"),
                        buyerExpense = o.optDouble("buyerExpense"),
                        buyerNet = o.optDouble("buyerNet")
                    )
                    dao.upsertInvoice(inv.toEntity())
                    syncHomeFolderPipeline(inv.folderId)
                }
                "paAccount" -> {
                    val o = org.json.JSONObject(item.payloadJson)
                    val acc = PrivateAccount(
                        id = o.getString("id"),
                        folderId = o.getString("folderId"),
                        name = o.getString("name"),
                        phone = o.optString("phone"),
                        cap = o.optDouble("cap"),
                        send = o.optString("send", "confirm"),
                        img = o.optString("img")
                    )
                    dao.upsertPrivateAccount(acc.toEntity())
                }
                else -> return false
            }
            dao.deleteTrash(item.id)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun eraseAllData() {
        dao.clearWeekFolders(); dao.clearInvoices(); dao.clearWeeklyFilters(); dao.clearDetails()
        dao.clearClockEntries(); dao.clearDebtCashboxes(); dao.clearDebtAccounts(); dao.clearDebtVouchers()
        dao.clearCurrencyReceipts(); dao.clearCurrencyExchanges()
        dao.clearTsFolders(); dao.clearTsAccounts(); dao.clearTsFunds(); dao.clearTsVouchers()
        dao.clearPrivateFolders(); dao.clearPrivateAccounts(); dao.clearPrivateTxs()
        dao.clearBuyerTransfers(); dao.clearBuyerAnnualFolders(); dao.clearBuyerSales(); dao.clearBuyerProfits()
        dao.emptyTrash()
        ensureMinimumContainers()
    }

    suspend fun exportBackupJson(settings: AppSettings, includeImages: Boolean = false): String =
        BackupManager.exportToJson(context, dao, settingsStore, settings, includeImages)

    suspend fun importBackupJson(raw: String): Result<Int> {
        val res = BackupManager.importFromJson(raw, dao, settingsStore, context)
        if (res.isSuccess) ensureMinimumContainers()
        return res
    }
}

data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
data class Tuple5<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)
