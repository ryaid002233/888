package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.DateHelper
import com.example.ui.navigation.SmartAdminRootApp
import com.example.ui.theme.SmartAdminTheme
import com.example.ui.viewmodel.SmartAdminViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: SmartAdminViewModel = viewModel()
            val uiState by vm.uiState.collectAsStateWithLifecycle()

            val exportLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.CreateDocument("application/json")
            ) { uri ->
                if (uri != null) vm.exportBackupToUri(uri)
            }

            val importLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) vm.importBackupFromUri(uri)
            }

            SmartAdminTheme(settings = uiState.settings) {
                SmartAdminRootApp(
                    uiState = uiState,
                    viewModel = vm,
                    onExportBackup = {
                        exportLauncher.launch("SmartAdmin_Backup_${DateHelper.todayIso()}.json")
                    },
                    onImportBackup = {
                        importLauncher.launch(arrayOf("application/json", "*/*"))
                    }
                )
            }
        }
    }
}
